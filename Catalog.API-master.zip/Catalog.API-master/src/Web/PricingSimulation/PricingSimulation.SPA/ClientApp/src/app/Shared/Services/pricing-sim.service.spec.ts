import { TestBed } from '@angular/core/testing';

import { PricingSimService } from './pricing-sim.service';

describe('PricingSimService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PricingSimService = TestBed.get(PricingSimService);
    expect(service).toBeTruthy();
  });
});
