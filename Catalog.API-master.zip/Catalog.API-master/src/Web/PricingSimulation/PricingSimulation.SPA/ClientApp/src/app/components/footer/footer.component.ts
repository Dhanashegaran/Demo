import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  template: ` <footer><p>© Copyright 2019. All rights reserved.</p></footer>`,
  styles: [`
    footer {
      right: 0;
      bottom: 0;
      left: 0;
      padding: 1rem;
      text-align: center;
      position: relative;
      height: 40px;
      margin-top: -40px;
    }
    p { margin-left: 70%; }
  `]
})
export class FooterComponent {}