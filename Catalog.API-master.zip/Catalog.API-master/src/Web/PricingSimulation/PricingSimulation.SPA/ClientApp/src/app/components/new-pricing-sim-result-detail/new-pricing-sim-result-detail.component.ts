import { Component, Input, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { MatPaginator, MatSort } from '@angular/material';
import { IDetail } from '../../typings/pricing-sim-result-details';

@Component({
  selector: 'app-new-pricing-sim-result-detail',
  templateUrl: './new-pricing-sim-result-detail.component.html',
  styleUrls: ['./new-pricing-sim-result-detail.component.scss'],
})
export class NewPricingSimResultDetailComponent {
  selectedColumn: string[];

  public searchString: string;
  displayedDetailColumns = ['responseDetailId', 'printerSku', 'componentSku', 'itemClass', 'cpqflag', 'priceSource', 'costSource', 'tcos', 'tcoscurrency', 'tcoscurrencyRate', 'targetMarginPct', 'lclpcurrency', 'lclpcurrencyRate', 'lclp', 'bdnetPrice', 'bdnetPriceCurrency', 'bdnetPriceCurrencyRate', 'contractualDiscountPct', 'truckloadDiscountPct', 'maxPricePct', 'msppct', 'tier1Pct', 'tier2Pct', 'tier3Pct', 'tier4Pct', 'isomonoYield', 'isoColorYield', 'isoProfColorYield', 'isoColorSaveYield', 'isoCoveragePct', 'operationalYieldCalcMethod', 'tcossimulationCurrencyRate', 'lclpsimulationCurrencyRate', 'bdnetSimulationCurrencyRate', 'unitCost', 'targetMarginNetPrice', 'listPrice', 'ndp', 'maxPrice', 'msp', 'streetPrice', 'bdnetPriceTier0', 'bdnetPriceTier1', 'bdnetPriceTier2', 'bdnetPriceTier3', 'bdnetPriceTier4', 'discountedNetPrice', 'netPrice', 'operationalCoveragePct', 'operationalMonoOnMonoYield', 'operationalMonoOnProfessionalColorYield', 'operationalMonoOnColorYield', 'operationalMonoOnColorSaveYield', 'operationalProfColorYield', 'operationalColorYield', 'operationaColorSaveYield', 'componentQty', 'componentBaseFee', 'componentMonoClick', 'componentProfColorClick', 'componentColorClick', 'componentColorSaveClick', 'extendedNetPrice', 'extendedCost'];
  matDataSourceDetail: MatTableDataSource<IDetail>;

  @ViewChild(MatSort) sortDetail: MatSort;
  @ViewChild(MatPaginator) paginatorDetail: MatPaginator;

  private _details: IDetail[];
  get Details(): IDetail[] {
    return this._details;
  }

  @Input()
  set Details(val: IDetail[]) {
    this._details = val;
    this.matDataSourceDetail = new MatTableDataSource<IDetail>(this._details);
    this.matDataSourceDetail.sort = this.sortDetail;
    this.matDataSourceDetail.paginator = this.paginatorDetail;
  }

  public doTableFilter = (value: string) => {
    var tempdata: IDetail[];
    // console.info(this.selectedColumn);
    tempdata = this.transform(this._details, this.selectedColumn, value);
    this.matDataSourceDetail = new MatTableDataSource<IDetail>(tempdata);
    this.matDataSourceDetail.sort = this.sortDetail;
    this.matDataSourceDetail.paginator = this.paginatorDetail;
    //this.matDataSourceSummary.filter = value.trim().toLocaleLowerCase();
  }
  transform(items: any[], field: string[], value: string): any[] {
    if (!items) {
      return [];
    }
    if (!field || !value) {
      return items;
    }
    var result: any[] = [];

    for (var i = 0; i < field.length; i++) {
      var temp = items.filter(singleItem =>
        (
          singleItem[field[i]] + '').toString().toLowerCase().includes(value.toLowerCase())
      );
      if (temp != null && temp != undefined) {
        // console.info(temp);
        temp.forEach(Obj => {
          result.push(Obj);
        });
      }
    }
    return result;

  }

}
