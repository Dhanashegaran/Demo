import { TestBed } from '@angular/core/testing';

import { MasterDataFetchService } from './master-data-fetch.service';

describe('MasterDataFetchService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MasterDataFetchService = TestBed.get(MasterDataFetchService);
    expect(service).toBeTruthy();
  });
});
