import { Injectable, EventEmitter } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  public toggleShowSideMenuEvent: EventEmitter<undefined> = new EventEmitter();

  public toggleSideMenuState () {
    this.toggleShowSideMenuEvent.emit();
  }
}
