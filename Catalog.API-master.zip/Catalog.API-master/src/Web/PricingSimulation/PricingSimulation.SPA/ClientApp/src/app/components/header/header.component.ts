import { Component } from '@angular/core';
import { AppService } from 'src/app/app.service.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styles: [`
    .header {
      display: flex;
      flex: 1;
      width: 100%;
      background: #0096D6;
      font-size: 1rem;
      color: #fff;
      align-items: center;
      letter-spacing: .3px;
    }

    .home-logo { width: 100px; }

    .navigation-bar {
      display: flex;
      flex: 1;
      justify-content: flex-end;
      border-bottom: 0;
    }
    .brand-name { font-size: 1.8rem; font-weight: bold; }
    .navigation-bar .nav-item { 
      color: #fff;
      opacity: 0.8;
      height: auto;
      text-decoration: none;
    }
    .navigation-bar .nav-item span { 
      padding: 3px;
      display: inline-block;
      height: 25px;
      box-sizing: border-box;
    }
    .menu-button { min-width: 0; padding: 3px 10px; }
    .menu-button:focus { outline: none; }
    .menu-button:hover { border-radius: 50%; }
    .navigation-bar .nav-item.active { opacity: 1; }
    .navigation-bar .nav-item.active span,
    .navigation-bar .nav-item span:hover {
      border-bottom: 1px solid #fff;
    }
  `]
})
export class HeaderComponent {
  
  constructor(private appService: AppService) { }

  toggleSideMenu() {
    this.appService.toggleSideMenuState();
  }
}
