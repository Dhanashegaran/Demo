import { Component, Input, Output, EventEmitter } from '@angular/core';
import { PriceSimulationRequestDetail } from '../../pages/new-pricing-sim-request/price-simulation-request-detail';

@Component({
  selector: 'app-new-pricing-detail',
  templateUrl: './new-pricing-detail.component.html',
  styleUrls: ['./new-pricing-detail.component.css']
})
export class NewPricingDetailComponent {
  @Input() requestDetail: PriceSimulationRequestDetail;
  @Input() printerSkus: string[];
  @Output() remove = new EventEmitter<any>();


  RemovePrinter(){
    this.remove.emit();
  }

}
