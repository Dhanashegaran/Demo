import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { MasterDataFetchService } from './master-data-fetch.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { IAvailableCountries } from '../../typings/pricing-sim';
import { PriceSimulationRequest } from '../../pages/new-pricing-sim-request/price-simulation-request';
import { MatSnackBar } from '@angular/material';

@Injectable({
  providedIn: 'root'
})

export class PricingSimService {
  
  public availableL1: Observable<Array<string>>;
  private _availableL1: BehaviorSubject<Array<string>>;

  public availableCountries: Observable<IAvailableCountries[]>;
  private _availableCountries: BehaviorSubject<IAvailableCountries[]>;

  constructor(
    private http: HttpClient, 
    private masterService: MasterDataFetchService, 
    private snackBar: MatSnackBar
  ) {
    
    this._availableL1 = <BehaviorSubject<Array<string>>> new BehaviorSubject([]);
    this.availableL1 = this._availableL1.asObservable();

    this._availableCountries = <BehaviorSubject<IAvailableCountries[]>> new BehaviorSubject([]);
    this.availableCountries = this._availableCountries.asObservable();
  }

  public getSimData(simId: string) {
    return this.http.get(environment.settings.catalogServiceUrl + 'Simulation?SimulationId=' + simId);
  }

  public getAllSimulationsForPrinterSKU(printerSku: string): any {
    return this.http.get(environment.settings.catalogServiceUrl + 'Simulations?PrinterSku=' + printerSku);
  }

  public PerformPricingSimulation(input: PriceSimulationRequest): any {
    return this.http.post(
      environment.settings.catalogServiceUrl + "ProcessSimulation",
      input
    );
  }

  public lockPrinter(simId: string, printerSku: string, effectiveStartDate: Date, effectiveEndDate: Date) {
    const url = environment.settings.catalogServiceUrl + 'LockPrinterPricing';
    return this.http.post(url, {
      simulationId: simId,
      printerSKU: printerSku,
      effectiveStartDate: effectiveStartDate,
      effectiveEndDate: effectiveEndDate,
      enable: true
    });
  }

  public filterAvailableL1ForCountry (country: string): void {
    this.masterService.
      GetAvailableL1ForCountry(country).subscribe(
      (data: Array<string>) => this._availableL1.next(data),
      error => this.openSnackBar(error.error, 'dismiss')
    )
  }

  public getAvailableCountries (): void {
    this.masterService
      .GetAvailableCountries()
      .subscribe((data: IAvailableCountries[]) => {
        this._availableCountries.next(data),
          error => this.openSnackBar(error.error, 'dismiss');
      });
  }

  public openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 5000,
    });
  }
}
