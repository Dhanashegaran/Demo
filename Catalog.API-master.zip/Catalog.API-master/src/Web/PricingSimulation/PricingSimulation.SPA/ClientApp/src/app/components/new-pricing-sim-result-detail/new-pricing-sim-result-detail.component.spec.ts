import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewPricingSimResultDetailComponent } from './new-pricing-sim-result-detail.component';

describe('NewPricingSimResultDetailComponent', () => {
  let component: NewPricingSimResultDetailComponent;
  let fixture: ComponentFixture<NewPricingSimResultDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewPricingSimResultDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewPricingSimResultDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
