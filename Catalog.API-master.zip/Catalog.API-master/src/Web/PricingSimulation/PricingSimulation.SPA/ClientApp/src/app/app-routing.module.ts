import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NewPricingSimRequestComponent } from './pages/new-pricing-sim-request/new-pricing-sim-request.component';
import { PricingSimComponent } from './pages/pricing-sim/pricing-sim.component';
import { NewPricingSimLockComponent } from './pages/new-pricing-sim-lock/new-pricing-sim-lock.component';
import { AuthGuardService } from './shared/services/auth-guard.service';
import { AuthCallbackComponent } from './components/auth-callback/auth-callback.component';
import { AuthService } from './shared/services/auth.service';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/app-new-pricing-sim-request',
    pathMatch: 'full'
  },
  { 
    path: 'app-new-pricing-sim-request', 
    component: NewPricingSimRequestComponent,
    canActivate: [AuthGuardService]
  },
  { 
    path: 'app-pricing-sim', 
    component: PricingSimComponent,
    canActivate: [AuthGuardService]
   },
  { 
    path: 'app-lock-pricing',
     component: NewPricingSimLockComponent,
     canActivate: [AuthGuardService]
    },
  { 
    path: 'app-lock-pricing/:printerSKU', 
    component: NewPricingSimLockComponent,
    canActivate: [AuthGuardService]
   },
   {
    path: 'auth-callback',
    component: AuthCallbackComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [AuthGuardService, AuthService]
})
export class AppRoutingModule { }
