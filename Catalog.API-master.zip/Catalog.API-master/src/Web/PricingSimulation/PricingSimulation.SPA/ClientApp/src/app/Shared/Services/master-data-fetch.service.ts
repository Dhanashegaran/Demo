import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
export type PrinterDescription = [string, string];

@Injectable({
  providedIn: 'root'
})

export class MasterDataFetchService { 
  
  constructor(private http: HttpClient, private authService: AuthService) {
    /*
    let headers:  HttpHeaders  = new HttpHeaders();
    headers.append('Accept', 'application/json');
    headers.append('Authorization', `Bearer ${this.authService.getAuthorizationHeaderValue()}`)
    */
  }

  GetAvailableCountries(){
   /*
    let headers = new HttpHeaders({ 'Authorization': this.authService.getAuthorizationHeaderValue() });

   // headers.append('Authorization', `Bearer ${this.authService.getAuthorizationHeaderValue()}`)
    console.log(headers);
    return this.http.get(environment.settings.masterDataServiceUrl + "Countries", {  headers: headers });
    */
    return this.http.get(environment.settings.masterDataServiceUrl + "Countries");
  }

  GetAvailableL1ForCountry (country: string){    
    return this.http.get(environment.settings.masterDataServiceUrl + "L1OfferTypes?IsoCountryCode="+country);
  }

  GetAvailableL2ForCountry(country: string, l1:string){
    return this.http.get(environment.settings.masterDataServiceUrl + "L2OfferTypes?IsoCountryCode="+country+ "&L1OfferType=" +l1);
  }

  GetAvailableCurrenciesForCountry(l2: string, l1: string, country: string){
    return this.http.get(environment.settings.masterDataServiceUrl + "Currencies?IsoCountryCode="+country + "&L1OfferType=" + l1 + "&L2OfferType=" + l2);
  }

  GetHardwarePurchaseMethods(l2: string, l1: string, country: string){
    return this.http.get(environment.settings.masterDataServiceUrl + "HardwarePurchaseMethods?IsoCountryCode="+country + "&L1OfferType=" + l1 + "&L2OfferType=" + l2);
  }

  GetKitOptions(l2: string, l1: string, country: string){
    return this.http.get(environment.settings.masterDataServiceUrl + "KitOptions?IsoCountryCode="+country + "&L1OfferType=" + l1 + "&L2OfferType=" + l2);
  }

  GetServiceLevels(l2: string, l1: string, country: string){
    return this.http.get(environment.settings.masterDataServiceUrl + "ServiceLevels?IsoCountryCode="+country + "&L1OfferType=" + l1 + "&L2OfferType=" + l2);
  }

  GetBillingModels(l2: string, l1: string, country: string){
    return this.http.get(environment.settings.masterDataServiceUrl + "BillingModels?IsoCountryCode="+country + "&L1OfferType=" + l1 + "&L2OfferType=" + l2);
  }

  GetHardwareFulfillmentOptions(l2: string, l1: string, country: string){
    return this.http.get(environment.settings.masterDataServiceUrl + "HardwareFulfillmentOptions?IsoCountryCode="+country + "&L1OfferType=" + l1 + "&L2OfferType=" + l2);
  }

  GetHardwareFulfillmentChannels(l2: string, l1: string, country: string){
    return this.http.get(environment.settings.masterDataServiceUrl + "HardwareFulfillmentChannels?IsoCountryCode="+country + "&L1OfferType=" + l1 + "&L2OfferType=" + l2);
  }

  GetSupplyFulfillmentOptions(l2: string, l1: string, country: string){
    return this.http.get(environment.settings.masterDataServiceUrl + "SupplyFulfillmentOptions?IsoCountryCode="+country + "&L1OfferType=" + l1 + "&L2OfferType=" + l2);
  }

  GetAvailableForL1Country(tableName: string, l1: string,  country: string): string[] {
    return [tableName + country + '_V1', tableName + country + '_V2'];
  }

  GetAvailableMarginTemplate(l2: string, l1: string): any {
    return  this.http.get(environment.settings.masterDataServiceUrl + "MarginTemplates?L1OfferType="+l1 + "&L2OfferType=" + l2);
   }

  GetAvailablePrinterSKUs(country: string, l1: string, l2: string): any {
    return this.http.get<PrinterDescription>(environment.settings.masterDataServiceUrl + "PrinterSkus?IsoCountryCode="+country + "&L1OfferType=" + l1 + "&L2OfferType=" + l2);
   }
}
