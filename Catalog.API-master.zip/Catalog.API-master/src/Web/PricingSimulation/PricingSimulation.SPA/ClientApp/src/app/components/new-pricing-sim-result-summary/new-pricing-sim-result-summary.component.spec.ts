import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewPricingSimResultSummaryComponent } from './new-pricing-sim-result-summary.component';

describe('NewPricingSimResultSummaryComponent', () => {
  let component: NewPricingSimResultSummaryComponent;
  let fixture: ComponentFixture<NewPricingSimResultSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewPricingSimResultSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewPricingSimResultSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
