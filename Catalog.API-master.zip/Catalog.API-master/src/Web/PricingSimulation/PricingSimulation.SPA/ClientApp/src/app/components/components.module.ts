import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { MaterialModule } from '../material.module';

/** Application Components Start */

import { NewPricingDetailComponent } from './new-pricing-detail/new-pricing-detail.component';
import { NewPricingSimResultsComponent } from './new-pricing-sim-results/new-pricing-sim-results.component';
import { NewPricingSimResultSummaryComponent } from './new-pricing-sim-result-summary/new-pricing-sim-result-summary.component';
import { NewPricingSimResultDetailComponent } from './new-pricing-sim-result-detail/new-pricing-sim-result-detail.component';
import { NewPricingSimLockComponent } from '../pages/new-pricing-sim-lock/new-pricing-sim-lock.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { SideMenuComponent } from './side-menu/side-menu.component';
import { AppRoutingModule } from '../app-routing.module';
import { AuthCallbackComponent } from './auth-callback/auth-callback.component';

/** Application Components End */

@NgModule({
  declarations: [
    NewPricingDetailComponent,
    NewPricingSimResultsComponent,
    NewPricingSimResultSummaryComponent,
    NewPricingSimResultDetailComponent,
    NewPricingSimLockComponent,
    FooterComponent,
    HeaderComponent,
    SideMenuComponent,
    AuthCallbackComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    MaterialModule,
    AppRoutingModule
  ],
  exports: [
    NewPricingDetailComponent,
    NewPricingSimResultsComponent,
    NewPricingSimResultSummaryComponent,
    NewPricingSimResultDetailComponent,
    FooterComponent,
    HeaderComponent,
    SideMenuComponent
  ]
})
export class ComponentsModule { }
