﻿using IdentityServer4;
using IdentityServer4.Models;
using IdentityServer4.Test;
using System.Collections.Generic;
using System.Security.Claims;

namespace Hp.ContractualFramework.Services.Identity.API.Configuration
{
    public static class Config
    {
        public static List<TestUser> GetUsers()
        {
            return new List<TestUser>
            {
                //admin user
                new TestUser
                {
                    SubjectId = "1",
                    Username = "admin",
                    Password = "Work.Together@12"
                }
            };
        }

        public static IEnumerable<IdentityResource> GetIdentityResources()
        {
            return new IdentityResource[]
            {
                new IdentityResources.OpenId(),
                new IdentityResources.Profile(),
            };
        }

        public static IEnumerable<ApiResource> GetApis()
        {
            return new List<ApiResource>
            {
                new ApiResource("catalogapi", "Catalog API"),
                new ApiResource("masterdataapi", "MasterData API"),
                new ApiResource("pricing_sim_api", "Pricing Simulation SPA")
            };
        }

        public static IEnumerable<Client> GetClients()
        {
            return new List<Client>
            {
                //postman (non-interactive)
                new Client
                {
                    ClientId = "postman_api_client",

                    AllowedGrantTypes = GrantTypes.ClientCredentials,
                    ClientSecrets =
                    {
                        new Secret("ado948b8cbqBFG78".Sha256())
                    },
                    AllowedScopes = { "catalogapi", "masterdataapi" }
                },

                // OpenID Connect hybrid flow client (MVC)
                new Client
                {
                    ClientId = "mvc",
                    ClientName = "MVC Client",
                    AllowedGrantTypes = GrantTypes.Hybrid,

                    ClientSecrets =
                    {
                        new Secret("ado948b8cbqBFG78".Sha256())
                    },

                    RedirectUris           = { "http://localhost:8005/signin-oidc", "http://g1w9448.austin.hpicorp.net:8005/signin-oidc" },
                    PostLogoutRedirectUris = { "http://localhost:8005/signout-callback-oidc", "http://g1w9448.austin.hpicorp.net:8005/signout-callback-oidc" },

                    AllowedScopes =
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        "catalogapi", "masterdataapi"
                    },

                    AllowOfflineAccess = true
                },

                // JavaScript Client
                new Client
                {
                    ClientId = "pricing_sim_client",
                    ClientName = "JavaScript Client",
                    AllowedGrantTypes = GrantTypes.Code,
                    RequirePkce = true,
                    RequireClientSecret = false,

                    RedirectUris =           { "http://localhost:4200/auth-callback" },
                    PostLogoutRedirectUris = { "http://localhost:4200/" },
                    AllowedCorsOrigins =     { "http://localhost:4200/" },

                    AllowedScopes =
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        "pricing_sim_api"
                    }
                },

                //catalogapi swagger
                new Client
                {
                    ClientId = "catalogapi_swagger",
                    ClientName = "CatalogApi Swagger UI",
                    AllowedGrantTypes = GrantTypes.Implicit,
                    AllowAccessTokensViaBrowser = true,

                    RedirectUris = { "http://localhost:8001/swagger/oauth2-redirect.html", "http://g1w9448.austin.hpicorp.net:8001/swagger/oauth2-redirect.html" },
                    PostLogoutRedirectUris = { "http://localhost:8001/swagger/", "http://g1w9448.austin.hpicorp.net:8001/swagger" },

                    AllowedScopes =
                    {
                        "catalogapi"
                    }
                },

                //masterdataapi swagger
                new Client
                {
                    ClientId = "masterdataapi_swagger",
                    ClientName = "MasterDataApi Swagger UI",
                    AllowedGrantTypes = GrantTypes.Implicit,
                    AllowAccessTokensViaBrowser = true,

                    RedirectUris = { "http://localhost:8002/swagger/oauth2-redirect.html", "http://g1w9448.austin.hpicorp.net:8002/swagger/oauth2-redirect.html" },
                    PostLogoutRedirectUris = { "http://localhost:8002/swagger/", "http://g1w9448.austin.hpicorp.net:8002/swagger/"},

                    AllowedScopes =
                    {
                        "masterdataapi"
                    }
                }
            };
        }
    }
}