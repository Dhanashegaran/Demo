﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class MasterDataContext : DbContext
    {
        public MasterDataContext()
        {
        }

        public MasterDataContext(DbContextOptions<MasterDataContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CfsGeographicModel> CfsGeographicModel { get; set; }
        public virtual DbSet<CfsTableMetadata> CfsTableMetadata { get; set; }
        public virtual DbSet<CpqBillingModels> CpqBillingModels { get; set; }
        public virtual DbSet<CpqBillingModelsByOfferByCountry> CpqBillingModelsByOfferByCountry { get; set; }
        public virtual DbSet<CpqCategoryPricingByOfferByCountry> CpqCategoryPricingByOfferByCountry { get; set; }
        public virtual DbSet<CpqCountry> CpqCountry { get; set; }
        public virtual DbSet<CpqDefaultBmByOfferByCountry> CpqDefaultBmByOfferByCountry { get; set; }
        public virtual DbSet<CpqDefaultHwffoByOfferByCountry> CpqDefaultHwffoByOfferByCountry { get; set; }
        public virtual DbSet<CpqDefaultHwpoByOfferByCountry> CpqDefaultHwpoByOfferByCountry { get; set; }
        public virtual DbSet<CpqDefaultKoByOfferByCountry> CpqDefaultKoByOfferByCountry { get; set; }
        public virtual DbSet<CpqDefaultMarginTemplateByOffer> CpqDefaultMarginTemplateByOffer { get; set; }
        public virtual DbSet<CpqDefaultSffoByOfferByCountry> CpqDefaultSffoByOfferByCountry { get; set; }
        public virtual DbSet<CpqDefaultSlaByOfferByCountry> CpqDefaultSlaByOfferByCountry { get; set; }
        public virtual DbSet<CpqHwFulfillmentOptions> CpqHwFulfillmentOptions { get; set; }
        public virtual DbSet<CpqHwFulfillmentOptionsByOfferByCountry> CpqHwFulfillmentOptionsByOfferByCountry { get; set; }
        public virtual DbSet<CpqHwPurchaseOptions> CpqHwPurchaseOptions { get; set; }
        public virtual DbSet<CpqHwPurchaseOptionsByOfferByCountry> CpqHwPurchaseOptionsByOfferByCountry { get; set; }
        public virtual DbSet<CpqKitOptions> CpqKitOptions { get; set; }
        public virtual DbSet<CpqKitOptionsByOfferByCountry> CpqKitOptionsByOfferByCountry { get; set; }
        public virtual DbSet<CpqLlcAttributesByOfferByCountry> CpqLlcAttributesByOfferByCountry { get; set; }
        public virtual DbSet<CpqLocalCostByOffer> CpqLocalCostByOffer { get; set; }
        public virtual DbSet<CpqLocalPriceByOffer> CpqLocalPriceByOffer { get; set; }
        public virtual DbSet<CpqMarginTargetsByOfferByCountry> CpqMarginTargetsByOfferByCountry { get; set; }
        public virtual DbSet<CpqMarginTemplateByOffer> CpqMarginTemplateByOffer { get; set; }
        public virtual DbSet<CpqMaxPriceByOfferByCountry> CpqMaxPriceByOfferByCountry { get; set; }
        public virtual DbSet<CpqMspByOfferByCountry> CpqMspByOfferByCountry { get; set; }
        public virtual DbSet<CpqPriceCostSourceByOfferByCountry> CpqPriceCostSourceByOfferByCountry { get; set; }
        public virtual DbSet<CpqPriceDescriptorByOfferByCountry> CpqPriceDescriptorByOfferByCountry { get; set; }
        public virtual DbSet<CpqPricingSimulationDetail> CpqPricingSimulationDetail { get; set; }
        public virtual DbSet<CpqPricingSimulationHeader> CpqPricingSimulationHeader { get; set; }
        public virtual DbSet<CpqPrinterAccessoryByOfferByCountry> CpqPrinterAccessoryByOfferByCountry { get; set; }
        public virtual DbSet<CpqPrinterByOfferByCountry> CpqPrinterByOfferByCountry { get; set; }
        public virtual DbSet<CpqPrinterClassAttributes> CpqPrinterClassAttributes { get; set; }
        public virtual DbSet<CpqPrinterClassAttributesByOfferByCountry> CpqPrinterClassAttributesByOfferByCountry { get; set; }
        public virtual DbSet<CpqPrinterLlcByOfferByCountry> CpqPrinterLlcByOfferByCountry { get; set; }
        public virtual DbSet<CpqPrinterServicePartByOfferByCountry> CpqPrinterServicePartByOfferByCountry { get; set; }
        public virtual DbSet<CpqPrinterStatusByOfferByCountry> CpqPrinterStatusByOfferByCountry { get; set; }
        public virtual DbSet<CpqPrinterSupplyByOfferByCountry> CpqPrinterSupplyByOfferByCountry { get; set; }
        public virtual DbSet<CpqPwSupplyAttributesByOfferByCountry> CpqPwSupplyAttributesByOfferByCountry { get; set; }
        public virtual DbSet<CpqRateTableByOfferByCountry> CpqRateTableByOfferByCountry { get; set; }
        public virtual DbSet<CpqServiceLevels> CpqServiceLevels { get; set; }
        public virtual DbSet<CpqServiceLevelsByOfferByCountry> CpqServiceLevelsByOfferByCountry { get; set; }
        public virtual DbSet<CpqServicePartAttributesByOfferByCountry> CpqServicePartAttributesByOfferByCountry { get; set; }
        public virtual DbSet<CpqServicePartPricingByOfferByCountry> CpqServicePartPricingByOfferByCountry { get; set; }
        public virtual DbSet<CpqStandardDiscountsByOfferByCountry> CpqStandardDiscountsByOfferByCountry { get; set; }
        public virtual DbSet<CpqSuppliesFulfillmentOptions> CpqSuppliesFulfillmentOptions { get; set; }
        public virtual DbSet<CpqSuppliesFulfillmentOptionsByOfferByCountry> CpqSuppliesFulfillmentOptionsByOfferByCountry { get; set; }
        public virtual DbSet<CpqSupplyAttributesByOfferByCountry> CpqSupplyAttributesByOfferByCountry { get; set; }
        public virtual DbSet<CpqSupplyProgramByOfferByCountry> CpqSupplyProgramByOfferByCountry { get; set; }
        public virtual DbSet<CpqTruckloadDiscountsByOfferByCountry> CpqTruckloadDiscountsByOfferByCountry { get; set; }
        public virtual DbSet<CpqVolumeDiscountsByOfferByCountry> CpqVolumeDiscountsByOfferByCountry { get; set; }
        public virtual DbSet<CtTable> CtTable { get; set; }
        public virtual DbSet<GpsyPrice> GpsyPrice { get; set; }
        public virtual DbSet<GtmCountry> GtmCountry { get; set; }
        public virtual DbSet<GtmOfferType> GtmOfferType { get; set; }
        public virtual DbSet<GtmOfferTypeByCountry> GtmOfferTypeByCountry { get; set; }
        public virtual DbSet<GtmRegion> GtmRegion { get; set; }
        public virtual DbSet<PlmConfigrableServices> PlmConfigrableServices { get; set; }
        public virtual DbSet<PlmCtoHwBom> PlmCtoHwBom { get; set; }
        public virtual DbSet<PlmFamily> PlmFamily { get; set; }
        public virtual DbSet<PlmFamilyHwAccessories> PlmFamilyHwAccessories { get; set; }
        public virtual DbSet<PlmLlcBom> PlmLlcBom { get; set; }
        public virtual DbSet<PlmModel> PlmModel { get; set; }
        public virtual DbSet<PlmMvModel> PlmMvModel { get; set; }
        public virtual DbSet<PlmPabHwBom> PlmPabHwBom { get; set; }
        public virtual DbSet<PlmPreconfiguredHwBom> PlmPreconfiguredHwBom { get; set; }
        public virtual DbSet<PlmPreconfiguredServices> PlmPreconfiguredServices { get; set; }
        public virtual DbSet<PlmSeries> PlmSeries { get; set; }
        public virtual DbSet<PlmServicePartBom> PlmServicePartBom { get; set; }
        public virtual DbSet<PlmSku> PlmSku { get; set; }
        public virtual DbSet<PlmSupplyBom> PlmSupplyBom { get; set; }
        public virtual DbSet<ScottTables> ScottTables { get; set; }
        public virtual DbSet<TreasuryCurrency> TreasuryCurrency { get; set; }
        public virtual DbSet<TreasuryCurrencyRate> TreasuryCurrencyRate { get; set; }
        public virtual DbSet<TreasuryCurrencyRateTable> TreasuryCurrencyRateTable { get; set; }

        // Unable to generate entity type for table 'dbo.someTempTable'. Please see the warning messages.

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                #warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                //optionsBuilder.UseSqlServer("Server=c1w26125.itcs.hpicorp.net;Database=hpcsfmaster;User Id=sa;Password = Work.Together@12;");

            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.1-servicing-10028");

            modelBuilder.Entity<CfsGeographicModel>(entity =>
            {
                entity.ToTable("CFS_GEOGRAPHIC_MODEL");

                entity.HasIndex(e => new { e.TableName, e.Mkey, e.MappedValue })
                    .HasName("UID_GEOGRAPHIC_MODEL_KEY")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ColumnName)
                    .IsRequired()
                    .HasColumnName("COLUMN_NAME")
                    .HasMaxLength(65)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.IsoKey)
                    .IsRequired()
                    .HasColumnName("ISO_KEY")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.MappedValue)
                    .IsRequired()
                    .HasColumnName("MAPPED_VALUE")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Mkey)
                    .IsRequired()
                    .HasColumnName("MKEY")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.TableName)
                    .IsRequired()
                    .HasColumnName("TABLE_NAME")
                    .HasMaxLength(65)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate).HasColumnType("datetime");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CfsTableMetadata>(entity =>
            {
                entity.ToTable("CFS_TABLE_METADATA");

                entity.HasIndex(e => e.TableName)
                    .HasName("UID_TABLE_METADATA_TABLENAME")
                    .IsUnique();

                entity.Property(e => e.DateFields)
                    .HasColumnName("DATE_FIELDS")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.KeyFields)
                    .HasColumnName("KEY_FIELDS")
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.RangeFields)
                    .HasColumnName("RANGE_FIELDS")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.TableName)
                    .IsRequired()
                    .HasColumnName("TABLE_NAME")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDttm)
                    .HasColumnName("UPDATE_DTTM")
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdateUser)
                    .HasColumnName("UPDATE_USER")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.WildcardFields)
                    .HasColumnName("WILDCARD_FIELDS")
                    .HasMaxLength(150)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqBillingModels>(entity =>
            {
                entity.ToTable("CPQ_BILLING_MODELS");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.BillingModel)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqBillingModelsByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_BILLING_MODELS_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.BillingModel)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqCategoryPricingByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_CATEGORY_PRICING_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_CATEGORY_PRICI");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Currency)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.NetPrice).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqCountry>(entity =>
            {
                entity.HasKey(e => e.IsoCountryCode)
                    .HasName("PK_CPQ_COUNTRY_ISO_COUNTRY_CODE");

                entity.ToTable("CPQ_COUNTRY");

                entity.Property(e => e.IsoCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.CpqCountryFlag)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<CpqDefaultBmByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_DEFAULT_BM_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.BillingModel)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqDefaultHwffoByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_DEFAULT_HWFFO_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.HwfulfillmentOption)
                    .HasColumnName("HWFulfillmentOption")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqDefaultHwpoByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_DEFAULT_HWPO_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.HwpurchaseOption)
                    .HasColumnName("HWPurchaseOption")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqDefaultKoByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_DEFAULT_KO_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.KitOption)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqDefaultMarginTemplateByOffer>(entity =>
            {
                entity.ToTable("CPQ_DEFAULT_MARGIN_TEMPLATE_BY_OFFER");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.MarginTemplate)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqDefaultSffoByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_DEFAULT_SFFO_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.SuppliesFulfillmentOption)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqDefaultSlaByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_DEFAULT_SLA_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sla)
                    .HasColumnName("SLA")
                    .HasMaxLength(16)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqHwFulfillmentOptions>(entity =>
            {
                entity.ToTable("CPQ_HW_FULFILLMENT_OPTIONS");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.HwfulfillmentChannel)
                    .HasColumnName("HWFulfillmentChannel")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.HwfulfillmentOption)
                    .HasColumnName("HWFulfillmentOption")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqHwFulfillmentOptionsByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_HW_FULFILLMENT_OPTIONS_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.HwfulfillmentOption)
                    .HasColumnName("HWFulfillmentOption")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqHwPurchaseOptions>(entity =>
            {
                entity.ToTable("CPQ_HW_PURCHASE_OPTIONS");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.HwpurchaseOption)
                    .HasColumnName("HWPurchaseOption")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqHwPurchaseOptionsByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_HW_PURCHASE_OPTIONS_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.HwpurchaseOption)
                    .HasColumnName("HWPurchaseOption")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqKitOptions>(entity =>
            {
                entity.ToTable("CPQ_KIT_OPTIONS");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.KitOption)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqKitOptionsByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_KIT_OPTIONS_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.KitOption)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqLlcAttributesByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_LLC_ATTRIBUTES_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.PrinterSku)
                    .HasName("idx_PrinterSKU_LLC_ATTRIBUTES");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_LLC_ATTRIBUTES");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ColorYield).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.MonoYield).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.PrinterSku)
                    .HasColumnName("PrinterSKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ProfessionalColorYield).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.PrinterSkuNavigation)
                    .WithMany(p => p.CpqLlcAttributesByOfferByCountry)
                    .HasForeignKey(d => d.PrinterSku)
                    .HasConstraintName("FK_LLC_ATTRIBUTES_PRN_SKU");
            });

            modelBuilder.Entity<CpqLocalCostByOffer>(entity =>
            {
                entity.ToTable("CPQ_LOCAL_COST_BY_OFFER");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_LOC");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Currency)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.EffEndDate).HasColumnType("datetime");

                entity.Property(e => e.EffStartDate).HasColumnType("datetime");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Tcos)
                    .HasColumnName("TCOS")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Vcos)
                    .HasColumnName("VCOS")
                    .HasColumnType("numeric(18, 0)");
            });

            modelBuilder.Entity<CpqLocalPriceByOffer>(entity =>
            {
                entity.ToTable("CPQ_LOCAL_PRICE_BY_OFFER");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_LOC");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EffEndDate).HasColumnType("datetime");

                entity.Property(e => e.EffStartDate).HasColumnType("datetime");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ListPrice).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.PriceDescriptor)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqMarginTargetsByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_MARGIN_TARGETS_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.PrinterSku)
                    .HasName("idx_PrinterSKU_MARGIN_TARGETS");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_MARGIN_TARGETS");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Class)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.MarginTemplate)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PrinterSku)
                    .HasColumnName("PrinterSKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ProductLine)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TargetMarginPct)
                    .HasColumnName("TargetMarginPCT")
                    .HasColumnType("numeric(10, 4)");

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqMarginTemplateByOffer>(entity =>
            {
                entity.ToTable("CPQ_MARGIN_TEMPLATE_BY_OFFER");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.MarginTemplate)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqMaxPriceByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_MAX_PRICE_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_MAX_PRICE_BY_O");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.MaxPricePct)
                    .HasColumnName("MaxPricePCT")
                    .HasColumnType("numeric(10, 4)");

                entity.Property(e => e.ProductLine)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqMspByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_MSP_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_MSP_BY_OFFER_B");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Msppct)
                    .HasColumnName("MSPPCT")
                    .HasColumnType("numeric(10, 4)");

                entity.Property(e => e.ProductLine)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqPriceCostSourceByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_PRICE_COST_SOURCE_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_PRICE_COST_SOU");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CostSource)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PriceSource)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqPriceDescriptorByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_PRICE_DESCRIPTOR_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DefaultFlag)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ItemClass)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PriceDescriptor)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqPricingSimulationDetail>(entity =>
            {
                entity.ToTable("CPQ_PRICING_SIMULATION_DETAIL");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasColumnName("CREATED_BY")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnName("CREATED_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.FieldName)
                    .HasColumnName("FIELD_NAME")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FieldSource)
                    .HasColumnName("FIELD_SOURCE")
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasColumnName("UPDATED_BY")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnName("UPDATED_DATE")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<CpqPricingSimulationHeader>(entity =>
            {
                entity.ToTable("CPQ_PRICING_SIMULATION_HEADER");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasColumnName("CREATED_BY")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnName("CREATED_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.FieldName)
                    .HasColumnName("FIELD_NAME")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FieldSource)
                    .HasColumnName("FIELD_SOURCE")
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasColumnName("UPDATED_BY")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnName("UPDATED_DATE")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<CpqPrinterAccessoryByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_PRINTER_ACCESSORY_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.PrinterSku)
                    .HasName("idx_PrinterSKU_PRINTER_ACCESS");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_PRINTER_ACCESS");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CpqaccessoryFlag)
                    .HasColumnName("CPQAccessoryFlag")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PrinterSku)
                    .HasColumnName("PrinterSKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.PrinterSkuNavigation)
                    .WithMany(p => p.CpqPrinterAccessoryByOfferByCountry)
                    .HasForeignKey(d => d.PrinterSku)
                    .HasConstraintName("FK_PRINTER_ACCESSORY_PRN_SKU");
            });

            modelBuilder.Entity<CpqPrinterByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_PRINTER_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_PRINTER_BY_OFF");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Cpqflag)
                    .HasColumnName("CPQFlag")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqPrinterClassAttributes>(entity =>
            {
                entity.ToTable("CPQ_PRINTER_CLASS_ATTRIBUTES");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_PRINTER_CLASS_ATTRIBUTES");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Adfcapacity)
                    .HasColumnName("ADFCapacity")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.ColorPrintSpeed).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.DuplexScanSpeed).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.EngineLife).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.IsA3)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.IsColor)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.IsFlow)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.IsInk)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.IsMfp)
                    .HasColumnName("IsMFP")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MonoPrintSpeed).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.Rmpv)
                    .HasColumnName("RMPV")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.ShortDescription)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SimplexScanSpeed).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TrayCapacity).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqPrinterClassAttributesByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_PRINTER_CLASS_ATTRIBUTES_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_PRINTER_CLASS_");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DefaultMonthlyColorPages).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.DefaultMonthlyColorSavePages).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.DefaultMonthlyMonoPages).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.DefaultMonthlyProfColorPages).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqPrinterLlcByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_PRINTER_LLC_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.PrinterSku)
                    .HasName("idx_PrinterSKU_PRINTER_LLC_BY");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_PRINTER_LLC_BY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Cpqflag)
                    .HasColumnName("CPQFlag")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PrinterSku)
                    .HasColumnName("PrinterSKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.PrinterSkuNavigation)
                    .WithMany(p => p.CpqPrinterLlcByOfferByCountry)
                    .HasForeignKey(d => d.PrinterSku)
                    .HasConstraintName("FK_PRINTER_LLC_BY_PRN_SKU");
            });

            modelBuilder.Entity<CpqPrinterServicePartByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_PRINTER_SERVICE_PART_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.PrinterSku)
                    .HasName("idx_PrinterSKU_PRINTER_SERVIC");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_PRINTER_SERVIC");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Cpqflag)
                    .HasColumnName("CPQFlag")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PrinterSku)
                    .HasColumnName("PrinterSKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.PrinterSkuNavigation)
                    .WithMany(p => p.CpqPrinterServicePartByOfferByCountry)
                    .HasForeignKey(d => d.PrinterSku)
                    .HasConstraintName("FK_PRINTER_SERVICE_PART_PRN_SKU");
            });

            modelBuilder.Entity<CpqPrinterStatusByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_PRINTER_STATUS_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_PRINTER_STATUS");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Ibodate)
                    .HasColumnName("IBODate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Ibxdate)
                    .HasColumnName("IBXDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Npidate)
                    .HasColumnName("NPIDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.ProductStatus)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Stddate)
                    .HasColumnName("STDDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqPrinterSupplyByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_PRINTER_SUPPLY_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.PrinterSku)
                    .HasName("idx_PrinterSKU_PRINTER_SUPPLY");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_PRINTER_SUPPLY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CpqsupplyFlag)
                    .HasColumnName("CPQSupplyFlag")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PrinterSku)
                    .HasColumnName("PrinterSKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.PrinterSkuNavigation)
                    .WithMany(p => p.CpqPrinterSupplyByOfferByCountry)
                    .HasForeignKey(d => d.PrinterSku)
                    .HasConstraintName("FK_PRINTER_SUPPLY_PRN_SKU");
            });

            modelBuilder.Entity<CpqPwSupplyAttributesByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_PW_SUPPLY_ATTRIBUTES_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.PrinterSku)
                    .HasName("idx_PrinterSKU_PW_SUPPLY_ATTR");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_PW_SUPPLY_ATTR");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ColorSaveReductionPct)
                    .HasColumnName("ColorSaveReductionPCT")
                    .HasColumnType("numeric(10, 4)");

                entity.Property(e => e.CostRatioColor).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.CostRatioMono).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CustomerAvailableInk).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.GeneralOfficeReductionPct)
                    .HasColumnName("GeneralOfficeReductionPCT")
                    .HasColumnType("numeric(10, 4)");

                entity.Property(e => e.InkPerPage).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.MaintInkIntercept).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.MaintInkLowVolIntercept).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.MaintInkLowVolSlope).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.MaintInkLowVolumeThreshold).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.MaintInklSlope).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.PrinterSku)
                    .HasColumnName("PrinterSKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.PrinterSkuNavigation)
                    .WithMany(p => p.CpqPwSupplyAttributesByOfferByCountry)
                    .HasForeignKey(d => d.PrinterSku)
                    .HasConstraintName("FK_PW_SUPPLY_ATTR_PRN_SKU");
            });

            modelBuilder.Entity<CpqRateTableByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_RATE_TABLE_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.RateTable)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqServiceLevels>(entity =>
            {
                entity.ToTable("CPQ_SERVICE_LEVELS");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Sla)
                    .HasColumnName("SLA")
                    .HasMaxLength(16)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqServiceLevelsByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_SERVICE_LEVELS_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sla)
                    .HasColumnName("SLA")
                    .HasMaxLength(16)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqServicePartAttributesByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_SERVICE_PART_ATTRIBUTES_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.PrinterSku)
                    .HasName("idx_PrinterSKU_SERVICE_PART_A");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_SERVICE_PART_A");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Air)
                    .HasColumnName("AIR")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PrinterSku)
                    .HasColumnName("PrinterSKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.PrinterSkuNavigation)
                    .WithMany(p => p.CpqServicePartAttributesByOfferByCountry)
                    .HasForeignKey(d => d.PrinterSku)
                    .HasConstraintName("FK_SERVICE_PART_A_PRN_SKU");
            });

            modelBuilder.Entity<CpqServicePartPricingByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_SERVICE_PART_PRICING_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_SERVICE_PART_P");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Currency)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.Discount).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ListPrice).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.UseLlcpriceFlag)
                    .HasColumnName("UseLLCPriceFlag")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.WarrantyCredit).HasColumnType("numeric(18, 0)");
            });

            modelBuilder.Entity<CpqStandardDiscountsByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_STANDARD_DISCOUNTS_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_STANDARD_DISCO");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ProductLine)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.StandardDiscountPct)
                    .HasColumnName("StandardDiscountPCT")
                    .HasColumnType("numeric(10, 4)");

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqSuppliesFulfillmentOptions>(entity =>
            {
                entity.ToTable("CPQ_SUPPLIES_FULFILLMENT_OPTIONS");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.SuppliesFulfillmentChannel)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.SuppliesFulfillmentOption)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqSuppliesFulfillmentOptionsByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_SUPPLIES_FULFILLMENT_OPTIONS_BY_OFFER_BY_COUNTRY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.SuppliesFulfillmentOption)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqSupplyAttributesByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_SUPPLY_ATTRIBUTES_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.PrinterSku)
                    .HasName("idx_PrinterSKU_SUPPLY_ATTRIBU");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_SUPPLY_ATTRIBU");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IsocolorSaveYield)
                    .HasColumnName("ISOColorSaveYield")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.IsocolorYield)
                    .HasColumnName("ISOColorYield")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.IsocoveragePct)
                    .HasColumnName("ISOCoveragePCT")
                    .HasColumnType("numeric(10, 4)");

                entity.Property(e => e.IsomonoYield)
                    .HasColumnName("ISOMonoYield")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.IsoprofessionalColorYield)
                    .HasColumnName("ISOProfessionalColorYield")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.OperationalYieldCalcMethod)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PrinterSku)
                    .HasColumnName("PrinterSKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.StarterColorSaveYield).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.StarterColorYield).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.StarterMonoYield).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.StarterProfessionalColorYield).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.PrinterSkuNavigation)
                    .WithMany(p => p.CpqSupplyAttributesByOfferByCountry)
                    .HasForeignKey(d => d.PrinterSku)
                    .HasConstraintName("FK_SUPPLY_ATTRIBU_PRN_SKU");
            });

            modelBuilder.Entity<CpqSupplyProgramByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_SUPPLY_PROGRAM_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.PrinterSku)
                    .HasName("idx_PrinterSKU_SUPPLY_PROGRAM");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_SUPPLY_PROGRAM");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PrinterSku)
                    .HasColumnName("PrinterSKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ProgramColorYield).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.ProgramMonoYield).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.ProgramProfessionalColorYield).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SupplyProgram)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.PrinterSkuNavigation)
                    .WithMany(p => p.CpqSupplyProgramByOfferByCountry)
                    .HasForeignKey(d => d.PrinterSku)
                    .HasConstraintName("FK_SUPPLY_PROGRAM_PRN_SKU");
            });

            modelBuilder.Entity<CpqTruckloadDiscountsByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_TRUCKLOAD_DISCOUNTS_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_TRUCKLOAD_DISC");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ProductLine)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TruckloadDiscountPct)
                    .HasColumnName("TruckloadDiscountPCT")
                    .HasColumnType("numeric(10, 4)");

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CpqVolumeDiscountsByOfferByCountry>(entity =>
            {
                entity.ToTable("CPQ_VOLUME_DISCOUNTS_BY_OFFER_BY_COUNTRY");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_VOLUME_DISCOUN");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ProductLine)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Tier1Pct)
                    .HasColumnName("Tier1PCT")
                    .HasColumnType("numeric(10, 4)");

                entity.Property(e => e.Tier2Pct)
                    .HasColumnName("Tier2PCT")
                    .HasColumnType("numeric(10, 4)");

                entity.Property(e => e.Tier3Pct)
                    .HasColumnName("Tier3PCT")
                    .HasColumnType("numeric(10, 4)");

                entity.Property(e => e.Tier4Pct)
                    .HasColumnName("Tier4PCT")
                    .HasColumnType("numeric(10, 4)");

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CtTable>(entity =>
            {
                entity.ToTable("ct_table");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ColumnCharid)
                    .HasColumnName("column_charid")
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ColumnId).HasColumnName("column_id");

                entity.Property(e => e.ColumnName)
                    .HasColumnName("column_name")
                    .HasMaxLength(33)
                    .IsUnicode(false);

                entity.Property(e => e.DataType)
                    .HasColumnName("data_type")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.IsIdentity).HasColumnName("is_identity");

                entity.Property(e => e.IsNullable).HasColumnName("is_nullable");

                entity.Property(e => e.MaxLength).HasColumnName("max_length");

                entity.Property(e => e.Precision).HasColumnName("precision");

                entity.Property(e => e.Scale).HasColumnName("scale");

                entity.Property(e => e.TableName)
                    .HasColumnName("table_name")
                    .HasMaxLength(63)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<GpsyPrice>(entity =>
            {
                entity.ToTable("GPSY_PRICE");

                entity.HasIndex(e => e.ProdBase)
                    .HasName("UID_GPSY_PROD_BASE");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CalcRefPrcAmt)
                    .HasColumnName("CALC_REF_PRC_AMT")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.CtryCd)
                    .HasColumnName("CTRY_CD")
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.CurrCd)
                    .HasColumnName("CURR_CD")
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.EndDtCd)
                    .HasColumnName("END_DT_CD")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.EndEffDt)
                    .HasColumnName("END_EFF_DT")
                    .HasColumnType("date");

                entity.Property(e => e.LastModTmstmp)
                    .HasColumnName("LAST_MOD_TMSTMP")
                    .HasColumnType("date");

                entity.Property(e => e.Lclp)
                    .HasColumnName("LCLP")
                    .HasColumnType("numeric(18, 6)");

                entity.Property(e => e.Opt)
                    .HasColumnName("OPT")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PrcMethCd)
                    .HasColumnName("PRC_METH_CD")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.PrcTermCd)
                    .HasColumnName("PRC_TERM_CD")
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.ProcessNm)
                    .HasColumnName("PROCESS_NM")
                    .HasMaxLength(24)
                    .IsUnicode(false);

                entity.Property(e => e.ProdBase)
                    .HasColumnName("PROD_BASE")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ProdNbr)
                    .HasColumnName("PROD_NBR")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.QbSetNbr)
                    .HasColumnName("QB_SET_NBR")
                    .HasColumnType("numeric(4, 0)");

                entity.Property(e => e.QblSeqNbr)
                    .HasColumnName("QBL_SEQ_NBR")
                    .HasColumnType("numeric(2, 0)");

                entity.Property(e => e.StartEffDt)
                    .HasColumnName("START_EFF_DT")
                    .HasColumnType("date");

                entity.Property(e => e.UserLogonId)
                    .HasColumnName("USER_LOGON_ID")
                    .HasMaxLength(24)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<GtmCountry>(entity =>
            {
                entity.HasKey(e => e.CountryCode);

                entity.ToTable("GTM_COUNTRY");

                entity.HasIndex(e => e.CountryCode)
                    .HasName("UID_GTM_COUNTRY_COUNTRY")
                    .IsUnique();

                entity.HasIndex(e => e.IsoCountryCode)
                    .HasName("UID_GTM_COUNTRY_ISO");

                entity.Property(e => e.CountryCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.CountryName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsoCountryCode)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.RegionCode)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.IsoCountryCodeNavigation)
                    .WithMany(p => p.GtmCountry)
                    .HasForeignKey(d => d.IsoCountryCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GTM_COUNTRY_IsoCountryCode");

                entity.HasOne(d => d.RegionCodeNavigation)
                    .WithMany(p => p.GtmCountry)
                    .HasForeignKey(d => d.RegionCode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_GTM_COUNTRY_RegionCode");
            });

            modelBuilder.Entity<GtmOfferType>(entity =>
            {
                entity.ToTable("GTM_OFFER_TYPE");

                entity.HasIndex(e => new { e.L1offerType, e.L2offerType })
                    .HasName("UID_OFFER_TYPE")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<GtmOfferTypeByCountry>(entity =>
            {
                entity.ToTable("gtm_offer_type_by_country");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsoCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.RegionCode)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<GtmRegion>(entity =>
            {
                entity.HasKey(e => e.RegionCode);

                entity.ToTable("GTM_REGION");

                entity.HasIndex(e => e.RegionCode)
                    .HasName("UID_REGION")
                    .IsUnique();

                entity.Property(e => e.RegionCode)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.RegionName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<PlmConfigrableServices>(entity =>
            {
                entity.ToTable("PLM_CONFIGRABLE_SERVICES");

                entity.HasIndex(e => e.PrinterSku)
                    .HasName("idx_PrinterSKU_CONFIGRABLE_SERVICES");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_CONFIGRABLE_SERVICES");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Cpqflag)
                    .HasColumnName("CPQFlag")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DeliverableCode)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ModifierCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ModifierValue).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.PrinterSku)
                    .HasColumnName("PrinterSKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.PrinterSkuNavigation)
                    .WithMany(p => p.PlmConfigrableServices)
                    .HasForeignKey(d => d.PrinterSku)
                    .HasConstraintName("FK_CONFIGRABLE_SERVICES_PRN_SKU");
            });

            modelBuilder.Entity<PlmCtoHwBom>(entity =>
            {
                entity.ToTable("PLM_CTO_HW_BOM");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_CTO_HW_BOM");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FeatureType)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.FeatureValue)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PlmFamily>(entity =>
            {
                entity.ToTable("PLM_FAMILY");

                entity.HasIndex(e => e.Family)
                    .HasName("UID_Family")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LabName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<PlmFamilyHwAccessories>(entity =>
            {
                entity.ToTable("PLM_FAMILY_HW_ACCESSORIES");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_FAMILY_HW_ACCESSORIES");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FeatureType)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.FeatureValue)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PlmLlcBom>(entity =>
            {
                entity.ToTable("PLM_LLC_BOM");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_LLC_BOM");

                entity.HasIndex(e => new { e.Sku, e.Family })
                    .HasName("UID_PLM_LLC_BOM")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PlmModel>(entity =>
            {
                entity.ToTable("PLM_MODEL");

                entity.HasIndex(e => e.Model)
                    .HasName("UID_PLM_MODEL")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Model)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Series)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SeriesId).HasColumnName("series_id");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.SeriesNavigation)
                    .WithMany(p => p.PlmModel)
                    .HasForeignKey(d => d.SeriesId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PLM_MODEL_Series");
            });

            modelBuilder.Entity<PlmMvModel>(entity =>
            {
                entity.ToTable("PLM_MV_MODEL");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ComparableHpSeries)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Make)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.Model)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<PlmPabHwBom>(entity =>
            {
                entity.ToTable("PLM_PAB_HW_BOM");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_PAB_HW_BOM");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FeatureType)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.FeatureValue)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PlmPreconfiguredHwBom>(entity =>
            {
                entity.ToTable("PLM_PRECONFIGURED_HW_BOM");

                entity.HasIndex(e => e.PrinterSku)
                    .HasName("idx_PrinterSKU_PRECONFIGURED_HW_BOM");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_PRECONFIGURED_HW_BOM");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FeatureType)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.FeatureValue)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PrinterSku)
                    .HasColumnName("PrinterSKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.PrinterSkuNavigation)
                    .WithMany(p => p.PlmPreconfiguredHwBom)
                    .HasForeignKey(d => d.PrinterSku)
                    .HasConstraintName("FK_PRECONFIGURED_HW_BOM_PRN_SKU");
            });

            modelBuilder.Entity<PlmPreconfiguredServices>(entity =>
            {
                entity.ToTable("PLM_PRECONFIGURED_SERVICES");

                entity.HasIndex(e => e.PrinterSku)
                    .HasName("idx_PrinterSKU_PRECONFIGURED_SERVICES");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_PRECONFIGURED_SERVICES");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Cpqflag)
                    .HasColumnName("CPQFlag")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DeliverableCode)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.L1offerType)
                    .HasColumnName("L1OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.L2offerType)
                    .HasColumnName("L2OfferType")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ModifierCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ModifierValue).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.PrinterSku)
                    .HasColumnName("PrinterSKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Region)
                    .HasMaxLength(22)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PlmSeries>(entity =>
            {
                entity.ToTable("PLM_SERIES");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FamilyId).HasColumnName("family_id");

                entity.Property(e => e.Series)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.FamilyNavigation)
                    .WithMany(p => p.PlmSeries)
                    .HasForeignKey(d => d.FamilyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PLM_SERIES_Family");
            });

            modelBuilder.Entity<PlmServicePartBom>(entity =>
            {
                entity.ToTable("PLM_SERVICE_PART_BOM");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_SERVICE_PART_BOM");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PlmSku>(entity =>
            {
                entity.HasKey(e => e.Sku);

                entity.ToTable("PLM_SKU");

                entity.Property(e => e.Sku)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Model)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ModelId).HasColumnName("model_id");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.ModelNavigation)
                    .WithMany(p => p.PlmSku)
                    .HasForeignKey(d => d.ModelId)
                    .HasConstraintName("FK_PLM_SKU_MODEL");
            });

            modelBuilder.Entity<PlmSupplyBom>(entity =>
            {
                entity.ToTable("PLM_SUPPLY_BOM");

                entity.HasIndex(e => e.Sku)
                    .HasName("idx_SKU_SUPPLY_BOM");

                entity.HasIndex(e => new { e.Sku, e.Family })
                    .HasName("UID_PLM_SUPPLY_BOM")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Family)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Sku)
                    .HasColumnName("SKU")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SupplyColorType)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.SupplyLoadType)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.SupplyType)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ScottTables>(entity =>
            {
                entity.ToTable("scott_tables");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ColumnCharid)
                    .HasColumnName("column_charid")
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ColumnId).HasColumnName("column_id");

                entity.Property(e => e.ColumnName)
                    .HasColumnName("column_name")
                    .HasMaxLength(33)
                    .IsUnicode(false);

                entity.Property(e => e.DataType)
                    .HasColumnName("data_type")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.IsIdentity).HasColumnName("is_identity");

                entity.Property(e => e.IsNullable).HasColumnName("is_nullable");

                entity.Property(e => e.MaxLength).HasColumnName("max_length");

                entity.Property(e => e.Precision).HasColumnName("precision");

                entity.Property(e => e.Scale).HasColumnName("scale");

                entity.Property(e => e.TableName)
                    .HasColumnName("table_name")
                    .HasMaxLength(63)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TreasuryCurrency>(entity =>
            {
                entity.ToTable("TREASURY_CURRENCY");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Description)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Iso2currencyCode)
                    .HasColumnName("ISO2CurrencyCode")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Iso3currencyCode)
                    .HasColumnName("ISO3CurrencyCode")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.NumDecimals).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TreasuryCurrencyRate>(entity =>
            {
                entity.ToTable("TREASURY_CURRENCY_RATE");

                entity.HasIndex(e => e.Iso2currencyCode)
                    .HasName("UID_TREASURY_CURRENCY_RATE")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CurrencyRate)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.EffEndDate).HasColumnType("datetime");

                entity.Property(e => e.EffStartDate).HasColumnType("datetime");

                entity.Property(e => e.Iso2currencyCode)
                    .HasColumnName("ISO2CurrencyCode")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.ProductLine)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.RateTable)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TreasuryCurrencyRateTable>(entity =>
            {
                entity.ToTable("TREASURY_CURRENCY_RATE_TABLE");

                entity.HasIndex(e => e.RateTable)
                    .HasName("UID_TREASURY_CURRENCY_RATE_TABLE")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CreatedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.RateTable)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });
        }
    }
}
