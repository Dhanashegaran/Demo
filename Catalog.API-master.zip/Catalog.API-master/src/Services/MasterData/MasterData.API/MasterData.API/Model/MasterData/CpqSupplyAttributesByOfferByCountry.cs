﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class CpqSupplyAttributesByOfferByCountry
    {
        public long Id { get; set; }
        public string Family { get; set; }
        public string Sku { get; set; }
        public string L1offerType { get; set; }
        public string L2offerType { get; set; }
        public string Region { get; set; }
        public string Country { get; set; }
        public string PrinterSku { get; set; }
        public decimal? IsomonoYield { get; set; }
        public decimal? IsocolorYield { get; set; }
        public decimal? IsoprofessionalColorYield { get; set; }
        public decimal? IsocoveragePct { get; set; }
        public decimal? StarterMonoYield { get; set; }
        public decimal? StarterColorYield { get; set; }
        public decimal? StarterProfessionalColorYield { get; set; }
        public decimal? StarterColorSaveYield { get; set; }
        public string OperationalYieldCalcMethod { get; set; }
        public decimal? IsocolorSaveYield { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdateDate { get; set; }

        public virtual PlmSku PrinterSkuNavigation { get; set; }
    }
}
