﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class PlmSeries
    {
        public PlmSeries()
        {
            PlmModel = new HashSet<PlmModel>();
        }

        public long Id { get; set; }
        public string Family { get; set; }
        public string Series { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public long FamilyId { get; set; }

        public virtual PlmFamily FamilyNavigation { get; set; }
        public virtual ICollection<PlmModel> PlmModel { get; set; }
    }
}
