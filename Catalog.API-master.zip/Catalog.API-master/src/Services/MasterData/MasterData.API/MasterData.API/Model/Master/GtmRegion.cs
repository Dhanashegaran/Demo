﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class GtmRegion
    {
        public GtmRegion()
        {
            GtmCountry = new HashSet<GtmCountry>();
        }

        public string Regioncode { get; set; }
        public string Regionname { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }
        public long Id { get; set; }

        public virtual ICollection<GtmCountry> GtmCountry { get; set; }
    }
}
