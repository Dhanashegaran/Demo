﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class CpqHwFulfillmentOptions
    {
        public long Id { get; set; }
        public string Hwfulfillmentoption { get; set; }
        public string Hwfulfillmentchannel { get; set; }
        public string Description { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }
    }
}
