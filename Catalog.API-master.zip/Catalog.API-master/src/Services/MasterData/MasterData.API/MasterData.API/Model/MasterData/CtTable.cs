﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class CtTable
    {
        public long Id { get; set; }
        public string TableName { get; set; }
        public string ColumnName { get; set; }
        public string ColumnCharid { get; set; }
        public int? ColumnId { get; set; }
        public string DataType { get; set; }
        public int? MaxLength { get; set; }
        public int? Precision { get; set; }
        public int? Scale { get; set; }
        public int? IsNullable { get; set; }
        public int? IsIdentity { get; set; }
    }
}
