﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class CpqPwSupplyAttributesByOfferByCountry
    {
        public long Id { get; set; }
        public string Sku { get; set; }
        public string L1offertype { get; set; }
        public string L2offertype { get; set; }
        public string Region { get; set; }
        public string Country { get; set; }
        public string Printersku { get; set; }
        public decimal? Customeravailableink { get; set; }
        public decimal? Inkperpage { get; set; }
        public decimal? Generalofficereductionpct { get; set; }
        public decimal? Colorsavereductionpct { get; set; }
        public decimal? Maintinklowvolslope { get; set; }
        public decimal? Maintinklowvolintercept { get; set; }
        public decimal? Maintinklslope { get; set; }
        public decimal? Maintinkintercept { get; set; }
        public decimal? Maintinklowvolumethreshold { get; set; }
        public decimal? Costratiomono { get; set; }
        public decimal? Costratiocolor { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }

        public virtual PlmSku PrinterskuNavigation { get; set; }
    }
}
