﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class GpsyPrice
    {
        public long Id { get; set; }
        public string ProdBase { get; set; }
        public string Opt { get; set; }
        public string ProdNbr { get; set; }
        public string CtryCd { get; set; }
        public string CurrCd { get; set; }
        public string PrcTermCd { get; set; }
        public decimal? QbSetNbr { get; set; }
        public decimal? QblSeqNbr { get; set; }
        public DateTime? StartEffDt { get; set; }
        public decimal? Lclp { get; set; }
        public string UserLogonId { get; set; }
        public string ProcessNm { get; set; }
        public DateTime? LastModTmstmp { get; set; }
        public DateTime? EndEffDt { get; set; }
        public string EndDtCd { get; set; }
        public string PrcMethCd { get; set; }
        public decimal? CalcRefPrcAmt { get; set; }
    }
}
