﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class plm_series
    {
        public plm_series()
        {
            plm_model = new HashSet<plm_model>();
        }

        public long id { get; set; }
        public string family { get; set; }
        public string series { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
        public long family_id { get; set; }

        public virtual plm_family familyNavigation { get; set; }
        public virtual ICollection<plm_model> plm_model { get; set; }
    }
}
