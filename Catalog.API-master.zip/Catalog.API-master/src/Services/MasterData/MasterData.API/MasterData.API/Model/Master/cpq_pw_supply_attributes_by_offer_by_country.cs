﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class cpq_pw_supply_attributes_by_offer_by_country
    {
        public long id { get; set; }
        public string sku { get; set; }
        public string l1offertype { get; set; }
        public string l2offertype { get; set; }
        public string region { get; set; }
        public string country { get; set; }
        public string printersku { get; set; }
        public decimal? customeravailableink { get; set; }
        public decimal? inkperpage { get; set; }
        public decimal? generalofficereductionpct { get; set; }
        public decimal? colorsavereductionpct { get; set; }
        public decimal? maintinklowvolslope { get; set; }
        public decimal? maintinklowvolintercept { get; set; }
        public decimal? maintinklslope { get; set; }
        public decimal? maintinkintercept { get; set; }
        public decimal? maintinklowvolumethreshold { get; set; }
        public decimal? costratiomono { get; set; }
        public decimal? costratiocolor { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }

        public virtual plm_sku printerskuNavigation { get; set; }
    }
}
