﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class plm_supply_bom
    {
        public long id { get; set; }
        public string family { get; set; }
        public string sku { get; set; }
        public string description { get; set; }
        public string supplytype { get; set; }
        public string supplyloadtype { get; set; }
        public string supplycolortype { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
    }
}
