﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class CpqCountry
    {
        public CpqCountry()
        {
            GtmCountry = new HashSet<GtmCountry>();
        }

        public string Isocountrycode { get; set; }
        public string Cpqcountryflag { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }

        public virtual ICollection<GtmCountry> GtmCountry { get; set; }
    }
}
