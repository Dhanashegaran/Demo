﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class plm_model
    {
        public long id { get; set; }
        public string series { get; set; }
        public string model { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
        public long series_id { get; set; }

        public virtual plm_series series_ { get; set; }
    }
}
