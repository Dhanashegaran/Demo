﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class CpqSupplyAttributesByOfferByCountry
    {
        public long Id { get; set; }
        public string Family { get; set; }
        public string Sku { get; set; }
        public string L1offertype { get; set; }
        public string L2offertype { get; set; }
        public string Region { get; set; }
        public string Country { get; set; }
        public string Printersku { get; set; }
        public decimal? Isomonoyield { get; set; }
        public decimal? Isocoloryield { get; set; }
        public decimal? Isoprofessionalcoloryield { get; set; }
        public decimal? Isocoveragepct { get; set; }
        public decimal? Startermonoyield { get; set; }
        public decimal? Startercoloryield { get; set; }
        public decimal? Starterprofessionalcoloryield { get; set; }
        public decimal? Startercolorsaveyield { get; set; }
        public string Operationalyieldcalcmethod { get; set; }
        public decimal? Isocolorsaveyield { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }

        public virtual PlmSku PrinterskuNavigation { get; set; }
    }
}
