﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class GtmCountry
    {
        public string Regioncode { get; set; }
        public string Isocountrycode { get; set; }
        public string Countrycode { get; set; }
        public string Countryname { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }

        public virtual CpqCountry IsocountrycodeNavigation { get; set; }
        public virtual GtmRegion RegioncodeNavigation { get; set; }
    }
}
