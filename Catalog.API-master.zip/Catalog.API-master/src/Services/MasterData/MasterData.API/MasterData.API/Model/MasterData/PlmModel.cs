﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class PlmModel
    {
        public PlmModel()
        {
            PlmSku = new HashSet<PlmSku>();
        }

        public long Id { get; set; }
        public string Series { get; set; }
        public string Model { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public long SeriesId { get; set; }

        public virtual PlmSeries SeriesNavigation { get; set; }
        public virtual ICollection<PlmSku> PlmSku { get; set; }
    }
}
