﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class CpqCountry
    {
        public CpqCountry()
        {
            GtmCountry = new HashSet<GtmCountry>();
        }

        public string IsoCountryCode { get; set; }
        public string CpqCountryFlag { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual ICollection<GtmCountry> GtmCountry { get; set; }
    }
}
