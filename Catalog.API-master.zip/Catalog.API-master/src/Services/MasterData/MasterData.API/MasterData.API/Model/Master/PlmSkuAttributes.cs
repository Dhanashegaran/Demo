﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class PlmSkuAttributes
    {
        public string Sku { get; set; }
        public string Description { get; set; }
        public string Productline { get; set; }
        public string Statuscode { get; set; }
        public string Warrantycode { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }
    }
}
