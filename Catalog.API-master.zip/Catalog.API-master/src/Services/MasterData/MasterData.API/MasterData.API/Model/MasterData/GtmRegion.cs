﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class GtmRegion
    {
        public GtmRegion()
        {
            GtmCountry = new HashSet<GtmCountry>();
        }

        public string RegionCode { get; set; }
        public string RegionName { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public long Id { get; set; }

        public virtual ICollection<GtmCountry> GtmCountry { get; set; }
    }
}
