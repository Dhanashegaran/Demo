﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class CpqLocalPriceByOffer
    {
        public long Id { get; set; }
        public string Sku { get; set; }
        public string L1offerType { get; set; }
        public string L2offerType { get; set; }
        public string PriceDescriptor { get; set; }
        public decimal? ListPrice { get; set; }
        public DateTime? EffStartDate { get; set; }
        public DateTime? EffEndDate { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdateDate { get; set; }
    }
}
