﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class CpqVolumeDiscountsByOfferByCountry
    {
        public long Id { get; set; }
        public string Sku { get; set; }
        public string Productline { get; set; }
        public string L1offertype { get; set; }
        public string L2offertype { get; set; }
        public string Region { get; set; }
        public string Country { get; set; }
        public decimal? Tier1pct { get; set; }
        public decimal? Tier2pct { get; set; }
        public decimal? Tier3pct { get; set; }
        public decimal? Tier4pct { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }
    }
}
