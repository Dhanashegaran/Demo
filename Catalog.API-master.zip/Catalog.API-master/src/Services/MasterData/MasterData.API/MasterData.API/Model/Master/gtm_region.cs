﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class gtm_region
    {
        public gtm_region()
        {
            gtm_country = new HashSet<gtm_country>();
        }

        public string regioncode { get; set; }
        public string regionname { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
        public long id { get; set; }

        public virtual ICollection<gtm_country> gtm_country { get; set; }
    }
}
