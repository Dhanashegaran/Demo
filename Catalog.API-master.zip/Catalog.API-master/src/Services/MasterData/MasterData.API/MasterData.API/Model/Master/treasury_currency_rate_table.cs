﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class treasury_currency_rate_table
    {
        public long id { get; set; }
        public string ratetable { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
    }
}
