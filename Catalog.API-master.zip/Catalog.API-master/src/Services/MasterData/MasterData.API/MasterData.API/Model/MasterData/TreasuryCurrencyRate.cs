﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class TreasuryCurrencyRate
    {
        public long Id { get; set; }
        public string RateTable { get; set; }
        public string Iso2currencyCode { get; set; }
        public string ProductLine { get; set; }
        public string CurrencyRate { get; set; }
        public DateTime? EffStartDate { get; set; }
        public DateTime? EffEndDate { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdateDate { get; set; }
    }
}
