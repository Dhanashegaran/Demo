﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class plm_preconfigured_hw_bom
    {
        public long id { get; set; }
        public string printersku { get; set; }
        public string featuretype { get; set; }
        public string featurevalue { get; set; }
        public string sku { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }

        public virtual plm_sku printerskuNavigation { get; set; }
    }
}
