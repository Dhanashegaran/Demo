﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class PlmSupplyBom
    {
        public long Id { get; set; }
        public string Family { get; set; }
        public string Sku { get; set; }
        public string Description { get; set; }
        public string SupplyType { get; set; }
        public string SupplyLoadType { get; set; }
        public string SupplyColorType { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdateDate { get; set; }
    }
}
