﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class CfsGeographicModel
    {
        public long Id { get; set; }
        public string TableName { get; set; }
        public string ColumnName { get; set; }
        public string Mkey { get; set; }
        public string MappedValue { get; set; }
        public string IsoKey { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdateDate { get; set; }
    }
}
