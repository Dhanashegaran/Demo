﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class gtm_item_class
    {
        public string itemclass { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
    }
}
