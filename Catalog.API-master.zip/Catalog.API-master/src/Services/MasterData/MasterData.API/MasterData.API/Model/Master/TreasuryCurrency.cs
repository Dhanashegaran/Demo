﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class TreasuryCurrency
    {
        public long Id { get; set; }
        public string Iso2currencycode { get; set; }
        public string Iso3currencycode { get; set; }
        public string Description { get; set; }
        public decimal? Numdecimals { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }
    }
}
