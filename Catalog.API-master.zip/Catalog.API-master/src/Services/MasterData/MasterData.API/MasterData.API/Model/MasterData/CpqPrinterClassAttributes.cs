﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class CpqPrinterClassAttributes
    {
        public long Id { get; set; }
        public string Sku { get; set; }
        public string Description { get; set; }
        public string ShortDescription { get; set; }
        public string IsColor { get; set; }
        public string IsMfp { get; set; }
        public string IsA3 { get; set; }
        public string IsInk { get; set; }
        public string IsFlow { get; set; }
        public decimal? MonoPrintSpeed { get; set; }
        public decimal? ColorPrintSpeed { get; set; }
        public decimal? SimplexScanSpeed { get; set; }
        public decimal? DuplexScanSpeed { get; set; }
        public decimal? TrayCapacity { get; set; }
        public decimal? Adfcapacity { get; set; }
        public decimal? Rmpv { get; set; }
        public decimal? EngineLife { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdateDate { get; set; }
    }
}
