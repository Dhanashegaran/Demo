﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class plm_sku_attributes
    {
        public string sku { get; set; }
        public string description { get; set; }
        public string productline { get; set; }
        public string statuscode { get; set; }
        public string warrantycode { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
    }
}
