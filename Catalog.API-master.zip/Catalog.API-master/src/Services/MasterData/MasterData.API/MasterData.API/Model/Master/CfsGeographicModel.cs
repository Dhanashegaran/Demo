﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class CfsGeographicModel
    {
        public long Id { get; set; }
        public string TableName { get; set; }
        public string ColumnName { get; set; }
        public string Mkey { get; set; }
        public string MappedValue { get; set; }
        public string IsoKey { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updatedate { get; set; }
    }
}
