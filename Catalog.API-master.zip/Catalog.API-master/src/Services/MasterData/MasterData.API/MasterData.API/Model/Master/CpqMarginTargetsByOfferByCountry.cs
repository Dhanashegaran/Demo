﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class CpqMarginTargetsByOfferByCountry
    {
        public long Id { get; set; }
        public string Margintemplate { get; set; }
        public string L1offertype { get; set; }
        public string L2offertype { get; set; }
        public string Region { get; set; }
        public string Country { get; set; }
        public string Class { get; set; }
        public string Productline { get; set; }
        public string Printersku { get; set; }
        public string Sku { get; set; }
        public decimal? Targetmarginpct { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }
    }
}
