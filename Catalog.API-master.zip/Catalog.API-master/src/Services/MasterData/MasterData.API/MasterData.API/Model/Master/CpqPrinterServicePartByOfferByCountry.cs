﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class CpqPrinterServicePartByOfferByCountry
    {
        public long Id { get; set; }
        public string Family { get; set; }
        public string Sku { get; set; }
        public string L1offertype { get; set; }
        public string L2offertype { get; set; }
        public string Region { get; set; }
        public string Country { get; set; }
        public string Printersku { get; set; }
        public string Cpqflag { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }

        public virtual PlmSku PrinterskuNavigation { get; set; }
    }
}
