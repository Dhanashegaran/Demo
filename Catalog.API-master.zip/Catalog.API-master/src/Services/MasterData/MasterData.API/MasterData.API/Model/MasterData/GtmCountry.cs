﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class GtmCountry
    {
        public string RegionCode { get; set; }
        public string IsoCountryCode { get; set; }
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual CpqCountry IsoCountryCodeNavigation { get; set; }
        public virtual GtmRegion RegionCodeNavigation { get; set; }
    }
}
