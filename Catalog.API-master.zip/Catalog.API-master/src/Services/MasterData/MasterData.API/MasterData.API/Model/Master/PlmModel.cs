﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class PlmModel
    {
        public long Id { get; set; }
        public string Series { get; set; }
        public string Model { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }
        public long SeriesId { get; set; }

        public virtual PlmSeries SeriesNavigation { get; set; }
    }
}
