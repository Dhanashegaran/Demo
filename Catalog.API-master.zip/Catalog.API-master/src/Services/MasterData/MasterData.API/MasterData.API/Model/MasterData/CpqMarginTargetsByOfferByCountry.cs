﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class CpqMarginTargetsByOfferByCountry
    {
        public long Id { get; set; }
        public string MarginTemplate { get; set; }
        public string L1offerType { get; set; }
        public string L2offerType { get; set; }
        public string Region { get; set; }
        public string Country { get; set; }
        public string Class { get; set; }
        public string ProductLine { get; set; }
        public string PrinterSku { get; set; }
        public string Sku { get; set; }
        public decimal? TargetMarginPct { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdateDate { get; set; }
    }
}
