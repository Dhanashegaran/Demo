﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class treasury_currency_rate
    {
        public long id { get; set; }
        public string ratetable { get; set; }
        public string iso3currencycode { get; set; }
        public string productline { get; set; }
        public decimal? currencyrate { get; set; }
        public DateTime? effstartdate { get; set; }
        public DateTime? effenddate { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
        public string iso2currencycode { get; set; }
    }
}
