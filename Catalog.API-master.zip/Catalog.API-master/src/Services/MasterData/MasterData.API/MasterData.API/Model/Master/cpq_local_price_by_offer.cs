﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class cpq_local_price_by_offer
    {
        public long id { get; set; }
        public string sku { get; set; }
        public string l1offertype { get; set; }
        public string l2offertype { get; set; }
        public string pricedescriptor { get; set; }
        public decimal? listprice { get; set; }
        public DateTime? effstartdate { get; set; }
        public DateTime? effenddate { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
    }
}
