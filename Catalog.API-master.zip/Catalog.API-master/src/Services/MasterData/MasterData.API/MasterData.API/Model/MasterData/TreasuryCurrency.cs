﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class TreasuryCurrency
    {
        public long Id { get; set; }
        public string Iso2currencyCode { get; set; }
        public string Iso3currencyCode { get; set; }
        public string Description { get; set; }
        public decimal? NumDecimals { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdateDate { get; set; }
    }
}
