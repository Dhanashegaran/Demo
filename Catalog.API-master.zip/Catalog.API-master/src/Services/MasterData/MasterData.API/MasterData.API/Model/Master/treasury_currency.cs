﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class treasury_currency
    {
        public long id { get; set; }
        public string iso2currencycode { get; set; }
        public string iso3currencycode { get; set; }
        public string description { get; set; }
        public decimal? numdecimals { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
    }
}
