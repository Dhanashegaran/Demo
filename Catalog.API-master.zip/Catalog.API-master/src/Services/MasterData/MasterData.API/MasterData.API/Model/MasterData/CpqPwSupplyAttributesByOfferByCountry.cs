﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.MasterData
{
    public partial class CpqPwSupplyAttributesByOfferByCountry
    {
        public long Id { get; set; }
        public string Sku { get; set; }
        public string L1offerType { get; set; }
        public string L2offerType { get; set; }
        public string Region { get; set; }
        public string Country { get; set; }
        public string PrinterSku { get; set; }
        public decimal? CustomerAvailableInk { get; set; }
        public decimal? InkPerPage { get; set; }
        public decimal? GeneralOfficeReductionPct { get; set; }
        public decimal? ColorSaveReductionPct { get; set; }
        public decimal? MaintInkLowVolSlope { get; set; }
        public decimal? MaintInkLowVolIntercept { get; set; }
        public decimal? MaintInklSlope { get; set; }
        public decimal? MaintInkIntercept { get; set; }
        public decimal? MaintInkLowVolumeThreshold { get; set; }
        public decimal? CostRatioMono { get; set; }
        public decimal? CostRatioColor { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdateDate { get; set; }

        public virtual PlmSku PrinterSkuNavigation { get; set; }
    }
}
