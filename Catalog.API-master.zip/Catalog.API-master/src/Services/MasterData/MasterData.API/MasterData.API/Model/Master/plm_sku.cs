﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.MasterData.API.Model.Master
{
    public partial class plm_sku
    {
        public plm_sku()
        {
            cpq_printer_llc_by_offer_by_country = new HashSet<cpq_printer_llc_by_offer_by_country>();
            cpq_printer_service_part_by_offer_by_country = new HashSet<cpq_printer_service_part_by_offer_by_country>();
            cpq_printer_supply_by_offer_by_country = new HashSet<cpq_printer_supply_by_offer_by_country>();
            cpq_pw_supply_attributes_by_offer_by_country = new HashSet<cpq_pw_supply_attributes_by_offer_by_country>();
            cpq_service_part_attributes_by_offer_by_country = new HashSet<cpq_service_part_attributes_by_offer_by_country>();
            cpq_supply_attributes_by_offer_by_country = new HashSet<cpq_supply_attributes_by_offer_by_country>();
            cpq_supply_program_by_offer_by_country = new HashSet<cpq_supply_program_by_offer_by_country>();
            plm_configrable_services = new HashSet<plm_configrable_services>();
            plm_preconfigured_hw_bom = new HashSet<plm_preconfigured_hw_bom>();
        }

        public string model { get; set; }
        public string sku { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
        public long? model_id { get; set; }

        public virtual ICollection<cpq_printer_llc_by_offer_by_country> cpq_printer_llc_by_offer_by_country { get; set; }
        public virtual ICollection<cpq_printer_service_part_by_offer_by_country> cpq_printer_service_part_by_offer_by_country { get; set; }
        public virtual ICollection<cpq_printer_supply_by_offer_by_country> cpq_printer_supply_by_offer_by_country { get; set; }
        public virtual ICollection<cpq_pw_supply_attributes_by_offer_by_country> cpq_pw_supply_attributes_by_offer_by_country { get; set; }
        public virtual ICollection<cpq_service_part_attributes_by_offer_by_country> cpq_service_part_attributes_by_offer_by_country { get; set; }
        public virtual ICollection<cpq_supply_attributes_by_offer_by_country> cpq_supply_attributes_by_offer_by_country { get; set; }
        public virtual ICollection<cpq_supply_program_by_offer_by_country> cpq_supply_program_by_offer_by_country { get; set; }
        public virtual ICollection<plm_configrable_services> plm_configrable_services { get; set; }
        public virtual ICollection<plm_preconfigured_hw_bom> plm_preconfigured_hw_bom { get; set; }
    }
}
