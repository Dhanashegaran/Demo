﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using Hp.ContractualFramework.Services.MasterData.API.Infrastructure.Filters;
using Hp.ContractualFramework.Services.MasterData.API.Model.MasterData;
using Hp.ContractualFramework.Services.MasterData.API.Model.Master;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Swashbuckle.AspNetCore.Swagger;

namespace Hp.ContractualFramework.Services.MasterData.API {

    public class Startup {
        public Startup(IConfiguration configuration) {
            Configuration = configuration;
        }
        readonly string AllowSpecificOrigins = "allowSpecificOrigins";

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services) {
            services
                .AddSingleton<IConfiguration>(Configuration)
                .AddCustomDbContext(Configuration)
                .AddCustomMVC(Configuration)
                .AddIdentity(Configuration)
                .AddSwagger(Configuration);

            services.AddCors(options =>
            {
                options.AddPolicy(AllowSpecificOrigins,
                builder =>
                {
                    builder.WithOrigins("http://localhost:4200",
                                        "http://localhost:8002",
                                        "http://g1w9448.austin.hpicorp.net:8002")
                                        .AllowAnyHeader()
                                        .AllowAnyMethod();
                });
            });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env) {
            if (env.IsDevelopment()) {
                app.UseDeveloperExceptionPage();
            }

            //identity
            app.UseAuthentication();

            //cors
            app.UseCors(AllowSpecificOrigins);

            // Add header:
            app.Use((context, next) =>
            {
                context.Response.Headers["Access-Control-Allow-Origin"] = "*"; //TODO:add url
                return next.Invoke();
            });

            //mvc
            app.UseMvc();

            //swagger
            app.UseSwagger()
              .UseSwaggerUI(c => {
                  c.SwaggerEndpoint(Configuration["SwaggerEndpoint"], Configuration["SwaggerVersion"]);
                  c.OAuthClientId("masterdataapi_swagger");
                  c.OAuthAppName("MasterDataApi Swagger UI");
              });
        }
    }

    public static class CustomExtensionMethods {

        public static IServiceCollection AddCustomDbContext(this IServiceCollection services, IConfiguration configuration) {

            switch (configuration.GetValue<string>("DatabaseRuntime"))
            {
                case "SqlServer":

                    //Master context
                    services.AddDbContext<MasterDataContext>(options =>
                    {
                        options.UseSqlServer(configuration["MasterDataDbConnectionString"],
                            sqlServerOptionsAction: sqlOptions =>
                            {
                                sqlOptions.EnableRetryOnFailure(maxRetryCount: 10, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                            });
                        options.ConfigureWarnings(warnings => warnings.Throw(RelationalEventId.QueryClientEvaluationWarning));
                    });

                    break;

                case "PostgreSQL":

                    //Master Context (PostgreSQL)
                    services.AddDbContext<MasterContext>(options => {
                        options.UseNpgsql(configuration["PostgresMasterDataApiConnectionString"]);
                        options.ConfigureWarnings(warnings => warnings.Throw(RelationalEventId.QueryClientEvaluationWarning));
                    });

                    break;
            }

            return services;

        }

        public static IServiceCollection AddCustomMVC(this IServiceCollection services, IConfiguration configuration) {
            //services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            services.AddMvc();

            return services;
        }

        public static IServiceCollection AddSwagger(this IServiceCollection services, IConfiguration configuration) {
            services.AddSwaggerGen(options => {
                options.DescribeAllEnumsAsStrings();
                options.SwaggerDoc(configuration["SwaggerVersion"], new Swashbuckle.AspNetCore.Swagger.Info
                {
                    Title = configuration["SwaggerTitle"],
                    Version = configuration["SwaggerVersion"],
                    Description = configuration["SwaggerDescription"],
                    TermsOfService = configuration["SwaggerTermsOfService"]
                });

                //identity (swagger)
                options.AddSecurityDefinition("oauth2", new OAuth2Scheme
                {
                    Type = "oauth2",
                    Flow = "implicit",
                    AuthorizationUrl = String.Concat(configuration.GetValue<string>("IdentityUrlExternal"), "/connect/authorize"),
                    TokenUrl = String.Concat(configuration.GetValue<string>("IdentityUrlExternal"), "/connect/token"),
                    Scopes = new Dictionary<string, string>
                        {
                            { "masterdataapi", "MasterDataApi access" }
                        }
                });
                options.OperationFilter<AuthorizeCheckOperationFilter>();
            });

            return services;

        }

        public static IServiceCollection AddIdentity(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddMvcCore()
                .AddAuthorization()
                .AddJsonFormatters();

            JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();

            services.AddAuthentication("Bearer")
               .AddJwtBearer("Bearer", options =>
               {
                   options.Authority = configuration["IdentityUrl"];
                   options.RequireHttpsMetadata = false;
                   options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters()
                   {
                       ValidAudiences = new[] { "masterdataapi", "pricing_sim_api" }
                   };
               });

            return services;

        }

        public static IServiceCollection AddCors(this IServiceCollection services)
        {
            services.AddCors(options => {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .SetIsOriginAllowed((host) => true)
                    .AllowCredentials());
            });

            return services;
        }
    }
}