﻿using Hp.ContractualFramework.Services.MasterData.API.Model.MasterData;
using Hp.ContractualFramework.Services.MasterData.API.Model.Master;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace MasterData.API.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class MasterDataController : ControllerBase
    {

        private readonly MasterContext _masterContext;
        private readonly ILogger _logger;
        private readonly IConfiguration _configuration;

        public MasterDataController(MasterContext context, IConfiguration configuration, ILogger<MasterDataController> logger)
        {
            _masterContext = context;
            _logger = logger;
            _configuration = configuration;
        }

        private async Task<string> GetRegionForCountry(string countryCode)
        {
           
            List<string> regionList = await _masterContext.gtm_country
              .Where(e => e.isocountrycode == countryCode)
              .Select(e => e.regioncode)
              .ToListAsync();

            //region as '*' for ultimate fallback
            string region = (regionList.Any() ? regionList[0] : "*");

            return region;
        }

        [HttpGet]
        [Route("L1OfferTypes")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<string>>> GetL1OfferTypes(string IsoCountryCode)
        {

            try
            {

                //region as '*' for ultimate fallback
                string region = await GetRegionForCountry(IsoCountryCode);

                List<string> items = await _masterContext.gtm_offer_type_by_country
                    .Where(e => e.isocountrycode == IsoCountryCode
                    || (e.regioncode == region && e.isocountrycode == "*")
                    || (e.isocountrycode == "*" && e.regioncode == "*"))
                    .Select(e => e.l1offertype).Distinct()
                    .ToListAsync();


                if (items.Any())
                {
                    items.Remove("*");
                    return Ok(items);
                }
                return NotFound(string.Concat("No data  exists for the IsoCountryCode or Region :", IsoCountryCode));

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("L2OfferTypes")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<string>>> GetL2OfferTypes(string IsoCountryCode, string l1OfferType)
        {

            try
            {

                //region as '*' for ultimate fallback
                string region = await GetRegionForCountry(IsoCountryCode);

                var l2_all = from ot in _masterContext.gtm_offer_type
                             where ot.l1offertype == l1OfferType
                             select ot.l2offertype;

                List<string> items = await _masterContext.gtm_offer_type_by_country
                    .Where(e => (e.isocountrycode == IsoCountryCode || (e.regioncode == region && e.isocountrycode == "*") || (e.isocountrycode == "*" && e.regioncode == "*"))
                    && (e.l1offertype == l1OfferType || e.l1offertype == "*"))
                    .Select(e => e.l2offertype).Distinct()
                    .ToListAsync();



                if (items.Any())
                {
                    if (items.Contains("*"))
                        return Ok(l2_all);
                    return Ok(items);
                }
                else
                    return NotFound(string.Concat("No data exists for the IsoCountryCode, l1OfferType :", IsoCountryCode, ", ", l1OfferType));

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("Countries")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<Tuple<string, string>>>> GetCountries()
        {

            try
            {
                var items = await (from cntries in _masterContext.gtm_offer_type_by_country
                                   join cdesc in _masterContext.gtm_country on cntries.isocountrycode equals cdesc.isocountrycode
                                   select new Tuple<string, string>(cntries.isocountrycode, cdesc.countryname)).ToListAsync();

                if (items.Any())
                    return Ok(items.Distinct());
                else
                    return NotFound("No data exists");

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("Currencies")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<Tuple<string, string>>>> GetCurrencies(string isoCountryCode, string l1OfferType, string l2OfferType)
        {

            try
            {

                List<string> items = await _masterContext.cpq_price_descriptor_by_offer_by_country
                    .Where(e => e.country == isoCountryCode && (e.l1offertype == l1OfferType || e.l1offertype == "*") && (e.l2offertype == l2OfferType || e.l2offertype == "*"))
                    .Select(e => e.pricedescriptor).Distinct()
                    .ToListAsync();


                if (!items.Any())
                    return NotFound(string.Concat("No data exists for the IsoCountryCode :", isoCountryCode));


                //have list of price descriptors now need to look at currencies by parsing2 char for descriptor
                List<string> char_2_c_list = new List<string>();

                foreach (var item in items)
                {
                    string car_2 = item.Substring(0, 2);
                    string cur_2 = item.Substring(2, 2);
                    if (!char_2_c_list.Contains(cur_2))
                        char_2_c_list.Add(cur_2);
                }

                //may need to return a tuple with iso3 currency and description
                var curr_items = _masterContext.treasury_currency
                    .Where(e => char_2_c_list.Contains(e.iso2currencycode))
                    .Select(e => new Tuple<string, string>(e.iso3currencycode, e.description));

                if (curr_items.Any())
                    return Ok(curr_items);
                else
                    return NotFound("No data exists");

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("CurrencyRate")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<string>>> GetCurrencyRate(string IsoCurrencyCode)
        {

            try
            {

                var is_2_currency_q = from c2 in _masterContext.treasury_currency
                                      where c2.iso3currencycode == IsoCurrencyCode
                                      select c2.iso2currencycode;

                if (is_2_currency_q.Any())
                {

                    var iso_2_currency_code = is_2_currency_q.First();

                    var items = await _masterContext.treasury_currency_rate
                        .Where(e => e.iso2currencycode == iso_2_currency_code)
                        .Select(e => e.currencyrate).Distinct()
                        .ToListAsync();
                    //need to od a PL join here...

                    if (items.Any())
                        return Ok(items);
                    else
                        return NotFound(string.Concat("No data exists for 2-char ISO Currency ", iso_2_currency_code));
                }
                return NotFound(string.Concat("No data exists for ", IsoCurrencyCode));

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("HardwarePurchaseMethods")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<Tuple<string, string>>>> GetHardwarePurchaseMethods(string IsoCountryCode, string L1OfferType, string L2OfferType)
        {

            try
            {
                string region = await GetRegionForCountry(IsoCountryCode);

                var items = await _masterContext.cpq_hw_purchase_options_by_offer_by_country
                    .Join(_masterContext.cpq_hw_purchase_options, e => e.hwpurchaseoption, p => p.hwpurchaseoption, (e, p) => new { e.hwpurchaseoption, e.country, e.l1offertype, e.l2offertype, e.region, p.description })
                    .Where(e => (e.country == IsoCountryCode || (e.region == region && e.country == "*") || (e.country == "*" && e.region == "*"))
                     && (e.l1offertype == L1OfferType || e.l1offertype == "*")
                     && (e.l2offertype == L2OfferType || e.l2offertype == "*"))
                    .Select(e => new { e.hwpurchaseoption, e.country, e.l1offertype, e.l2offertype, e.description })
                    .ToListAsync();

                var vals = from item in items
                           orderby (item.country == "*" ? 0 : 1) + (item.l1offertype == "*" ? 0 : 2) + (item.l2offertype == "*" ? 0 : 4) descending
                           select new Tuple<string, string>(item.hwpurchaseoption, item.description);
                vals = vals.Distinct();

                if (vals.Any())
                    return Ok(vals);
                else
                    return NotFound(string.Format("No data exists for the  L1OffferType:{0}, L2OfferType:{1}", L1OfferType, L2OfferType));

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("BillingModels")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<Tuple<string, string>>>> GetBillingModels(string IsoCountryCode, string L1OfferType, string L2OfferType)
        {

            try
            {
                string region = await GetRegionForCountry(IsoCountryCode);
                var items = await _masterContext.cpq_billing_models_by_offer_by_country
                    .Join(_masterContext.cpq_billing_models, e => e.billingmodel, bmi => bmi.billingmodel, (e, bmi) => new { e.billingmodel, e.country, e.region, e.l1offertype, e.l2offertype, bmi.description })
                    .Where(e => (e.country == IsoCountryCode || (e.region == region && e.country == "*") || (e.country == "*" && e.region == "*"))
                     && (e.l1offertype == L1OfferType || e.l1offertype == "*")
                     && (e.l2offertype == L2OfferType || e.l2offertype == "*"))
                .Select(e => new { e.billingmodel, e.region, e.country, e.l1offertype, e.l2offertype, e.description })
                    .ToListAsync();

                //push stars to bottom
                var vals = from item in items
                           orderby (item.country == "*" ? 0 : 1) + (item.l1offertype == "*" ? 0 : 2) + (item.l2offertype == "*" ? 0 : 4) descending
                           select new Tuple<string, string>(item.billingmodel, item.description);
                vals = vals.Distinct();

                if (vals.Any())
                    return Ok(vals);
                else
                    return NotFound(string.Format("No data exists for the  L1OffferType:{0}, L2OfferType:{1}", L1OfferType, L2OfferType));

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }


        [HttpGet]
        [Route("KitOptions")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<Tuple<string, string>>>> GetKitOptions(string IsoCountryCode, string L1OfferType, string L2OfferType)
        {

            try
            {
                string region = await GetRegionForCountry(IsoCountryCode);
                var items = await _masterContext.cpq_kit_options_by_offer_by_country
                   .Join(_masterContext.cpq_kit_options, e => e.kitoption, bmi => bmi.kitoption, (e, bmi) => new { e.kitoption, e.country, e.region, e.l1offertype, e.l2offertype, bmi.description })
                    .Where(e => (e.country == IsoCountryCode || (e.region == region && e.country == "*") || (e.country == "*" && e.region == "*"))
                     && (e.l1offertype == L1OfferType || e.l1offertype == "*")
                     && (e.l2offertype == L2OfferType || e.l2offertype == "*"))
                    .Select(e => new { e.kitoption, e.country, e.l1offertype, e.l2offertype, e.description })
                    .ToListAsync();

                //push stars to bottom
                var vals = from item in items
                           orderby (item.country == "*" ? 0 : 1) + (item.l1offertype == "*" ? 0 : 2) + (item.l2offertype == "*" ? 0 : 4) descending
                           select new Tuple<string, string>(item.kitoption, item.description);
                vals = vals.Distinct();

                if (vals.Any())
                    return Ok(vals);

                else
                    return NotFound(string.Format("No data exists for the  L1OffferType:{0}, L2OfferType:{1}", L1OfferType, L2OfferType));

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("ServiceLevels")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<Tuple<string, string>>>> GetServiceLevels(string IsoCountryCode, string L1OfferType, string L2OfferType)
        {

            try
            {
                string region = await GetRegionForCountry(IsoCountryCode);
                var items = await _masterContext.cpq_service_levels_by_offer_by_country
                   .Join(_masterContext.cpq_service_levels, e => e.sla, bmi => bmi.sla, (e, bmi) => new { e.sla, e.country, e.region, e.l1offertype, e.l2offertype, bmi.description })
                    .Where(e =>
                     (e.country == IsoCountryCode || (e.region == region && e.country == "*") || (e.country == "*" && e.region == "*"))
                     && (e.l1offertype == L1OfferType || e.l1offertype == "*")
                     && (e.l2offertype == L2OfferType || e.l2offertype == "*"))
                    .Select(e => new { e.sla, e.l1offertype, e.l2offertype, e.country, e.region, e.description }).Distinct()
                    .ToListAsync();

                //push stars to bottom
                var vals = from item in items
                           orderby (item.country == "*" ? 0 : 1) + (item.l1offertype == "*" ? 0 : 2) + (item.l2offertype == "*" ? 0 : 4) descending
                           select new Tuple<string, string>(item.sla, item.description);
                vals = vals.Distinct();

                if (vals.Any())
                    return Ok(vals);
                else
                    return NotFound(string.Format("No data exists for the  L1OffferType:{0}, L2OfferType:{1}", L1OfferType, L2OfferType));

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("HardwareFulfillmentOptions")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<Tuple<string, string>>>> GetHarwareFulfillmentOptions(string IsoCountryCode, string L1OfferType, string L2OfferType)
        {

            try
            {
                string region = await GetRegionForCountry(IsoCountryCode);
                var items = await _masterContext.cpq_hw_fulfillment_options_by_offer_by_country
                   .Join(_masterContext.cpq_hw_fulfillment_options, e => e.hwfulfillmentoption, bmi => bmi.hwfulfillmentoption, (e, bmi) => new { e.hwfulfillmentoption, e.country, e.region, e.l1offertype, e.l2offertype, bmi.description })
                   .Where(e => (e.country == IsoCountryCode || (e.region == region && e.country == "*") || (e.country == "*" && e.region == "*"))
                     && (e.l1offertype == L1OfferType || e.l1offertype == "*")
                     && (e.l2offertype == L2OfferType || e.l2offertype == "*"))
                    .Select(e => new { e.hwfulfillmentoption, e.l1offertype, e.l2offertype, e.country, e.region, e.description })
                    .Distinct()
                    .ToListAsync();

                //push stars to bottom
                var vals = from item in items
                           orderby (item.country == "*" ? 0 : 1) + (item.l1offertype == "*" ? 0 : 2) + (item.l2offertype == "*" ? 0 : 4) descending
                           select new Tuple<string, string>(item.hwfulfillmentoption, item.description);
                vals = vals.Distinct();

                if (vals.Any())
                    return Ok(vals);
                else
                    return NotFound(string.Format("No data exists for the  L1OffferType:{0}, L2OfferType:{1}", L1OfferType, L2OfferType));

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("SupplyFulfillmentOptions")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<Tuple<string, string>>>> GetSupplyFulfillmentOptions(string IsoCountryCode, string L1OfferType, string L2OfferType)
        {

            try
            {
                string region = await GetRegionForCountry(IsoCountryCode);
                var items = await _masterContext.cpq_supplies_fulfillment_options_by_offer_by_country
                     .Join(_masterContext.cpq_supplies_fulfillment_options, e => e.suppliesfulfillmentoption, bmi => bmi.suppliesfulfillmentoption, (e, bmi) => new { e.suppliesfulfillmentoption, e.country, e.region, e.l1offertype, e.l2offertype, bmi.description })
                  .Where(e => (e.country == IsoCountryCode || (e.region == region && e.country == "*") || (e.country == "*" && e.region == "*"))
                     && (e.l1offertype == L1OfferType || e.l1offertype == "*")
                     && (e.l2offertype == L2OfferType || e.l2offertype == "*"))
                    .Select(e => new { e.suppliesfulfillmentoption, e.l1offertype, e.l2offertype, e.country, e.region, e.description }).Distinct()
                    .ToListAsync();

                //push stars to bottom
                var vals = from item in items
                           orderby (item.country == "*" ? 0 : 1) + (item.l1offertype == "*" ? 0 : 2) + (item.l2offertype == "*" ? 0 : 4) descending
                           select new Tuple<string, string>(item.suppliesfulfillmentoption, item.description);
                vals = vals.Distinct();

                if (vals.Any())
                    return Ok(vals);
                else
                    return NotFound(string.Format("No data exists for the  L1OffferType:{0}, L2OfferType:{1}", L1OfferType, L2OfferType));
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("HardwareFulfillmentChannels")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<Tuple<string, string>>>> GetHardwareFulfillmentChannels(string IsoCountryCode, string L1OfferType, string L2OfferType)
        {

            try
            {
                string region = await GetRegionForCountry(IsoCountryCode);
                ///TODO: Check the table here....to retunr the Channel
                var items = await _masterContext.cpq_hw_fulfillment_options_by_offer_by_country
                    .Join(_masterContext.cpq_hw_fulfillment_options, e => e.hwfulfillmentoption, bmi => bmi.hwfulfillmentoption, (e, bmi) => new { e.hwfulfillmentoption, e.country, e.region, e.l1offertype, e.l2offertype, bmi.hwfulfillmentchannel, bmi.description })
                    .Where(e => (e.country == IsoCountryCode || (e.region == region && e.country == "*") || (e.country == "*" && e.region == "*"))
                     && (e.l1offertype == L1OfferType || e.l1offertype == "*")
                     && (e.l2offertype == L2OfferType || e.l2offertype == "*"))
                    .Select(e => new { e.hwfulfillmentchannel, e.l1offertype, e.l2offertype, e.country, e.region, e.description }).Distinct()
                    .ToListAsync();

                //push stars to bottom
                var vals = from item in items
                           orderby (item.country == "*" ? 0 : 1) + (item.l1offertype == "*" ? 0 : 2) + (item.l2offertype == "*" ? 0 : 4) descending
                           select new Tuple<string, string>(item.hwfulfillmentchannel, item.description);
                vals = vals.Distinct();

                if (vals.Any())
                    return Ok(vals);
                else
                    return NotFound(string.Format("No data exists for the  L1OffferType:{0}, L2OfferType:{1}", L1OfferType, L2OfferType));
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("SuppliesFulfillmentChannels")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<string>>> GetSuppliesFulfillmentChannels(string IsoCountryCode, string L1OfferType, string L2OfferType)
        {

            try
            {
                string region = await GetRegionForCountry(IsoCountryCode);
                ///TODO: Check the table here....to return the Channel
                List<string> items = await _masterContext.cpq_supplies_fulfillment_options_by_offer_by_country
                    .Where(e => (e.country == IsoCountryCode || (e.region == region && e.country == "*") || (e.country == "*" && e.region == "*"))
                     && (e.l1offertype == L1OfferType || e.l1offertype == "*")
                     && (e.l2offertype == L2OfferType || e.l2offertype == "*"))
                    .Select(e => e.suppliesfulfillmentoption).Distinct()
                    .ToListAsync();

                if (items.Any())
                    return Ok(items);
                else
                    return NotFound(string.Format("No data exists for the IsoCountryCode:{0}, L1OffferType:{1}, L2OfferType:{2}", IsoCountryCode, L1OfferType, L2OfferType));

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("MarginTemplates")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<string>>> GetMarginTemplates(string L1OfferType, string L2OfferType)
        {

            try
            {
                ///TODO: Check the table here....to return the Channel
                List<string> items = await _masterContext.cpq_margin_template_by_offer
                    .Where(e => (e.l1offertype == L1OfferType || e.l1offertype == "*")
                     && (e.l2offertype == L2OfferType || e.l2offertype == "*"))
                    .Select(e => e.margintemplate).Distinct()
                    .ToListAsync();

                if (items.Any())
                    return Ok(items);
                else
                    return NotFound(string.Format("No data exists for the  L1OffferType:{0}, L2OfferType:{1}", L1OfferType, L2OfferType));

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }


        [HttpGet]
        [Route("PrinterSkus")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(string), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<Tuple<string, string>>>> GetPrinterSkus(string IsoCountryCode, string L1OfferType, string L2OfferType)
        {

            try
            {
                string region = await GetRegionForCountry(IsoCountryCode);

                var items = await (
                     from cpqprint in _masterContext.cpq_printer_by_offer_by_country
                     join plm_sku in _masterContext.plm_sku on cpqprint.sku equals plm_sku.sku
                     where ((cpqprint.country == IsoCountryCode || (cpqprint.region == region && cpqprint.country == "*") || (cpqprint.country == "*" && cpqprint.region == "*"))
                     && (cpqprint.l1offertype == L1OfferType || cpqprint.l1offertype == "*")
                     && (cpqprint.l2offertype == L2OfferType || cpqprint.l2offertype == "*"))
                     select new Tuple<string, string>(cpqprint.sku, plm_sku.model))
                     .Distinct()
                    .ToListAsync();

                if (items.Any())
                    return Ok(items);
                else
                    return NotFound(string.Format("No data exists for the IsoCountryCode:{0}, L1OffferType:{1}, L2OfferType:{2}", IsoCountryCode, L1OfferType, L2OfferType));
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
    }
}