﻿using Hp.ContractualFramework.Services.Catalog.API.Model.Master.External.Corona;
using Hp.ContractualFramework.Services.Catalog.API.Model.PricingSimulation;
using Hp.ContractualFramework.Services.Sample.API.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Catalog.API.Controllers {
    [Route("api/v1/[controller]")]
    [ApiController]
    [EnableCors("CorsPolicy")]
    [Authorize]
    public class PricingSimulationController : ControllerBase {

        private readonly PricingSimulationContext _pricingSimulationContext;
        private readonly ICoronaApi _coronaApi;
        private readonly ILogger _logger;
        private readonly IConfiguration _configuration;

        public PricingSimulationController(PricingSimulationContext pContext, ICoronaApi coronaApi, IConfiguration configuration, ILogger<PricingSimulationController> logger) {
            _pricingSimulationContext = pContext;
            _coronaApi = coronaApi;
            _logger = logger;
            _configuration = configuration;
        }

        [HttpPost]
        [Route("SimulationRequest/Add")]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        public async Task<ActionResult> AddSimulationRequest([FromBody] pricing_simulation_request Request) {

            try {

                if (SimulationExists(Request.simulationid).Result) {
                    return BadRequest("Simulation already exists.");
                }

                //update request header/details
                UpdateRequestSimulationIds(ref Request);

                //save input
                _pricingSimulationContext.PricingSimulationRequest.Add(Request);
                await _pricingSimulationContext.SaveChangesAsync();

                //return output
                return NoContent();

            } catch (Exception ex) {
                return BadRequest(ex);
            }
        }

        [HttpPost]
        [Route("ProcessSimulation")]
        [ProducesResponseType(typeof(pricing_simulation_response), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<pricing_simulation_response>> ProcessSimulation([FromBody] pricing_simulation_request Request) {
            DateTime startTime = DateTime.Now;
            try {

                if (SimulationExists(Request.simulationid).Result) {
                    return BadRequest("Simulation already exists.");
                }

                //update request header/details
                UpdateRequestSimulationIds(ref Request);

                //save input
                _pricingSimulationContext.PricingSimulationRequest.Add(Request);
                await _pricingSimulationContext.SaveChangesAsync();

                //execute spProcessPricingSimulation
                ExecuteProcessPricingSimulation(Request.simulationid, _configuration);

                //real time prices
                if (Request.requestheader.realtimepricecall) {

                    List<pricing_simulation_response_detail> responseDetailList = await _pricingSimulationContext.PricingSimulationResponseDetail
                   .Where(x => x.simulationid == Request.simulationid)
                   .ToListAsync();
                    SaveCoronaPrices(responseDetailList, Request.requestheader);
                }
                if (Request.requestheader.realtimecostcall) {
                    List<pricing_simulation_response_detail> responseDetailList = await _pricingSimulationContext.PricingSimulationResponseDetail
                    .Where(x => x.simulationid == Request.simulationid)
                    .ToListAsync();
                    PullAndSaveRealtimeCosts(responseDetailList, Request.requestheader);
                }

                ProcessSimulationCalculations(Request.simulationid, 4, _configuration);
                ProcessSimulationCalculations(Request.simulationid, 3, _configuration);

                //get output
                pricing_simulation_response output = await _pricingSimulationContext.PricingSimulationResponse
                 .Where(x => x.simulationid == Request.simulationid)
                 .Include(x => x.responsedetail)
                 .Include(x => x.responsesummary)
                 .FirstAsync();

                //return output
                return Ok(output);
            } catch (Exception ex) {
                return BadRequest(ex);
            } finally {
                _logger.LogInformation(string.Format("Total Time taken to complete the Pricing Simulation = {0} ms", new TimeSpan(DateTime.Now.Ticks - startTime.Ticks).TotalMilliseconds.ToString()));
            }

        }

        [HttpGet]
        [Route("Simulation")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(pricing_simulation_response), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<pricing_simulation_response>> GetSimulation(string SimulationId) {

            try {

                if (SimulationExists(SimulationId).Result) {

                    //get output
                    pricing_simulation_response response = await _pricingSimulationContext.PricingSimulationResponse
                     .Where(x => x.simulationid == SimulationId)
                     .Include(x => x.responsedetail)
                     .Include(x => x.responsesummary)
                     .FirstOrDefaultAsync();

                    //return output
                    return Ok(response);

                } else {
                    return NotFound(SimulationId);
                }

            } catch (Exception ex) {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("Simulations")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(pricing_simulation_response), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<List<pricing_simulation_response>>> GetAllSimulationsForPrinterSKU(string PrinterSku) {

            try {

                List<pricing_simulation_response> items = await _pricingSimulationContext.PricingSimulationResponse
                    .Where(psResponse => psResponse.responsesummary
                    .Any(psResponseSummary => psResponseSummary.printersku == PrinterSku))
                    .Include(x => x.responsesummary)
                    .Include(x => x.responsedetail).ToListAsync();
                if (items.Any())
                    return Ok(items);
                else
                    return NotFound(string.Concat("No simulations exist for the printerSku :", PrinterSku));

            } catch (Exception ex) {
                return BadRequest(ex);
            }
        }

        [HttpDelete]
        [Route("Simulation/Delete")]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(pricing_simulation_response), (int)HttpStatusCode.OK)]
        public async Task<ActionResult> RemoveSimulation(string SimulationId) {

            try {

                if (SimulationExists(SimulationId).Result) {

                    //delete request objects
                    pricing_simulation_request_header requestHeader = await _pricingSimulationContext.PricingSimulationRequestHeader
                        .Where(x => x.simulationid == SimulationId).FirstOrDefaultAsync();
                    pricing_simulation_request_detail requestDetail = await _pricingSimulationContext.PricingSimulationRequestDetail
                        .Where(x => x.simulationid == SimulationId).FirstOrDefaultAsync();
                    pricing_simulation_request request = await _pricingSimulationContext.PricingSimulationRequest
                        .Where(x => x.simulationid == SimulationId).FirstOrDefaultAsync();

                    if (requestHeader != null) { _pricingSimulationContext.Remove(requestHeader); }
                    if (requestDetail != null) { _pricingSimulationContext.Remove(requestDetail); }
                    if (request != null) { _pricingSimulationContext.Remove(request); }

                    //delete response objets
                    pricing_simulation_response_detail responseDetail = await _pricingSimulationContext.PricingSimulationResponseDetail
                       .Where(x => x.simulationid == SimulationId).FirstOrDefaultAsync();
                    pricing_simulation_response_summary responseSummary = await _pricingSimulationContext.PricingSimulationResponseSummary
                       .Where(x => x.simulationid == SimulationId).FirstOrDefaultAsync();
                    pricing_simulation_response response = await _pricingSimulationContext.PricingSimulationResponse
                       .Where(x => x.simulationid == SimulationId).FirstOrDefaultAsync();

                    if (responseDetail != null) { _pricingSimulationContext.Remove(responseDetail); }
                    if (responseSummary != null) { _pricingSimulationContext.Remove(responseSummary); }
                    if (response != null) { _pricingSimulationContext.Remove(response); }

                    //save context
                    await _pricingSimulationContext.SaveChangesAsync();

                    return NoContent();

                } else {
                    return NotFound(String.Concat("SimulationId: ", SimulationId, " not found."));
                }

            } catch (Exception ex) {
                return BadRequest(ex.ToString());

            }
        }

        [HttpPost]
        [Route("LockPrinterPricing")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        public async Task<ActionResult> LockPricingForPrinterSKU(pricing_catalog Catalog) {

            try {

                var userId = "Anonymous";
                Catalog.createdby = userId;
                Catalog.createddate = DateTime.Now.Date;

                pricing_catalog item = await _pricingSimulationContext.PricingCatalog
                    .Where(e => e.printersku == Catalog.printersku && e.simulationid == Catalog.simulationid
                    && e.effectivestartdate == Catalog.effectivestartdate && e.effectivestartdate == Catalog.effectiveenddate).FirstOrDefaultAsync();
                if (item is null) {
                    _pricingSimulationContext.PricingCatalog.Add(Catalog);
                    return Ok("Success");
                } else {
                    return BadRequest("Pricing already locked for this printer Sku.");
                }
            } catch (Exception ex) {
                return BadRequest(ex);
            }
        }

        #region "private methods"

        private async Task<bool> SimulationExists(string simulationId) {

            var simulation = await _pricingSimulationContext.PricingSimulationRequest
                .Where(x => x.simulationid == simulationId).AnyAsync();

            return simulation;

        }

        private static void ExecuteProcessPricingSimulation(string simulationId, IConfiguration configuration) {

            switch (configuration.GetValue<string>("DatabaseRuntime")) {
                case "PostgreSQL":

                    using (NpgsqlConnection conn = new NpgsqlConnection(configuration.GetValue<string>("PostgresCatalogApiConnectionString"))) {
                        string sql = "CALL pricing_simulation.spprocesssimulation(@_p_simulationid)";
                        using (NpgsqlCommand cmd = new NpgsqlCommand(sql, conn)) {
                            cmd.Parameters.AddWithValue("@_p_simulationid", simulationId);
                            conn.Open();
                            Task t = cmd.ExecuteNonQueryAsync();
                            t.Wait();

                        }
                    }

                    break;

                case "SqlServer":

                    using (System.Data.SqlClient.SqlConnection conn = new SqlConnection(configuration["CatalogAPIDbConnectionString"])) {
                        string sql = "spProcessSimulation";

                        using (SqlCommand cmd = new SqlCommand(sql, conn)) {

                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@SimulationId", simulationId);
                            conn.Open();

                            IAsyncResult result = cmd.BeginExecuteNonQuery();
                            cmd.EndExecuteNonQuery(result);
                        }
                    }

                    break;
            }
        }

        private void ProcessSimulationCalculations(string simulationId, int templateId, IConfiguration configuration) {

            var items = _pricingSimulationContext.PricingSimulationModelTemplateField
                    .Where(x => x.templateid == templateId && x.calcprocedure != null && x.enabled.HasValue && x.enabled.Value)
                    .OrderBy(x => x.calcorder);
            DateTime startTime;
            foreach (pricing_simulation_model_template_field item in items) {
                startTime = DateTime.Now;
                try {
                    ExecuteCalcProcedure(simulationId, configuration, item.calcprocedure);
                } catch (Exception ex) {
                    //Log exception
                    _logger.LogError(ex, string.Concat("Error executing CalcProcedure ", item.calcprocedure, " for SimulationId: ", simulationId));
                } finally {
                    _logger.LogInformation(string.Format("Time taken to execute  Calc Procedure {0} = {1} ms", item.calcprocedure, new TimeSpan(DateTime.Now.Ticks - startTime.Ticks).TotalMilliseconds.ToString()));
                }
            }
        }

        private static void ExecuteCalcProcedure(string simulationId, IConfiguration configuration, string calcProcedure) {
            switch (configuration.GetValue<string>("DatabaseRuntime")) {
                case "PostgreSQL":

                    using (NpgsqlConnection conn = new NpgsqlConnection(configuration.GetValue<string>("PostgresCatalogApiConnectionString"))) {
                        using (NpgsqlCommand cmd = new NpgsqlCommand(calcProcedure, conn)) {
                            conn.Open();
                            cmd.Parameters.AddWithValue("@_p_simulationid", simulationId);
                            Task t = cmd.ExecuteNonQueryAsync();
                            t.Wait();

                        }
                    }

                    break;

                case "SqlServer":

                    using (System.Data.SqlClient.SqlConnection conn = new SqlConnection(configuration["CatalogAPIDbConnectionString"])) {
                        string sql = calcProcedure.Replace("@SimulationId", string.Concat("'", simulationId, "'"));
                        using (SqlCommand cmd = new SqlCommand(sql, conn)) {
                            conn.Open();
                            IAsyncResult result = cmd.BeginExecuteNonQuery();
                            cmd.EndExecuteNonQuery(result);
                        }
                    }

                    break;
            }
        }

        private static void UpdateRequestSimulationIds(ref pricing_simulation_request Request) {

            //header
            Request.requestheader.simulationid = Request.simulationid;

            //detail
            foreach (pricing_simulation_request_detail detailItem in Request.requestdetail) {
                detailItem.simulationid = Request.simulationid;
            }
        }

        private void SaveCoronaPrices(List<pricing_simulation_response_detail> responseDetail, pricing_simulation_request_header requestHeader) {

            //append distinct printerSku's and component Sku's
            var componentskus = (from x in responseDetail
                                 where x.componentsku != null
                                 select x.componentsku).Distinct();

            var printerskus = (from x in responseDetail
                               select x.printersku).Distinct();

            var skus = printerskus.Union(componentskus);

            var coronaListPriceRequest = new CoronaListPriceRequest() {
                ListPriceRequestInfo = new ListPriceRequestInfo() {
                    PriceDescriptor = new PriceDescriptorIn() {
                        Country = requestHeader.country,
                        Currency = requestHeader.currency,
                        IncoTerm = "DDP", ///TODO: Get the right incoterm
                        PriceListType = null
                    },
                    Products = new Products() {
                        Product = skus.ToList()
                    }

                }
            };

            //corona price call
            var coronaListPriceResponse = _coronaApi.GetListPriceAsync(coronaListPriceRequest);

            //save prices to cpq_corona_prices table

        }
        //pull costs from C4 and save values to the MasterDB cost table
        private async void PullAndSaveRealtimeCosts(List<pricing_simulation_response_detail> responseDetail, pricing_simulation_request_header request) {
            Hp.ContractualFramework.Services.Catalog.API.Master.External.C4.C4ServiceWrapper wrapper = Hp.ContractualFramework.Services.Catalog.API.Master.External.C4.C4ServiceWrapper.Instance();

            List<C4Service.Product> prod_list = new List<C4Service.Product>();

            var componentskus = (from x in responseDetail
                                 where x.componentsku != null
                                 select x.componentsku).Distinct();

            //TODO can we assume USD or do we need to group by line currency type (or header) and send in batches?? We may need the currency fetch to happen first
            foreach (var comp in componentskus) {
                prod_list.Add(new C4Service.Product() { id = comp });
            }

            //TODO currently hard coded, will potentially need to send second call for VCOS as current implmentation doesn't support multiple costing tpyes at once
            var response = await wrapper.GetCostsFromC4(prod_list.ToArray(), "US", "UD", "DP", "TCOS");

            if (response.success) {

                //compile results
                for (int p = 0; p < prod_list.Count; ++p) {

                    int mc = 0;
                    foreach (var m in response.metrics) {
                        if (m.p == p) {
                            //do something here with the returned value. Write to C4 offer table but we will to determine for what criteria
                            mc++;
                        }
                    }
                    foreach (var l in response.lines) {
                        if (l.p == p) {
                            //do something here by checking type on line
                            //l.lineType == "not" or "den" etc... do we report back to user?
                        }
                    }

                }
            }
        }

        #endregion

    }
}