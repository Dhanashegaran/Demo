﻿using System;
using System.Net;
using System.Net.Http;
using Hp.ContractualFramework.Services.Catalog.API.Model.Master;
using Hp.ContractualFramework.Services.Sample.API.Infrastructure;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Refit;
using Polly;
using Swashbuckle.AspNetCore.Swagger;
using System.Collections.Generic;
using Hp.ContractualFramework.Services.Catalog.API.Infrastructure.Filters;
using System.IdentityModel.Tokens.Jwt;

namespace Hp.ContractualFramework.Services.Catalog.API {

    public class Startup {
        public Startup(IConfiguration configuration) {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services) {
            services
                .AddSingleton<IConfiguration>(Configuration)
                .AddCustomDbContext(Configuration)
                .AddCustomMVC(Configuration)
                .AddIdentity(Configuration)
                .AddSwagger(Configuration)
                .AddCoronaApi(Configuration)
                .AddCors();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env) {
            if (env.IsDevelopment()) {
                app.UseDeveloperExceptionPage();
            }

            //identity
            app.UseAuthentication();
            // Add header:
            app.Use((context, next) =>
            {
                context.Response.Headers["Access-Control-Allow-Origin"] = "*"; //TODO:add url
                return next.Invoke();
            });
            //mvc
            app.UseMvc();

            //cors
            app.UseCors("CorsPolicy");

            //swagger
            app.UseSwagger()
              .UseSwaggerUI(c => {
                  c.SwaggerEndpoint(Configuration["SwaggerEndpoint"], Configuration["SwaggerVersion"]);
                  c.OAuthClientId("catalogapi_swagger");
                  c.OAuthAppName("CatalogAPI Swagger UI");
              });
        }
    }
    public static class CustomExtensionMethods {
        public static IServiceCollection AddCustomDbContext(this IServiceCollection services, IConfiguration configuration) {


            switch (configuration.GetValue<string>("DatabaseRuntime")) {
                case "SqlServer":

                    //PricingSimulation Context (SQL Server)
                    services.AddDbContext<PricingSimulationContext>(options =>
                    {
                        options.UseSqlServer(configuration["CatalogAPIDbConnectionString"],
                            sqlServerOptionsAction: sqlOptions =>
                            {
                                sqlOptions.EnableRetryOnFailure(maxRetryCount: 10, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                            });
                        options.ConfigureWarnings(warnings => warnings.Throw(RelationalEventId.QueryClientEvaluationWarning));
                    });

                    //Master context (SQL Server)
                    services.AddDbContext<MasterContext>(options =>
                    {
                        options.UseSqlServer(configuration["MasterDataDbConnectionString"],
                            sqlServerOptionsAction: sqlOptions =>
                            {
                                sqlOptions.EnableRetryOnFailure(maxRetryCount: 10, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                            });
                        options.ConfigureWarnings(warnings => warnings.Throw(RelationalEventId.QueryClientEvaluationWarning));
                    });

                    break;

                case "PostgreSQL":

                    //PricingSimulation Context (PostgreSQL)
                    services.AddDbContext<PricingSimulationContext>(options => {
                        options.UseNpgsql(configuration["PostgresCatalogApiConnectionString"]);
                        options.ConfigureWarnings(warnings => warnings.Throw(RelationalEventId.QueryClientEvaluationWarning));
                    });

                    //Master Context (PostgreSQL)
                    services.AddDbContext<MasterContext>(options => {
                        options.UseNpgsql(configuration["PostgresMasterDataApiConnectionString"]);
                        options.ConfigureWarnings(warnings => warnings.Throw(RelationalEventId.QueryClientEvaluationWarning));
                    });

                    break;
            }

            return services;

        }

        public static IServiceCollection AddCustomMVC(this IServiceCollection services, IConfiguration configuration) {
            //services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            services.AddMvc();

            return services;
        }

        public static IServiceCollection AddSwagger(this IServiceCollection services, IConfiguration configuration) {
            services.AddSwaggerGen(options => {
                options.DescribeAllEnumsAsStrings();
                options.SwaggerDoc(configuration["SwaggerVersion"], new Swashbuckle.AspNetCore.Swagger.Info {
                    Title = configuration["SwaggerTitle"],
                    Version = configuration["SwaggerVersion"],
                    Description = configuration["SwaggerDescription"],
                    TermsOfService = configuration["SwaggerTermsOfService"]
                });

                //identity (swagger)
                options.AddSecurityDefinition("oauth2", new OAuth2Scheme
                {
                    Type = "oauth2",
                    Flow = "implicit",
                    AuthorizationUrl = String.Concat(configuration.GetValue<string>("IdentityUrlExternal"), "/connect/authorize"),
                    TokenUrl = String.Concat(configuration.GetValue<string>("IdentityUrlExternal"), "/connect/token"),
                    Scopes = new Dictionary<string, string>
                        {
                            { "catalogapi", "CatalogApi access" }
                        }
                });
                options.OperationFilter<AuthorizeCheckOperationFilter>();
            });

            return services;

        }

        public static IServiceCollection AddIdentity(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddMvcCore()
                .AddAuthorization()
                .AddJsonFormatters();

            JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();

            //bearer
            services.AddAuthentication("Bearer")
               .AddJwtBearer("Bearer", options =>
               {
                   options.Authority = configuration["IdentityUrl"];
                   options.RequireHttpsMetadata = false;
                   options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters()
                   {
                       ValidAudiences = new[] { "catalogapi", "pricing_sim_api" }
                   };
               });

            return services;

        }

        public static IServiceCollection AddCoronaApi(this IServiceCollection services, IConfiguration configuration)
        {

            services.AddRefitClient<ICoronaApi>()
              .ConfigureHttpClient(c => c.BaseAddress = new Uri(configuration["CoronaApiUrl"]))
              .AddTransientHttpErrorPolicy(p => p.RetryAsync(3))
              .AddTransientHttpErrorPolicy(p => p.CircuitBreakerAsync(5, TimeSpan.FromSeconds(30)))
              .ConfigurePrimaryHttpMessageHandler(() => {
                  return new HttpClientHandler()
                  {
                      UseDefaultCredentials = true,
                      Credentials = new NetworkCredential(configuration["CoranaApiUsername"], configuration["CoronaApiPassword"]),
                  };
              });

            return services;
        }
        
        public static IServiceCollection AddCors(this IServiceCollection services)
        {
            services.AddCors(options => {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .SetIsOriginAllowed((host) => true)
                    .AllowCredentials());
            });

            return services;
        }
    }
}