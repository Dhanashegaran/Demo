﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Hp.ContractualFramework.Services.Sample.API.Infrastructure;
using Hp.ContractualFramework.Services.Catalog.API.Model.Master;

namespace Hp.ContractualFramework.Services.Catalog.API {

    public class Program {
        public static void Main(string[] args) {
            BuildWebHost(args)

                //.MigrateDbContext<MasterContext>((context, services) =>
                //{
                //})

                //.MigrateDbContext<PricingSimulationContext>((context, services) => {
                //})

                .Run();
        }

        public static IWebHost BuildWebHost(string[] args) =>

            WebHost.CreateDefaultBuilder(args)
            .ConfigureAppConfiguration((builderContext, config) => {
                var builtConfig = config.Build();
                var configurationBuilder = new ConfigurationBuilder();
                configurationBuilder.AddEnvironmentVariables();
                config.AddConfiguration(configurationBuilder.Build());
            })
                .ConfigureLogging((hostingContext, builder) => {
                    builder.AddConfiguration(hostingContext.Configuration.GetSection("Logging"));
                    builder.AddConsole();
                    builder.AddDebug();
                })
             .UseStartup<Startup>()
             .Build();
    }
}
