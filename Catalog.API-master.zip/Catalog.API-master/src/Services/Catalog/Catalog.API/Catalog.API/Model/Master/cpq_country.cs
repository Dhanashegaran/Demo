﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class cpq_country
    {
        public cpq_country()
        {
            gtm_country = new HashSet<gtm_country>();
        }

        public string isocountrycode { get; set; }
        public string cpqcountryflag { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }

        public virtual ICollection<gtm_country> gtm_country { get; set; }
    }
}
