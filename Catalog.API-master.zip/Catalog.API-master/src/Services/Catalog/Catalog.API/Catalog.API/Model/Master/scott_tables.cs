﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class scott_tables
    {
        public long id { get; set; }
        public string table_name { get; set; }
        public string column_name { get; set; }
        public string column_charid { get; set; }
        public int? column_id { get; set; }
        public string data_type { get; set; }
        public int? max_length { get; set; }
        public int? precision { get; set; }
        public int? scale { get; set; }
        public int? is_nullable { get; set; }
        public int? is_identity { get; set; }
    }
}
