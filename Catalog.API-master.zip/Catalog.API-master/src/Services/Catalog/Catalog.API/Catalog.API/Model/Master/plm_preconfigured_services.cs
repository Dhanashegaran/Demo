﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class plm_preconfigured_services
    {
        public long id { get; set; }
        public string sku { get; set; }
        public string description { get; set; }
        public string deliverablecode { get; set; }
        public string modifiercode { get; set; }
        public decimal? modifiervalue { get; set; }
        public string l1offertype { get; set; }
        public string l2offertype { get; set; }
        public string region { get; set; }
        public string country { get; set; }
        public string printersku { get; set; }
        public string cpqflag { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
        public string enableflag { get; set; }
    }
}
