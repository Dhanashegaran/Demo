﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class gpsy_price
    {
        public long id { get; set; }
        public string prod_base { get; set; }
        public string opt { get; set; }
        public string prod_nbr { get; set; }
        public string ctry_cd { get; set; }
        public string curr_cd { get; set; }
        public string prc_term_cd { get; set; }
        public decimal? qb_set_nbr { get; set; }
        public decimal? qbl_seq_nbr { get; set; }
        public DateTime? start_eff_dt { get; set; }
        public decimal? lclp { get; set; }
        public string user_logon_id { get; set; }
        public string process_nm { get; set; }
        public DateTime? last_mod_tmstmp { get; set; }
        public DateTime? end_eff_dt { get; set; }
        public string end_dt_cd { get; set; }
        public string prc_meth_cd { get; set; }
        public decimal? calc_ref_prc_amt { get; set; }
    }
}
