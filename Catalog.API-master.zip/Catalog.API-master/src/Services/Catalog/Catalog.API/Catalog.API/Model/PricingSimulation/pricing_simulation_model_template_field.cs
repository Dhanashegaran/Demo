﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.PricingSimulation {
    public class pricing_simulation_model_template_field {
        
        public long fieldid { get; set; }
        public int fieldorder { get; set; }
        public int? calcorder { get; set; }
        public string fieldname { get;  set; }
        public string calcprocedure { get; set; }
        public string calcexpression { get; set; }
        public string comment { get; set; }
        public bool? enabled { get; set; }

        //relationships
        public long templateid { get; set; }
        public pricing_simulation_model_template pricing_simulation_model_template { get; set; }
    }
}
