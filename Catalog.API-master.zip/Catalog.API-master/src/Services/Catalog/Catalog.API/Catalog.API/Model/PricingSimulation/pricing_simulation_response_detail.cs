﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.PricingSimulation {
    public class pricing_simulation_response_detail {

        public long responsedetailid { get; set; }
        [JsonIgnore]
        public string simulationid { get; set; }
        public string printersku { get; set; }
        public string componentsku { get; set; }
        public string itemclass { get; set; }
        public string cpqflag { get; set; }
        public string pricesource { get; set; }
        public string costsource { get; set; }
        public decimal? tcos { get; set; }
        public string tcoscurrency { get; set; }
        public decimal? tcoscurrencyrate { get; set; }
        public decimal? targetmarginpct { get; set; }
        public string lclpcurrency { get; set; }
        public decimal? lclpcurrencyrate { get; set; }
        public decimal? lclp { get; set; }
        public decimal? bdnetprice { get; set; }
        public string bdnetpricecurrency { get; set; }
        public decimal? bdnetpricecurrencyrate { get; set; }
        public decimal? contractualdiscountpct { get; set; }
        public decimal? truckloaddiscountpct { get; set; }
        public decimal? maxpricepct { get; set; }
        public decimal? msppct { get; set; }
        public decimal? tier1pct { get; set; }
        public decimal? tier2pct { get; set; }
        public decimal? tier3pct { get; set; }
        public decimal? tier4pct { get; set; }
        public decimal? isomonoyield { get; set; }
        public decimal? isocoloryield { get; set; }
        public decimal? isoprofcoloryield { get; set; }
        public decimal? isocolorsaveyield { get; set; }
        public decimal? isocoveragepct { get; set; }
        public string operationalyieldcalcmethod { get; set; }
        public decimal? tcossimulationcurrencyrate { get; set; }
        public decimal? lclpsimulationcurrencyrate { get; set; }
        public decimal? bdnetsimulationcurrencyrate { get; set; }
        public decimal? unitcost { get; set; }
        public decimal? targetmarginnetprice { get; set; }
        public decimal? listprice { get; set; }
        public decimal? ndp { get; set; }
        public decimal? maxprice { get; set; }
        public decimal? msp { get; set; }
        public decimal? streetprice { get; set; }
        public decimal? bdnetpricetier0 { get; set; }
        public decimal? bdnetpricetier1 { get; set; }
        public decimal? bdnetpricetier2 { get; set; }
        public decimal? bdnetpricetier3 { get; set; }
        public decimal? bdnetpricetier4 { get; set; }
        public decimal? discountednetprice { get; set; }
        public decimal? netprice { get; set; }
        public decimal? operationalcoveragepct { get; set; }
        public decimal? operationalmonoonmonoyield { get; set; }
        public decimal? operationalmonoonprofessionalcoloryield { get; set; }
        public decimal? operationalmonooncoloryield { get; set; }
        public decimal? operationalmonooncolorsaveyield { get; set; }
        public decimal? operationalprofcoloryield { get; set; }
        public decimal? operationalcoloryield { get; set; }
        public decimal? operationacolorsaveyield { get; set; }
        public decimal? componentqty { get; set; }
        public decimal? componentbasefee { get; set; }
        public decimal? componentmonoclick { get; set; }
        public decimal? componentprofcolorclick { get; set; }
        public decimal? componentcolorclick { get; set; }
        public decimal? componentcolorsaveclick { get; set; }
        public decimal? extendednetprice { get; set; }
        public decimal? extendedcost { get; set; }
        [JsonIgnore]
        public string createdby { get; set; }
        [JsonIgnore]
        public string updatedby { get; set; }
        [JsonIgnore]


        public DateTime? createddate { get; set; }
        [JsonIgnore]
        public DateTime? updateddate { get; set; }

        //relationships
        public long responseid { get; set; }
        [JsonIgnore]
        public pricing_simulation_response pricing_simulation_response { get; set; }
    }
}
