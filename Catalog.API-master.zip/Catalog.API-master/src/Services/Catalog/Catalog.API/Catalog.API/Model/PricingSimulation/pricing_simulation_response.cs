﻿using Hp.ContractualFramework.Services.Catalog.API.Model.Master;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.PricingSimulation {
    public class pricing_simulation_response {

        public pricing_simulation_response() {
            responsesummary = new List<pricing_simulation_response_summary>();
            responsedetail = new List<pricing_simulation_response_detail>();
        }

        public long responseid { get; set; }
        public string simulationid { get; set; }
        [JsonIgnore]
        public string createdby { get; set; }
        [JsonIgnore]
        public string updatedby { get; set; }
        [JsonIgnore]
        public DateTime? createddate { get; set; }
        [JsonIgnore]
        public DateTime? updateddate { get; set; }

        public List<pricing_simulation_response_summary> responsesummary { get; set; }
        public List<pricing_simulation_response_detail> responsedetail { get; set; }

               
    }
}
