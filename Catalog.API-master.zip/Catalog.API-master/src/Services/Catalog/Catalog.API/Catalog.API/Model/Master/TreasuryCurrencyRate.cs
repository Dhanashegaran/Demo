﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class TreasuryCurrencyRate
    {
        public long Id { get; set; }
        public string Ratetable { get; set; }
        public string Iso3currencycode { get; set; }
        public string Productline { get; set; }
        public decimal? Currencyrate { get; set; }
        public DateTime? Effstartdate { get; set; }
        public DateTime? Effenddate { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }
        public string Iso2currencycode { get; set; }
    }
}
