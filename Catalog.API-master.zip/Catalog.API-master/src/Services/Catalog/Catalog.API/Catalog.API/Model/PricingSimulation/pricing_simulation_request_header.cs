﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.PricingSimulation {
    public class pricing_simulation_request_header {
        public long requestheaderid { get; set; }
        [JsonIgnore]
        public string simulationid { get; set; }
        public string l1offertype { get; set; }
        public string l2offertype { get; set; }
        public string country { get; set; }
        public string currency { get; set; }
        public decimal currencyrate { get; set; }
        public int term { get; set; }
        public string hwpurchasemethod { get; set; }
        public string billingmodel { get; set; }
        public string kitoption { get; set; }
        public string servicelevel { get; set; }
        public string hwfulfillmentoption { get; set; }
        public string suppliesfulfillmentoption { get; set; }
        public string hwfulfillmentchannel { get; set; }
        public string suppliesfulfillmentchannel { get; set; }
        public bool? includeoptionalaccessories { get; set; }
        public bool? includeoptionalsupplies { get; set; }
        public bool? includecarepacks { get; set; }
        public string margintemplate { get; set; }
        public string pricingmethodology { get; set; }
        public string marginrebalancingmethod { get; set; }
        public bool realtimecostcall { get; set; }
        public bool realtimepricecall { get; set; }

        [JsonIgnore]
        public string createdby { get; set; }
        [JsonIgnore]
        public string updatedby { get; set; }
        [JsonIgnore]
        public DateTime? createddate { get; set; }
        [JsonIgnore]
        public DateTime? updateddate { get; set; }

        //relationships
        public long requestid { get; set; }
        [JsonIgnore]
        public pricing_simulation_request pricing_simulation_request { get; set; }
    }
}
