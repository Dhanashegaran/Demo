﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class CfsTableMetadata
    {
        public long Id { get; set; }
        public string TableName { get; set; }
        public string KeyFields { get; set; }
        public string WildcardFields { get; set; }
        public string DateFields { get; set; }
        public string RangeFields { get; set; }
        public DateTime? UpdateDttm { get; set; }
        public string UpdateUser { get; set; }
    }
}
