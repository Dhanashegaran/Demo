﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class gtm_country
    {
        public string regioncode { get; set; }
        public string isocountrycode { get; set; }
        public string countrycode { get; set; }
        public string countryname { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }

        public virtual cpq_country isocountrycodeNavigation { get; set; }
        public virtual gtm_region regioncodeNavigation { get; set; }
    }
}
