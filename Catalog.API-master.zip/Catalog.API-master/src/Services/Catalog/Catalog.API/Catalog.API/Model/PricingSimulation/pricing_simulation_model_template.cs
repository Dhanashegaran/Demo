﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.PricingSimulation {
    public class pricing_simulation_model_template {

        public long templateid { get; set; }
        public int templateorder { get; set; }
        public int? calcorder { get; set; }
        public string templatename { get; set; }
        public string templategroup { get; set; }
        public string comment { get; set; }
        public bool? enabled { get; set; }
    }
}
