﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.PricingSimulation {
    public class pricing_simulation_response_summary {

        public long responsesummaryid { get; set; }
        [JsonIgnore]
        public string simulationid { get; set; }
        public string printersku { get; set; }
        public decimal? defaultmonthlymonopages { get; set; }
        public decimal? defaultmonthlyprofcolorpages { get; set; }
        public decimal? defaultmonthlycolorpages { get; set; }
        public decimal? defaultmonthlycolorsavepages { get; set; }
        public decimal? monthlymonopages { get; set; }
        public decimal? monthlyprofcolorpages { get; set; }
        public decimal? monthlycolorpages { get; set; }
        public decimal? monthlycolorsavepages { get; set; }
        public decimal? totalmonthlypages { get; set; }
        public decimal? totalcontractmonopages { get; set; }
        public decimal? totalcontractprofcolorpages { get; set; }
        public decimal? totalcontractcolorpages { get; set; }
        public decimal? totalcontractcolorsavepages { get; set; }
        public decimal? totalcontractpages { get; set; }
        public decimal? totaldirectpurchasehardware { get; set; }
        public decimal? basefee { get; set; }
        public decimal? monoclick { get; set; }
        public decimal? profcolorclick { get; set; }
        public decimal? colorclick { get; set; }
        public decimal? colorsaveclick { get; set; }
        public decimal? systemmarginpct { get; set; }
        public decimal? hardwaremarginpct { get; set; }
        public decimal? suppliesmarginpct { get; set; }
        public decimal? servicemarginpct { get; set; }
        public decimal? breakfixmarginpct { get; set; }
        public decimal? kitmarginpct { get; set; }
        [JsonIgnore]
        public string createdby { get; set; }
        [JsonIgnore]
        public string updatedby { get; set; }
        [JsonIgnore]
        public DateTime? createddate { get; set; }
        [JsonIgnore]
        public DateTime? updateddate { get; set; }

        //relationships
        public long responseid { get; set; }
        [JsonIgnore]
        public pricing_simulation_response pricing_simulation_response { get; set; }
    }
}
