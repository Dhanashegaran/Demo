﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class PlmSeries
    {
        public PlmSeries()
        {
            PlmModel = new HashSet<PlmModel>();
        }

        public long Id { get; set; }
        public string Family { get; set; }
        public string Series { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }
        public long FamilyId { get; set; }

        public virtual PlmFamily FamilyNavigation { get; set; }
        public virtual ICollection<PlmModel> PlmModel { get; set; }
    }
}
