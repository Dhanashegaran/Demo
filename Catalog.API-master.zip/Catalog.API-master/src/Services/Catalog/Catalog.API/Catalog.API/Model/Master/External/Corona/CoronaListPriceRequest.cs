﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master.External.Corona {
    public class CoronaListPriceRequest {
        [JsonProperty("ListPriceRequestInfo")]
        public ListPriceRequestInfo ListPriceRequestInfo { get; set; }
    }

    [JsonObject(Title = "PriceDescriptor")]
    public class PriceDescriptorIn {
        [JsonProperty("Country")]
        public string Country { get; set; }

        [JsonProperty("Currency")]
        public string Currency { get; set; }
        [JsonProperty("IncoTerm")]
        public string IncoTerm { get; set; }
        [JsonProperty("PriceListType")]
        public string PriceListType { get; set; }
    }

    public class Products {
        [JsonProperty("Product")]
        public List<string> Product { get; set; }

        public Products() {
            Product = new List<string>();
        }
    }

    public class ListPriceRequestInfo {
        [JsonProperty("PriceDescriptor")]
        public PriceDescriptorIn PriceDescriptor { get; set; }
        [JsonProperty("Products")]
        public Products Products { get; set; }
    }
}
