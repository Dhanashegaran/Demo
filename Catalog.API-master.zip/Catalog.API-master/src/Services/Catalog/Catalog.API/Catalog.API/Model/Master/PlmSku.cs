﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class PlmSku
    {
        public PlmSku()
        {
            CpqPrinterLlcByOfferByCountry = new HashSet<CpqPrinterLlcByOfferByCountry>();
            CpqPrinterServicePartByOfferByCountry = new HashSet<CpqPrinterServicePartByOfferByCountry>();
            CpqPrinterSupplyByOfferByCountry = new HashSet<CpqPrinterSupplyByOfferByCountry>();
            CpqPwSupplyAttributesByOfferByCountry = new HashSet<CpqPwSupplyAttributesByOfferByCountry>();
            CpqServicePartAttributesByOfferByCountry = new HashSet<CpqServicePartAttributesByOfferByCountry>();
            CpqSupplyAttributesByOfferByCountry = new HashSet<CpqSupplyAttributesByOfferByCountry>();
            CpqSupplyProgramByOfferByCountry = new HashSet<CpqSupplyProgramByOfferByCountry>();
            PlmConfigrableServices = new HashSet<PlmConfigrableServices>();
            PlmPreconfiguredHwBom = new HashSet<PlmPreconfiguredHwBom>();
        }

        public string Model { get; set; }
        public string Sku { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }
        public long? ModelId { get; set; }

        public virtual ICollection<CpqPrinterLlcByOfferByCountry> CpqPrinterLlcByOfferByCountry { get; set; }
        public virtual ICollection<CpqPrinterServicePartByOfferByCountry> CpqPrinterServicePartByOfferByCountry { get; set; }
        public virtual ICollection<CpqPrinterSupplyByOfferByCountry> CpqPrinterSupplyByOfferByCountry { get; set; }
        public virtual ICollection<CpqPwSupplyAttributesByOfferByCountry> CpqPwSupplyAttributesByOfferByCountry { get; set; }
        public virtual ICollection<CpqServicePartAttributesByOfferByCountry> CpqServicePartAttributesByOfferByCountry { get; set; }
        public virtual ICollection<CpqSupplyAttributesByOfferByCountry> CpqSupplyAttributesByOfferByCountry { get; set; }
        public virtual ICollection<CpqSupplyProgramByOfferByCountry> CpqSupplyProgramByOfferByCountry { get; set; }
        public virtual ICollection<PlmConfigrableServices> PlmConfigrableServices { get; set; }
        public virtual ICollection<PlmPreconfiguredHwBom> PlmPreconfiguredHwBom { get; set; }
    }
}
