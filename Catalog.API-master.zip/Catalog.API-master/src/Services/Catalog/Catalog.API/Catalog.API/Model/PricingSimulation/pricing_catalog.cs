﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.PricingSimulation {
    public class pricing_catalog {

        public string simulationid { get; set; }
        public string printersku { get; set; }
        public DateTime? effectivestartdate { get; set; }
        public DateTime? effectiveenddate { get; set; }
        public bool? enabled { get; set; }
        [JsonIgnore]
        public string createdby { get; set; }
        [JsonIgnore]
        public string updatedby { get; set; }
        [JsonIgnore]
        public DateTime? createddate { get; set; }
        [JsonIgnore]
        public DateTime? updateddate { get; set; }

    }
}
