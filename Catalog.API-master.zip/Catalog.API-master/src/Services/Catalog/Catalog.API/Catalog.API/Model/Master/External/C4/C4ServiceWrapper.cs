﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hp.ContractualFramework.Services.Catalog.API.Master.External.C4
{
    public class C4ServiceWrapper
    {
        C4Service.C4OutputPortTypeClient _client = null;

        static C4ServiceWrapper _instance = null;

        private C4ServiceWrapper()
        {
            //TODO this will need to converted to https instance and source url from DB
            _client = new C4Service.C4OutputPortTypeClient(C4Service.C4OutputPortTypeClient.EndpointConfiguration.C4OutputPort, @"http://c4soap.houston.hp.com/C4OutputPort");

        }

        public static C4ServiceWrapper Instance()
        {
            if (_instance == null) {
                _instance = new C4ServiceWrapper();
            }

            return _instance;
        }

        async Task<C4Service.Context> GetContext()
        {
            //TODO this will need to come from dB in encrypted form
            var rs = await _client.connectAsync("$dartcostsrvc001", "red.hot-76", "C4SOAP", System.Environment.MachineName);

            return rs.context;
        }

        public async Task<CostResponse> GetCostsFromC4(C4Service.Product[] products, string countryCd, string currencyCd, string priceTermCd, string metric)
        {
            CostResponse rval = new CostResponse();
            try {

                List<ProductResponse> returnvals = new List<ProductResponse>();
                C4Service.C4OutputPortTypeClient client = new C4Service.C4OutputPortTypeClient(C4Service.C4OutputPortTypeClient.EndpointConfiguration.C4OutputPort, @"http://c4soap.houston.hp.com/C4OutputPort");

                MessageInspector mi = new MessageInspector();
                var inspector = new InspectorEndpointBehavior(mi);
                client.Endpoint.EndpointBehaviors.Add(inspector);
                var context = new C4Service.Context();
                var request = new C4Service.Request();

                context = await this.GetContext();

                request.country = countryCd;
                request.currency = currencyCd;


                request.products = products;
                request.descriptor = new C4Service.PriceDescriptor() { country = countryCd, currency = currencyCd, priceterm = priceTermCd };

                int lookahead_months = 2;
                DateTime[] dates = new DateTime[lookahead_months];
                string[] datestr = new string[lookahead_months];

                // Get monthly values for the next 6 years
                for (int i = 0; i < lookahead_months; i++) {
                    // Calc the last day of the month for the next n month
                    dates[i] = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).AddMonths(i + 1).AddDays(-1);
                    datestr[i] = dates[i].ToString("yyyy/MM/dd");
                }

                request.metric = metric;
                request.delivery = string.Empty;

                string datestrt = string.Empty;
                foreach (var sst in datestr)
                    if (datestrt == string.Empty)
                        datestrt = sst;
                    else
                        datestrt += ";" + sst;

                request.dates = datestr[0];

                //var result = await client.getCostImplicitMccsNotBundledExtrapolatedArrayAsync(context, new C4Service.Request[] { request }, false);

                var result = await client.getCostImplicitMccsNotBundledAsync(context, request);

                //get response SOAP as a string
                var message = mi.LastMessageString;

                Dictionary<string, object> vdict = new Dictionary<string, object>();

                //Parse the SOAP xml and pull out and assign values
                StripValuesFromXML(ref vdict, message);

                PopulateObjectsFromXML(out rval.metrics, out rval.lines, ref vdict, message);

                rval.success = true;
            } catch (System.Exception e) {
                //TODO proper error logging needs to be done here
                throw e;
            }

            return rval;
        }

        void StripValuesFromXML(ref Dictionary<string, object> vdict, string message)
        {
            using (var xr = System.Xml.XmlReader.Create(new System.IO.StringReader(message))) {

                //two pass, 1rst get vals, 2nd set vals
                while (xr.Read()) {
                    if (xr.HasAttributes) {
                        bool had_id = false;
                        while (xr.MoveToNextAttribute()) {

                            string atr_key = xr.Name;
                            string atr_val = xr.Value;

                            if (atr_key == "id") {
                                had_id = true;
                                string id_k = atr_val;
                                xr.MoveToElement();

                                if (!xr.IsEmptyElement) {
                                    if (xr.NodeType == System.Xml.XmlNodeType.Element) {

                                        string eval = xr.ReadInnerXml();
                                        //var eval = xr.ReadContentAsString();
                                        //xr.MoveToContent();
                                        //var eval = xr.Value;
                                        //string eval = xr.Value;
                                        if (vdict.ContainsKey(id_k)) {

                                            vdict[id_k] = eval;
                                        } else {
                                            vdict.Add(id_k, eval);
                                        }
                                    }
                                    break;
                                } else {
                                    break;
                                }
                            }


                        }

                        if (!had_id)
                            xr.MoveToElement();
                    }
                }
            }

        }
        void PopulateObjectsFromXML(out List<MetricWithMcc> metrics, out List<LineWithMcc> lines, ref Dictionary<string, object> vdict, string message)
        {
            metrics = new List<MetricWithMcc>();
            lines = new List<LineWithMcc>();

            Dictionary<string, string> type_dict = new Dictionary<string, string>();
            string mode = string.Empty;
            //Dictionary<string, List<C4Service.Metric>> mct_dict = new Dictionary<string, List<C4Service.Metric>>();

            using (var xr = System.Xml.XmlReader.Create(new System.IO.StringReader(message))) {

                MetricWithMcc current_metric = null;
                LineWithMcc current_line = null;
                //two pass, 1rst get vals, 2nd set vals
                while (xr.Read()) {

                    if (xr.NodeType == System.Xml.XmlNodeType.Element && (xr.Name == "ok" || xr.Name == "not" || xr.Name == "den")) {
                        string typ = xr.Name;
                        mode = xr.Name;
                        if (xr.HasAttributes)
                            while (xr.MoveToNextAttribute()) {
                                string atr_key = xr.Name;
                                string atr_val = xr.Value;

                                if (atr_key == "href") {
                                    string id_k = atr_val.Replace("#", "");
                                    if (!type_dict.ContainsKey(id_k))
                                        type_dict.Add(id_k, typ);

                                }

                            }
                    }


                    if (xr.NodeType == System.Xml.XmlNodeType.Element &&
                        (xr.Name == "v" || xr.Name == "m" || xr.Name == "p" || xr.Name == "d" || xr.Name == "mcc")) {
                        string elename = xr.Name;
                        if (current_metric != null
                            || current_line != null) {
                            if (xr.HasAttributes)
                                while (xr.MoveToNextAttribute()) {
                                    string atr_key = xr.Name;
                                    string atr_val = xr.Value;

                                    if (atr_key == "href") {
                                        string id_k = atr_val.Replace("#", "");
                                        if (vdict.ContainsKey(id_k)) {
                                            if (current_metric != null) {
                                                if (elename == "v")
                                                    current_metric.v = Convert.ToSingle(vdict[id_k]);
                                                else if (elename == "m")
                                                    current_metric.m = Convert.ToInt32(vdict[id_k]);
                                                else if (elename == "d")
                                                    current_metric.d = Convert.ToInt32(vdict[id_k]);
                                                else if (elename == "p")
                                                    current_metric.p = Convert.ToInt32(vdict[id_k]);
                                                else if (elename == "mcc")
                                                    current_metric.mcc = Convert.ToString(vdict[id_k]);
                                            } else if (current_line != null) {
                                                if (elename == "m")
                                                    current_line.m = Convert.ToInt32(vdict[id_k]);
                                                else if (elename == "d")
                                                    current_line.d = Convert.ToInt32(vdict[id_k]);
                                                else if (elename == "p")
                                                    current_line.p = Convert.ToInt32(vdict[id_k]);

                                            }
                                        }
                                    }

                                }
                        }

                    } else {
                        if (xr.HasAttributes) {
                            while (xr.MoveToNextAttribute()) {

                                string atr_key = xr.Name;
                                string atr_val = xr.Value;

                                if (atr_key == "xsi:type") {
                                    current_metric = null;
                                    current_line = null;
                                    if (atr_val.EndsWith("MetricWithMcc") || atr_val.EndsWith("Metric") || atr_val.EndsWith("LineWithMcc") || atr_val.EndsWith("Line")) {
                                        if (atr_val.EndsWith("MetricWithMcc") || atr_val.EndsWith("Metric")) {
                                            current_metric = new MetricWithMcc();
                                            metrics.Add(current_metric);
                                        } else if (atr_val.EndsWith("LineWithMcc") || atr_val.EndsWith("Line")) {

                                            current_line = new LineWithMcc();
                                            current_line.lineType = mode;
                                            lines.Add(current_line);
                                        }
                                        //todo add metric items...
                                        xr.MoveToElement();
                                        break;
                                    } else {
                                        xr.MoveToElement();
                                        break;
                                    }

                                }
                            }

                        }
                    }
                }
            }

        }



    }

    public class CostResponse
    {
        public List<MetricWithMcc> metrics = new List<MetricWithMcc>();
        public List<LineWithMcc> lines = new List<LineWithMcc>();
        public bool success = false;
    }

    public struct Product
    {
        public string SKU;
        public string OptCode;
    }

    public class ProductResponse
    {
        public string SKU;
        public string OptCode;
        //public List<Tuple<string, decimal>> Values = new List<Tuple<string, decimal>>();
        public List<MetricWithMcc> Metrics = new List<MetricWithMcc>();
        public List<LineWithMcc> Lines = new List<LineWithMcc>();
    }

    public class MetricWithMcc
    {

        public int p;

        public int d;

        public string mccField;

        public int m;

        public float? v;

        public string mcc;
    }
    public class LineWithMcc
    {

        public int p;

        public int d;

        public string mccField;

        public int m;

        public string lineType;

    }

}
