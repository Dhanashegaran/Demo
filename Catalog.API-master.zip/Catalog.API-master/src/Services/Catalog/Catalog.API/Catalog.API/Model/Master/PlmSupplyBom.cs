﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class PlmSupplyBom
    {
        public long Id { get; set; }
        public string Family { get; set; }
        public string Sku { get; set; }
        public string Description { get; set; }
        public string Supplytype { get; set; }
        public string Supplyloadtype { get; set; }
        public string Supplycolortype { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }
    }
}
