﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master.External.Corona {
    public class CoronaListPriceResponse {
        public string status { get; set; }
        public string message { get; set; }
        public string code { get; set; }
        public ListPriceResponse listPriceResponse { get; set; }
    }

    public class ListPriceProductInfo {
        public string productId { get; set; }
        public string priceStartDate { get; set; }
        public string priceEndDate { get; set; }
        public string listPrice { get; set; }
        public string priceStatus { get; set; }
        public string createdDate { get; set; }
        public string lastModifiedDate { get; set; }
        public string status { get; set; }

    }

    public class PriceDescriptor {
        public string Country { get; set; }
        public string Currency { get; set; }
        public string IncoTerm { get; set; }
        public string status { get; set; }
        public List<ListPriceProductInfo> listPriceProductInfo { get; set; }

    }

    public class ListPriceResponse {
        public List<PriceDescriptor> priceDescriptor { get; set; }
    }
}
