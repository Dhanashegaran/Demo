﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class cpq_llc_attributes_by_offer_by_country
    {
        public long id { get; set; }
        public string family { get; set; }
        public string sku { get; set; }
        public string l1offertype { get; set; }
        public string l2offertype { get; set; }
        public string region { get; set; }
        public string country { get; set; }
        public string printersku { get; set; }
        public decimal? monoyield { get; set; }
        public decimal? coloryield { get; set; }
        public decimal? professionalcoloryield { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
    }
}
