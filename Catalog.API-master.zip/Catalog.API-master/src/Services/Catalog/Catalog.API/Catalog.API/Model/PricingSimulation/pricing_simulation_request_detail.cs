﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.PricingSimulation {
    public class pricing_simulation_request_detail {

            
        public long requestdetailid { get; set; }
        [JsonIgnore]
        public string simulationid { get; set; }
        public string printersku { get; set; }
        public decimal targetbase { get; set; }
        public decimal? targetmonoclick { get; set; }
        public decimal? targetcolorclick { get; set; }
        public decimal? targetprofcolorclick { get; set; }
        public decimal? programdiscountpct { get; set; }
        public string printermonthlypagesoption { get; set; }
        public decimal? overridemonthlymonopages { get; set; }
        public decimal? overridemonthlyprofcolorpages { get; set; }
        public decimal? overridemonthlycolorpages { get; set; }
        public decimal? overridemonthlycolorsavepages { get; set; }
        public string suppliesyieldoption { get; set; }
        public decimal? operationalmonocoveragepct { get; set; }
        public decimal? operationalcolorcoveragepct { get; set; }
        [JsonIgnore]
        public string createdby { get; set; }
        [JsonIgnore]
        public string updatedby { get; set; }
        [JsonIgnore]
        public DateTime? createddate { get; set; }
        [JsonIgnore]
        public DateTime? updateddate { get; set; }


        //relationships
        public long requestid { get; set; }
        [JsonIgnore]
        public pricing_simulation_request pricing_simulation_request { get; set; }
    }
}
