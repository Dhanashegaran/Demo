﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class cpq_printer_class_attributes
    {
        public long id { get; set; }
        public string sku { get; set; }
        public string description { get; set; }
        public string shortdescription { get; set; }
        public string iscolor { get; set; }
        public string ismfp { get; set; }
        public string isa3 { get; set; }
        public string isink { get; set; }
        public string isflow { get; set; }
        public decimal? monoprintspeed { get; set; }
        public decimal? colorprintspeed { get; set; }
        public decimal? simplexscanspeed { get; set; }
        public decimal? duplexscanspeed { get; set; }
        public decimal? traycapacity { get; set; }
        public decimal? adfcapacity { get; set; }
        public decimal? rmpv { get; set; }
        public decimal? enginelife { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
    }
}
