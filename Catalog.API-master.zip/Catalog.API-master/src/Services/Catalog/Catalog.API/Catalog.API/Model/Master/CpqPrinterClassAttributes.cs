﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class CpqPrinterClassAttributes
    {
        public long Id { get; set; }
        public string Sku { get; set; }
        public string Description { get; set; }
        public string Shortdescription { get; set; }
        public string Iscolor { get; set; }
        public string Ismfp { get; set; }
        public string Isa3 { get; set; }
        public string Isink { get; set; }
        public string Isflow { get; set; }
        public decimal? Monoprintspeed { get; set; }
        public decimal? Colorprintspeed { get; set; }
        public decimal? Simplexscanspeed { get; set; }
        public decimal? Duplexscanspeed { get; set; }
        public decimal? Traycapacity { get; set; }
        public decimal? Adfcapacity { get; set; }
        public decimal? Rmpv { get; set; }
        public decimal? Enginelife { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? Createddate { get; set; }
        public DateTime? Updateddate { get; set; }
    }
}
