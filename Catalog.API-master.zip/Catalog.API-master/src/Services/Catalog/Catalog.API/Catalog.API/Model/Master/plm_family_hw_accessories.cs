﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class plm_family_hw_accessories
    {
        public long id { get; set; }
        public string family { get; set; }
        public string featuretype { get; set; }
        public string featurevalue { get; set; }
        public string sku { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
    }
}
