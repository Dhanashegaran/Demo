﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class cpq_default_sffo_by_offer_by_country
    {
        public long id { get; set; }
        public string suppliesfulfillmentoption { get; set; }
        public string l1offertype { get; set; }
        public string l2offertype { get; set; }
        public string region { get; set; }
        public string country { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }
    }
}
