﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class plm_family
    {
        public plm_family()
        {
            plm_series = new HashSet<plm_series>();
        }

        public long id { get; set; }
        public string family { get; set; }
        public string labname { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updateddate { get; set; }

        public virtual ICollection<plm_series> plm_series { get; set; }
    }
}
