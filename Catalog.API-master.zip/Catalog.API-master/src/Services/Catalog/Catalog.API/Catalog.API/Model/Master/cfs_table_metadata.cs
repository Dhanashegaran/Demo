﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class cfs_table_metadata
    {
        public long id { get; set; }
        public string table_name { get; set; }
        public string key_fields { get; set; }
        public string wildcard_fields { get; set; }
        public string date_fields { get; set; }
        public string range_fields { get; set; }
        public DateTime? update_dttm { get; set; }
        public string update_user { get; set; }
    }
}
