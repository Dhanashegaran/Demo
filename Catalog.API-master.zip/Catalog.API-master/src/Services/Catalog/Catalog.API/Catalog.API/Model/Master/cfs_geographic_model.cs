﻿using System;
using System.Collections.Generic;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class cfs_geographic_model
    {
        public long id { get; set; }
        public string table_name { get; set; }
        public string column_name { get; set; }
        public string mkey { get; set; }
        public string mapped_value { get; set; }
        public string iso_key { get; set; }
        public string createdby { get; set; }
        public string updatedby { get; set; }
        public DateTime? createddate { get; set; }
        public DateTime? updatedate { get; set; }
    }
}
