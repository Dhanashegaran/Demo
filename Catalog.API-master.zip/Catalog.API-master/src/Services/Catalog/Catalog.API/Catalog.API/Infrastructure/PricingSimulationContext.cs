﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Extensions;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using Microsoft.EntityFrameworkCore;
using Hp.ContractualFramework.Services.Catalog.API.Model.PricingSimulation;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hp.ContractualFramework.Services.Sample.API.Infrastructure {
    public class PricingSimulationContext : DbContext {

        public PricingSimulationContext(DbContextOptions<PricingSimulationContext> options) : base(options) {

        }

        public DbSet<pricing_simulation_request_header> PricingSimulationRequestHeader { get; set; }
        public DbSet<pricing_simulation_request_detail> PricingSimulationRequestDetail { get; set; }
        public DbSet<pricing_simulation_response_detail> PricingSimulationResponseDetail { get; set; }
        public DbSet<pricing_simulation_response_summary> PricingSimulationResponseSummary { get; set; }
        public DbSet<pricing_simulation_request> PricingSimulationRequest { get; set; }
        public DbSet<pricing_simulation_response> PricingSimulationResponse { get; set; }

        public DbSet<pricing_simulation_model_template> PricingSimulationModelTemplate { get; set; }
        public DbSet<pricing_simulation_model_template_field> PricingSimulationModelTemplateField { get; set; }
        public DbSet<pricing_catalog> PricingCatalog { get; set; }

        protected override void OnModelCreating(ModelBuilder builder) {

            builder.HasDefaultSchema("pricing_simulation");

            //request
            builder.Entity<pricing_simulation_request>(ConfigurePricingSimulationRequest);
            builder.Entity<pricing_simulation_request_header>(ConfigurePricingSimulationRequestHeader);
            builder.Entity<pricing_simulation_request_detail>(ConfigurePricingSimulationRequestDetail);

            //response
            builder.Entity<pricing_simulation_response>(ConfigurePricingSimulationResponse);
            builder.Entity<pricing_simulation_response_summary>(ConfigurePricingSimulationResponseSummary);
            builder.Entity<pricing_simulation_response_detail>(ConfigurePricingSimulationResponseDetail);

            //templates
            builder.Entity<pricing_simulation_model_template>(ConfigurePricingSimulationModelTemplate);
            builder.Entity<pricing_simulation_model_template_field>(ConfigurePricingSimulationModelTemplateField);

            //Pricing Catalog
            builder.Entity<pricing_catalog>(ConfigurePricingCatalog);

        }

        //request
        void ConfigurePricingSimulationRequest(EntityTypeBuilder<pricing_simulation_request> builder) {

            builder.ToTable("pricing_simulation_request");
            builder.HasKey(e => e.requestid);
            builder.Property(e => e.simulationid).IsRequired();
            builder.Property(e => e.simulationid).HasMaxLength(255);
            builder.HasIndex(e => e.simulationid).IsUnique();
            builder.HasOne(e => e.requestheader);
            builder.HasMany(e => e.requestdetail);

        }
        void ConfigurePricingSimulationRequestHeader(EntityTypeBuilder<pricing_simulation_request_header> builder) {

            builder.ToTable("pricing_simulation_request_header");
            builder.HasKey(e => e.requestheaderid);
            builder.HasOne(p => p.pricing_simulation_request);
            builder.Property(e => e.simulationid).HasMaxLength(255);
            builder.Property(e => e.simulationid).IsRequired();

            //Propery types for decimal fields
            builder.Property(e => e.currencyrate).HasColumnType("decimal(18, 8)");
        }
        void ConfigurePricingSimulationRequestDetail(EntityTypeBuilder<pricing_simulation_request_detail> builder) {

            builder.ToTable("pricing_simulation_request_detail");
            builder.HasKey(e => e.requestdetailid);
            builder.HasOne(p => p.pricing_simulation_request);
            builder.Property(e => e.simulationid).HasMaxLength(255);
            builder.Property(e => e.simulationid).IsRequired();

            //Propery types for Percentage fields
            builder.Property(e => e.programdiscountpct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.operationalmonocoveragepct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.operationalcolorcoveragepct).HasColumnType("decimal(18, 4)");

            //Propery types for decimal fields
            builder.Property(e => e.targetbase).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.targetmonoclick).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.targetcolorclick).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.targetprofcolorclick).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.overridemonthlymonopages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.overridemonthlyprofcolorpages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.overridemonthlycolorpages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.overridemonthlycolorsavepages).HasColumnType("decimal(18, 8)");
        }

        //response
        void ConfigurePricingSimulationResponse(EntityTypeBuilder<pricing_simulation_response> builder) {

            builder.ToTable("pricing_simulation_response");
            builder.HasKey(e => e.responseid);
            builder.Property(e => e.simulationid).IsRequired();
            builder.Property(e => e.simulationid).HasMaxLength(255);
            builder.HasIndex(e => e.simulationid).IsUnique();
            builder.HasMany(e => e.responsedetail);
            builder.HasMany(e => e.responsesummary);

        }
        void ConfigurePricingSimulationResponseSummary(EntityTypeBuilder<pricing_simulation_response_summary> builder) {

            builder.ToTable("pricing_simulation_response_summary");
            builder.HasKey(e => e.responsesummaryid);
            builder.HasOne(p => p.pricing_simulation_response);
            builder.Property(e => e.simulationid).IsRequired();
            builder.Property(e => e.simulationid).HasMaxLength(255);

            //Propery types for Percentage fields
            builder.Property(e => e.systemmarginpct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.hardwaremarginpct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.suppliesmarginpct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.servicemarginpct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.breakfixmarginpct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.kitmarginpct).HasColumnType("decimal(18, 4)");

            //Propery types for decimal fields
            builder.Property(e => e.defaultmonthlymonopages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.defaultmonthlyprofcolorpages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.defaultmonthlycolorpages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.defaultmonthlycolorsavepages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.monthlymonopages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.monthlyprofcolorpages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.monthlycolorpages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.monthlycolorsavepages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.totalmonthlypages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.totalcontractmonopages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.totalcontractprofcolorpages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.totalcontractcolorpages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.totalcontractcolorsavepages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.totalcontractpages).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.totaldirectpurchasehardware).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.basefee).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.monoclick).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.profcolorclick).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.colorclick).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.colorsaveclick).HasColumnType("decimal(18, 8)");


        }
        void ConfigurePricingSimulationResponseDetail(EntityTypeBuilder<pricing_simulation_response_detail> builder) {

            builder.ToTable("pricing_simulation_response_detail");
            builder.HasKey(e => e.responsedetailid);
            builder.HasOne(p => p.pricing_simulation_response);
            builder.Property(e => e.simulationid).IsRequired();
            builder.Property(e => e.simulationid).HasMaxLength(255);


            //Propery types for Percentage fields
            builder.Property(e => e.targetmarginpct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.contractualdiscountpct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.maxpricepct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.msppct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.contractualdiscountpct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.truckloaddiscountpct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.tier1pct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.tier2pct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.tier3pct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.tier4pct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.isocoveragepct).HasColumnType("decimal(18, 4)");
            builder.Property(e => e.operationalcoveragepct).HasColumnType("decimal(18, 4)");

            //Propery types for decimal fields
            builder.Property(e => e.tcos).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.tcoscurrencyrate).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.lclpcurrencyrate).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.lclp).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.bdnetprice).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.bdnetpricecurrencyrate).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.isomonoyield).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.isocoloryield).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.isoprofcoloryield).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.isocolorsaveyield).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.tcossimulationcurrencyrate).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.lclpsimulationcurrencyrate).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.bdnetsimulationcurrencyrate).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.unitcost).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.targetmarginnetprice).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.listprice).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.ndp).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.maxprice).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.msp).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.streetprice).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.bdnetpricetier0).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.bdnetpricetier1).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.bdnetpricetier2).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.bdnetpricetier3).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.bdnetpricetier4).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.discountednetprice).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.netprice).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.operationalmonoonmonoyield).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.operationalmonoonprofessionalcoloryield).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.operationalmonooncoloryield).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.operationalmonooncolorsaveyield).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.operationalprofcoloryield).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.operationalcoloryield).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.operationacolorsaveyield).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.componentqty).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.componentbasefee).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.componentmonoclick).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.componentprofcolorclick).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.componentcolorclick).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.componentcolorsaveclick).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.extendednetprice).HasColumnType("decimal(18, 8)");
            builder.Property(e => e.extendedcost).HasColumnType("decimal(18, 8)");


        }

        //templates
        void ConfigurePricingSimulationModelTemplate(EntityTypeBuilder<pricing_simulation_model_template> builder) {

            builder.ToTable("pricing_simulation_model_template");
            builder.HasKey(e => e.templateid);
            builder.Property(e => e.templatename).HasMaxLength(255);
            builder.Property(e => e.templatename).IsRequired();
            builder.Property(e => e.templategroup).HasMaxLength(255);
            builder.Property(e => e.templategroup).IsRequired();
            builder.Property(e => e.enabled).HasDefaultValue(true);

        }
        void ConfigurePricingSimulationModelTemplateField(EntityTypeBuilder<pricing_simulation_model_template_field> builder) {

            builder.ToTable("pricing_simulation_model_template_field");
            builder.HasKey(e => e.fieldid);
            builder.Property(e => e.fieldname).IsRequired();
            builder.Property(e => e.fieldname).HasMaxLength(255);
            builder.HasOne(e => e.pricing_simulation_model_template);
            builder.Property(e => e.enabled).HasDefaultValue(true);
        }

        void ConfigurePricingCatalog(EntityTypeBuilder<pricing_catalog> builder) {
            builder.ToTable("pricing_catalog");
            builder.HasKey(e => new { e.printersku, e.effectivestartdate, e.effectiveenddate });
            builder.Property(e => e.enabled).HasDefaultValue(true);
        }
    }
}
