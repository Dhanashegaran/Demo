﻿using Hp.ContractualFramework.Services.Catalog.API.Model.Master.External.Corona;
using Refit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hp.ContractualFramework.Services.Sample.API.Infrastructure {
    public interface ICoronaApi {

        [Post("/2.0/ListPrice")]
           Task<CoronaListPriceResponse> GetListPriceAsync([Body] CoronaListPriceRequest input);
    }
}
