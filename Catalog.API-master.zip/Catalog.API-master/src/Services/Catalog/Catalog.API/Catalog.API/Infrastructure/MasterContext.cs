﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Hp.ContractualFramework.Services.Catalog.API.Model.Master
{
    public partial class MasterContext : DbContext
    {
        public MasterContext()
        {
        }

        public MasterContext(DbContextOptions<MasterContext> options)
            : base(options)
        {
        }

        public virtual DbSet<cfs_geographic_model> cfs_geographic_model { get; set; }
        public virtual DbSet<cfs_table_metadata> cfs_table_metadata { get; set; }
        public virtual DbSet<cpq_billing_models> cpq_billing_models { get; set; }
        public virtual DbSet<cpq_billing_models_by_offer_by_country> cpq_billing_models_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_category_pricing_by_offer_by_country> cpq_category_pricing_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_country> cpq_country { get; set; }
        public virtual DbSet<cpq_default_bm_by_offer_by_country> cpq_default_bm_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_default_hwffo_by_offer_by_country> cpq_default_hwffo_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_default_hwpo_by_offer_by_country> cpq_default_hwpo_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_default_ko_by_offer_by_country> cpq_default_ko_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_default_margin_template_by_offer> cpq_default_margin_template_by_offer { get; set; }
        public virtual DbSet<cpq_default_sffo_by_offer_by_country> cpq_default_sffo_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_default_sla_by_offer_by_country> cpq_default_sla_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_hw_fulfillment_options> cpq_hw_fulfillment_options { get; set; }
        public virtual DbSet<cpq_hw_fulfillment_options_by_offer_by_country> cpq_hw_fulfillment_options_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_hw_purchase_options> cpq_hw_purchase_options { get; set; }
        public virtual DbSet<cpq_hw_purchase_options_by_offer_by_country> cpq_hw_purchase_options_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_kit_options> cpq_kit_options { get; set; }
        public virtual DbSet<cpq_kit_options_by_offer_by_country> cpq_kit_options_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_llc_attributes_by_offer_by_country> cpq_llc_attributes_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_local_cost_by_offer> cpq_local_cost_by_offer { get; set; }
        public virtual DbSet<cpq_local_price_by_offer> cpq_local_price_by_offer { get; set; }
        public virtual DbSet<cpq_margin_targets_by_offer_by_country> cpq_margin_targets_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_margin_template_by_offer> cpq_margin_template_by_offer { get; set; }
        public virtual DbSet<cpq_max_price_by_offer_by_country> cpq_max_price_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_msp_by_offer_by_country> cpq_msp_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_price_cost_source_by_offer_by_country> cpq_price_cost_source_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_price_descriptor_by_offer_by_country> cpq_price_descriptor_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_printer_accessory_by_offer_by_country> cpq_printer_accessory_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_printer_by_offer_by_country> cpq_printer_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_printer_class_attributes> cpq_printer_class_attributes { get; set; }
        public virtual DbSet<cpq_printer_class_attributes_by_offer_by_country> cpq_printer_class_attributes_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_printer_llc_by_offer_by_country> cpq_printer_llc_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_printer_service_part_by_offer_by_country> cpq_printer_service_part_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_printer_status_by_offer_by_country> cpq_printer_status_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_printer_supply_by_offer_by_country> cpq_printer_supply_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_pw_supply_attributes_by_offer_by_country> cpq_pw_supply_attributes_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_rate_table_by_offer_by_country> cpq_rate_table_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_service_levels> cpq_service_levels { get; set; }
        public virtual DbSet<cpq_service_levels_by_offer_by_country> cpq_service_levels_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_service_part_attributes_by_offer_by_country> cpq_service_part_attributes_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_service_part_pricing_by_offer_by_country> cpq_service_part_pricing_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_standard_discounts_by_offer_by_country> cpq_standard_discounts_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_supplies_fulfillment_options> cpq_supplies_fulfillment_options { get; set; }
        public virtual DbSet<cpq_supplies_fulfillment_options_by_offer_by_country> cpq_supplies_fulfillment_options_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_supply_attributes_by_offer_by_country> cpq_supply_attributes_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_supply_program_by_offer_by_country> cpq_supply_program_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_truckload_discounts_by_offer_by_country> cpq_truckload_discounts_by_offer_by_country { get; set; }
        public virtual DbSet<cpq_volume_discounts_by_offer_by_country> cpq_volume_discounts_by_offer_by_country { get; set; }
        public virtual DbSet<gpsy_price> gpsy_price { get; set; }
        public virtual DbSet<gtm_country> gtm_country { get; set; }
        public virtual DbSet<gtm_item_class> gtm_item_class { get; set; }
        public virtual DbSet<gtm_offer_type> gtm_offer_type { get; set; }
        public virtual DbSet<gtm_offer_type_by_country> gtm_offer_type_by_country { get; set; }
        public virtual DbSet<gtm_region> gtm_region { get; set; }
        public virtual DbSet<plm_configrable_services> plm_configrable_services { get; set; }
        public virtual DbSet<plm_cto_hw_bom> plm_cto_hw_bom { get; set; }
        public virtual DbSet<plm_family> plm_family { get; set; }
        public virtual DbSet<plm_family_hw_accessories> plm_family_hw_accessories { get; set; }
        public virtual DbSet<plm_llc_bom> plm_llc_bom { get; set; }
        public virtual DbSet<plm_model> plm_model { get; set; }
        public virtual DbSet<plm_mv_model> plm_mv_model { get; set; }
        public virtual DbSet<plm_pab_hw_bom> plm_pab_hw_bom { get; set; }
        public virtual DbSet<plm_preconfigured_hw_bom> plm_preconfigured_hw_bom { get; set; }
        public virtual DbSet<plm_preconfigured_services> plm_preconfigured_services { get; set; }
        public virtual DbSet<plm_series> plm_series { get; set; }
        public virtual DbSet<plm_service_part_bom> plm_service_part_bom { get; set; }
        public virtual DbSet<plm_sku> plm_sku { get; set; }
        public virtual DbSet<plm_sku_attributes> plm_sku_attributes { get; set; }
        public virtual DbSet<plm_supply_bom> plm_supply_bom { get; set; }
        public virtual DbSet<scott_tables> scott_tables { get; set; }
        public virtual DbSet<treasury_currency> treasury_currency { get; set; }
        public virtual DbSet<treasury_currency_rate> treasury_currency_rate { get; set; }
        public virtual DbSet<treasury_currency_rate_table> treasury_currency_rate_table { get; set; }

        // Unable to generate entity type for table 'HpcsfMaster.cpq_c4_cost'. Please see the warning messages.

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseNpgsql("Host=G1w9448.austin.hpicorp.net;Database=HpcsfCatalogApi;Username=postgres;Password=Work.Together@12");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.1-servicing-10028");

            modelBuilder.Entity<cfs_geographic_model>(entity =>
            {
                entity.ToTable("cfs_geographic_model", "hpcsf_master");

                entity.Property(e => e.id).ValueGeneratedNever();

                entity.Property(e => e.column_name)
                    .IsRequired()
                    .HasMaxLength(65);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.iso_key)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.mapped_value)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.mkey)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.table_name)
                    .IsRequired()
                    .HasMaxLength(65);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cfs_table_metadata>(entity =>
            {
                entity.ToTable("cfs_table_metadata", "hpcsf_master");

                entity.HasIndex(e => e.table_name)
                    .HasName("uid_table_metadata_tablename")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.date_fields).HasMaxLength(100);

                entity.Property(e => e.key_fields).HasMaxLength(150);

                entity.Property(e => e.range_fields).HasMaxLength(100);

                entity.Property(e => e.table_name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.update_dttm).HasColumnType("date");

                entity.Property(e => e.update_user).HasMaxLength(25);

                entity.Property(e => e.wildcard_fields).HasMaxLength(150);
            });

            modelBuilder.Entity<cpq_billing_models>(entity =>
            {
                entity.ToTable("cpq_billing_models", "hpcsf_master");

                entity.HasIndex(e => e.billingmodel)
                    .HasName("uid_billing_models_bm")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.billingmodel).HasMaxLength(10);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.description).HasMaxLength(60);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_billing_models_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_billing_models_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.billingmodel, e.l1offertype, e.l2offertype, e.country, e.region })
                    .HasName("idx_billing_models_by_offer_bm");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.billingmodel).HasMaxLength(10);

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_category_pricing_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_category_pricing_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("uid_category_pricing_sku");

                entity.HasIndex(e => new { e.currency, e.sku })
                    .HasName("uid_category_pricing_currency_sku");

                entity.HasIndex(e => new { e.sku, e.currency })
                    .HasName("uid_category_pricing_sku_currency");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country).HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.currency).HasMaxLength(4);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.netprice).HasColumnType("numeric(18,8)");

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_country>(entity =>
            {
                entity.HasKey(e => e.isocountrycode)
                    .HasName("pk_cpq_country_iso_country_code");

                entity.ToTable("cpq_country", "hpcsf_master");

                entity.HasIndex(e => e.isocountrycode)
                    .HasName("uid_cpq_country_isocountry")
                    .IsUnique();

                entity.Property(e => e.isocountrycode)
                    .HasMaxLength(3)
                    .ValueGeneratedNever();

                entity.Property(e => e.cpqcountryflag).HasMaxLength(20);

                entity.Property(e => e.createdby).HasMaxLength(30);

                entity.Property(e => e.updatedby).HasMaxLength(30);
            });

            modelBuilder.Entity<cpq_default_bm_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_default_bm_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.billingmodel, e.l1offertype, e.l2offertype, e.country, e.region })
                    .HasName("idx_cpq_default_bm_by_offer_bm");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.billingmodel).HasMaxLength(10);

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_default_hwffo_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_default_hwffo_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.hwfulfillmentoption, e.l1offertype, e.l2offertype, e.country, e.region })
                    .HasName("idx_default_hwffo_by_offer_hwffo")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.hwfulfillmentoption).HasMaxLength(30);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_default_hwpo_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_default_hwpo_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.hwpurchaseoption, e.l1offertype, e.l2offertype, e.country, e.region })
                    .HasName("idx_default_hwpo_by_offer")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.hwpurchaseoption).HasMaxLength(30);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_default_ko_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_default_ko_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.kitoption, e.l1offertype, e.l2offertype, e.country, e.region })
                    .HasName("idx_default_ko_by_offer_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.kitoption).HasMaxLength(30);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_default_margin_template_by_offer>(entity =>
            {
                entity.ToTable("cpq_default_margin_template_by_offer", "hpcsf_master");

                entity.HasIndex(e => new { e.margintemplate, e.l1offertype, e.l2offertype })
                    .HasName("idx_default_margin_template_by_offer_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.margintemplate).HasMaxLength(30);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_default_sffo_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_default_sffo_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.suppliesfulfillmentoption, e.l1offertype, e.l2offertype, e.country, e.region })
                    .HasName("idx_default_sffo_by_offer_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.suppliesfulfillmentoption)
                    .IsRequired()
                    .HasMaxLength(60);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_default_sla_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_default_sla_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.sla, e.l1offertype, e.l2offertype, e.country, e.region })
                    .HasName("idx_default_sla_by_offer_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sla).HasMaxLength(16);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_hw_fulfillment_options>(entity =>
            {
                entity.ToTable("cpq_hw_fulfillment_options", "hpcsf_master");

                entity.HasIndex(e => new { e.hwfulfillmentoption, e.hwfulfillmentchannel })
                    .HasName("idx_hw_fulfillment_options_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.description).HasMaxLength(60);

                entity.Property(e => e.hwfulfillmentchannel).HasMaxLength(30);

                entity.Property(e => e.hwfulfillmentoption).HasMaxLength(30);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_hw_fulfillment_options_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_hw_fulfillment_options_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.hwfulfillmentoption, e.l1offertype, e.l2offertype, e.country, e.region })
                    .HasName("idx_hw_fulfillment_options_by_offer_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.hwfulfillmentoption).HasMaxLength(30);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_hw_purchase_options>(entity =>
            {
                entity.ToTable("cpq_hw_purchase_options", "hpcsf_master");

                entity.HasIndex(e => e.hwpurchaseoption)
                    .HasName("idx_hw_purchase_options")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.description).HasMaxLength(60);

                entity.Property(e => e.hwpurchaseoption).HasMaxLength(30);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_hw_purchase_options_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_hw_purchase_options_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.hwpurchaseoption, e.l1offertype, e.l2offertype, e.country, e.region })
                    .HasName("idx_hw_purchase_options_by_offer_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.hwpurchaseoption).HasMaxLength(30);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_kit_options>(entity =>
            {
                entity.ToTable("cpq_kit_options", "hpcsf_master");

                entity.HasIndex(e => e.kitoption)
                    .HasName("idx_cpq_kit_options_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.description).HasMaxLength(60);

                entity.Property(e => e.kitoption).HasMaxLength(30);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_kit_options_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_kit_options_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.kitoption, e.l1offertype, e.l2offertype, e.country, e.region })
                    .HasName("idx_kit_options_by_offer_by_country_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.kitoption).HasMaxLength(30);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_llc_attributes_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_llc_attributes_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.printersku)
                    .HasName("idx_printersku_llc_attributes");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_llc_attributes");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.coloryield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.monoyield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.printersku).HasMaxLength(20);

                entity.Property(e => e.professionalcoloryield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_local_cost_by_offer>(entity =>
            {
                entity.ToTable("cpq_local_cost_by_offer", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_loc");

                entity.HasIndex(e => new { e.country, e.sku })
                    .HasName("idx_cpq_local_cost_by_offer_countrysku");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.currency).HasMaxLength(4);

                entity.Property(e => e.iso2currency).HasMaxLength(3);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.tcos).HasColumnType("numeric(18,8)");

                entity.Property(e => e.updatedby).HasMaxLength(60);

                entity.Property(e => e.vcos).HasColumnType("numeric(18,8)");
            });

            modelBuilder.Entity<cpq_local_price_by_offer>(entity =>
            {
                entity.ToTable("cpq_local_price_by_offer", "hpcsf_master");

                entity.HasIndex(e => new { e.effstartdate, e.effenddate })
                    .HasName("idx_cpq_local_price_by_offer_start_end_effdate");

                entity.HasIndex(e => new { e.l2offertype, e.l1offertype })
                    .HasName("idx_cpq_local_price_by_offer_l2_l1");

                entity.HasIndex(e => new { e.sku, e.pricedescriptor })
                    .HasName("idx_cpq_local_price_by_offer_sku_pricedesc");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.listprice).HasColumnType("numeric(18,8)");

                entity.Property(e => e.pricedescriptor).HasMaxLength(6);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_margin_targets_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_margin_targets_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.printersku)
                    .HasName("idx_printersku_margin_targets");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_margin_targets");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e._class)
                    .HasColumnName("class")
                    .HasMaxLength(20);

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.margintemplate).HasMaxLength(30);

                entity.Property(e => e.printersku).HasMaxLength(20);

                entity.Property(e => e.productline).HasMaxLength(2);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.targetmarginpct).HasColumnType("numeric(18,8)");

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_margin_template_by_offer>(entity =>
            {
                entity.ToTable("cpq_margin_template_by_offer", "hpcsf_master");

                entity.HasIndex(e => new { e.margintemplate, e.l1offertype, e.l2offertype })
                    .HasName("idx_margin_template_by_offer_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.margintemplate).HasMaxLength(30);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_max_price_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_max_price_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_max_price_by_o");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.maxpricepct).HasColumnType("numeric(18,8)");

                entity.Property(e => e.productline).HasMaxLength(2);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_msp_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_msp_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_msp_by_offer_b");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.msppct).HasColumnType("numeric(18,8)");

                entity.Property(e => e.productline).HasMaxLength(2);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_price_cost_source_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_price_cost_source_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_price_cost_sou");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.costsource).HasMaxLength(20);

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.pricesource).HasMaxLength(20);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_price_descriptor_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_price_descriptor_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.country)
                    .HasName("idx_cpq_price_descriptor_by_offer_by_country_country");

                entity.HasIndex(e => new { e.l2offertype, e.l1offertype })
                    .HasName("idx_cpq_price_descriptor_by_offer_by_country_l2_l1");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country).HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.defaultflag).HasMaxLength(10);

                entity.Property(e => e.itemclass).HasMaxLength(20);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.pricedescriptor).HasMaxLength(6);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_printer_accessory_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_printer_accessory_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.printersku)
                    .HasName("idx_printersku_printer_access");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_printer_access");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.cpqaccessoryflag).HasMaxLength(10);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.enableflag).HasMaxLength(1);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.printersku).HasMaxLength(20);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_printer_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_printer_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_printer_by_off");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.cpqflag).HasMaxLength(20);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_printer_class_attributes>(entity =>
            {
                entity.ToTable("cpq_printer_class_attributes", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_printer_class_attributes");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.adfcapacity).HasColumnType("numeric(18,8)");

                entity.Property(e => e.colorprintspeed).HasColumnType("numeric(18,8)");

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.description).HasMaxLength(60);

                entity.Property(e => e.duplexscanspeed).HasColumnType("numeric(18,8)");

                entity.Property(e => e.enginelife).HasColumnType("numeric(18,8)");

                entity.Property(e => e.isa3).HasMaxLength(1);

                entity.Property(e => e.iscolor).HasMaxLength(1);

                entity.Property(e => e.isflow).HasMaxLength(1);

                entity.Property(e => e.isink).HasMaxLength(1);

                entity.Property(e => e.ismfp).HasMaxLength(1);

                entity.Property(e => e.monoprintspeed).HasColumnType("numeric(18,8)");

                entity.Property(e => e.rmpv).HasColumnType("numeric(18,8)");

                entity.Property(e => e.shortdescription).HasMaxLength(50);

                entity.Property(e => e.simplexscanspeed).HasColumnType("numeric(18,8)");

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.traycapacity).HasColumnType("numeric(18,8)");

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_printer_class_attributes_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_printer_class_attributes_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_printer_class_");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.defaultmonthlycolorpages).HasColumnType("numeric(18,8)");

                entity.Property(e => e.defaultmonthlycolorsavepages).HasColumnType("numeric(18,8)");

                entity.Property(e => e.defaultmonthlymonopages).HasColumnType("numeric(18,8)");

                entity.Property(e => e.defaultmonthlyprofcolorpages).HasColumnType("numeric(18,8)");

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_printer_llc_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_printer_llc_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.printersku)
                    .HasName("idx_printersku_printer_llc_by");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_printer_llc_by");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.cpqflag).HasMaxLength(20);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.printersku).HasMaxLength(20);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);

                entity.HasOne(d => d.printerskuNavigation)
                    .WithMany(p => p.cpq_printer_llc_by_offer_by_country)
                    .HasForeignKey(d => d.printersku)
                    .HasConstraintName("fk_printer_llc_by_prn_sku");
            });

            modelBuilder.Entity<cpq_printer_service_part_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_printer_service_part_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.printersku)
                    .HasName("idx_printersku_printer_servic");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_printer_servic");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.cpqflag).HasMaxLength(20);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.printersku).HasMaxLength(20);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);

                entity.HasOne(d => d.printerskuNavigation)
                    .WithMany(p => p.cpq_printer_service_part_by_offer_by_country)
                    .HasForeignKey(d => d.printersku)
                    .HasConstraintName("fk_printer_service_part_prn_sku");
            });

            modelBuilder.Entity<cpq_printer_status_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_printer_status_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_printer_status");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.productstatus).HasMaxLength(3);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_printer_supply_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_printer_supply_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.printersku)
                    .HasName("idx_printersku_printer_supply");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_printer_supply");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.cpqsupplyflag).HasMaxLength(20);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.printersku).HasMaxLength(20);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);

                entity.HasOne(d => d.printerskuNavigation)
                    .WithMany(p => p.cpq_printer_supply_by_offer_by_country)
                    .HasForeignKey(d => d.printersku)
                    .HasConstraintName("fk_printer_supply_prn_sku");
            });

            modelBuilder.Entity<cpq_pw_supply_attributes_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_pw_supply_attributes_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.printersku)
                    .HasName("idx_printersku_pw_supply_attr");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_pw_supply_attr");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.colorsavereductionpct).HasColumnType("numeric(18,8)");

                entity.Property(e => e.costratiocolor).HasColumnType("numeric(18,8)");

                entity.Property(e => e.costratiomono).HasColumnType("numeric(18,8)");

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.customeravailableink).HasColumnType("numeric(18,8)");

                entity.Property(e => e.generalofficereductionpct).HasColumnType("numeric(18,8)");

                entity.Property(e => e.inkperpage).HasColumnType("numeric(18,8)");

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.maintinkintercept).HasColumnType("numeric(18,8)");

                entity.Property(e => e.maintinklowvolintercept).HasColumnType("numeric(18,8)");

                entity.Property(e => e.maintinklowvolslope).HasColumnType("numeric(18,8)");

                entity.Property(e => e.maintinklowvolumethreshold).HasColumnType("numeric(18,8)");

                entity.Property(e => e.maintinklslope).HasColumnType("numeric(18,8)");

                entity.Property(e => e.printersku).HasMaxLength(20);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);

                entity.HasOne(d => d.printerskuNavigation)
                    .WithMany(p => p.cpq_pw_supply_attributes_by_offer_by_country)
                    .HasForeignKey(d => d.printersku)
                    .HasConstraintName("fk_pw_supply_attr_prn_sku");
            });

            modelBuilder.Entity<cpq_rate_table_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_rate_table_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.ratetable, e.l1offertype, e.l2offertype, e.country, e.region })
                    .HasName("idx_rate_table_by_offer_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.ratetable).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_service_levels>(entity =>
            {
                entity.ToTable("cpq_service_levels", "hpcsf_master");

                entity.HasIndex(e => e.sla)
                    .HasName("idx_sla_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.description).HasMaxLength(60);

                entity.Property(e => e.sla).HasMaxLength(16);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_service_levels_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_service_levels_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.sla, e.l1offertype, e.l2offertype, e.country, e.region })
                    .HasName("idx_sla_by_offer_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sla).HasMaxLength(16);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_service_part_attributes_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_service_part_attributes_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.printersku)
                    .HasName("idx_printersku_service_part_a");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_service_part_a");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.air).HasMaxLength(20);

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.printersku).HasMaxLength(20);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);

                entity.HasOne(d => d.printerskuNavigation)
                    .WithMany(p => p.cpq_service_part_attributes_by_offer_by_country)
                    .HasForeignKey(d => d.printersku)
                    .HasConstraintName("fk_service_part_a_prn_sku");
            });

            modelBuilder.Entity<cpq_service_part_pricing_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_service_part_pricing_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_service_part_p");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country).HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.currency).HasMaxLength(4);

                entity.Property(e => e.discount).HasColumnType("numeric(18,8)");

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.listprice).HasColumnType("numeric(18,8)");

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);

                entity.Property(e => e.usellcpriceflag).HasMaxLength(10);

                entity.Property(e => e.warrantycredit).HasColumnType("numeric(18,8)");
            });

            modelBuilder.Entity<cpq_standard_discounts_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_standard_discounts_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_standard_disco");

                entity.HasIndex(e => new { e.productline, e.sku })
                    .HasName("idx_sku_standard_discount_pl_sku");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country).HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.productline).HasMaxLength(2);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.standarddiscountpct).HasColumnType("numeric(18,8)");

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_supplies_fulfillment_options>(entity =>
            {
                entity.ToTable("cpq_supplies_fulfillment_options", "hpcsf_master");

                entity.HasIndex(e => new { e.suppliesfulfillmentoption, e.suppliesfulfillmentchannel })
                    .HasName("idx_supplies_fulfillment_options_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.description).HasMaxLength(60);

                entity.Property(e => e.suppliesfulfillmentchannel)
                    .IsRequired()
                    .HasMaxLength(60);

                entity.Property(e => e.suppliesfulfillmentoption)
                    .IsRequired()
                    .HasMaxLength(60);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_supplies_fulfillment_options_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_supplies_fulfillment_options_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.suppliesfulfillmentoption, e.l1offertype, e.l2offertype, e.country, e.region })
                    .HasName("idx_supplies_fulfillment_options_by_offer_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.suppliesfulfillmentoption)
                    .IsRequired()
                    .HasMaxLength(60);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_supply_attributes_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_supply_attributes_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.printersku)
                    .HasName("idx_printersku_supply_attribu");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_supply_attribu");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.isocolorsaveyield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.isocoloryield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.isocoveragepct).HasColumnType("numeric(18,8)");

                entity.Property(e => e.isomonoyield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.isoprofessionalcoloryield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.operationalyieldcalcmethod).HasMaxLength(30);

                entity.Property(e => e.printersku).HasMaxLength(20);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.startercolorsaveyield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.startercoloryield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.startermonoyield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.starterprofessionalcoloryield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.updatedby).HasMaxLength(60);

                entity.HasOne(d => d.printerskuNavigation)
                    .WithMany(p => p.cpq_supply_attributes_by_offer_by_country)
                    .HasForeignKey(d => d.printersku)
                    .HasConstraintName("fk_supply_attribu_prn_sku");
            });

            modelBuilder.Entity<cpq_supply_program_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_supply_program_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.printersku)
                    .HasName("idx_printersku_supply_program");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_supply_program");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.printersku).HasMaxLength(20);

                entity.Property(e => e.programcoloryield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.programmonoyield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.programprofessionalcoloryield).HasColumnType("numeric(18,8)");

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.supplyprogram).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);

                entity.HasOne(d => d.printerskuNavigation)
                    .WithMany(p => p.cpq_supply_program_by_offer_by_country)
                    .HasForeignKey(d => d.printersku)
                    .HasConstraintName("fk_supply_program_prn_sku");
            });

            modelBuilder.Entity<cpq_truckload_discounts_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_truckload_discounts_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_truckload_disc");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.productline).HasMaxLength(2);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.truckloaddiscountpct).HasColumnType("numeric(18,8)");

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<cpq_volume_discounts_by_offer_by_country>(entity =>
            {
                entity.ToTable("cpq_volume_discounts_by_offer_by_country", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_volume_discoun");

                entity.HasIndex(e => new { e.productline, e.sku })
                    .HasName("idx_sku_volume_discounts_pl_sku");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.productline).HasMaxLength(2);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.tier1pct).HasColumnType("numeric(18,8)");

                entity.Property(e => e.tier2pct).HasColumnType("numeric(18,8)");

                entity.Property(e => e.tier3pct).HasColumnType("numeric(18,8)");

                entity.Property(e => e.tier4pct).HasColumnType("numeric(18,8)");

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<gpsy_price>(entity =>
            {
                entity.ToTable("gpsy_price", "hpcsf_master");

                entity.HasIndex(e => e.prod_base)
                    .HasName("uid_gpsy_prod_base");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.calc_ref_prc_amt).HasColumnType("numeric(18,6)");

                entity.Property(e => e.ctry_cd).HasMaxLength(6);

                entity.Property(e => e.curr_cd).HasMaxLength(6);

                entity.Property(e => e.end_dt_cd).HasMaxLength(3);

                entity.Property(e => e.end_eff_dt).HasColumnType("date");

                entity.Property(e => e.last_mod_tmstmp).HasColumnType("date");

                entity.Property(e => e.lclp).HasColumnType("numeric(18,6)");

                entity.Property(e => e.opt).HasMaxLength(20);

                entity.Property(e => e.prc_meth_cd).HasMaxLength(3);

                entity.Property(e => e.prc_term_cd).HasMaxLength(6);

                entity.Property(e => e.process_nm).HasMaxLength(24);

                entity.Property(e => e.prod_base).HasMaxLength(20);

                entity.Property(e => e.prod_nbr).HasMaxLength(20);

                entity.Property(e => e.qb_set_nbr).HasColumnType("numeric(18,8)");

                entity.Property(e => e.qbl_seq_nbr).HasColumnType("numeric(18,8)");

                entity.Property(e => e.start_eff_dt).HasColumnType("date");

                entity.Property(e => e.user_logon_id).HasMaxLength(24);
            });

            modelBuilder.Entity<gtm_country>(entity =>
            {
                entity.HasKey(e => e.countrycode)
                    .HasName("pk_gtm_country");

                entity.ToTable("gtm_country", "hpcsf_master");

                entity.HasIndex(e => e.countrycode)
                    .HasName("uid_gtm_country_country")
                    .IsUnique();

                entity.HasIndex(e => e.isocountrycode)
                    .HasName("uid_gtm_country_iso");

                entity.Property(e => e.countrycode)
                    .HasMaxLength(2)
                    .ValueGeneratedNever();

                entity.Property(e => e.countryname).HasMaxLength(50);

                entity.Property(e => e.createdby).HasMaxLength(30);

                entity.Property(e => e.isocountrycode)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.regioncode)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(30);

                entity.HasOne(d => d.isocountrycodeNavigation)
                    .WithMany(p => p.gtm_country)
                    .HasForeignKey(d => d.isocountrycode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_gtm_country_isocountrycode");

                entity.HasOne(d => d.regioncodeNavigation)
                    .WithMany(p => p.gtm_country)
                    .HasForeignKey(d => d.regioncode)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_gtm_country_regioncode");
            });

            modelBuilder.Entity<gtm_item_class>(entity =>
            {
                entity.HasKey(e => e.itemclass)
                    .HasName("pk_gtm_item_class");

                entity.ToTable("gtm_item_class", "hpcsf_master");

                entity.HasIndex(e => e.itemclass)
                    .HasName("uid_gtm_item_class")
                    .IsUnique();

                entity.Property(e => e.itemclass)
                    .HasMaxLength(30)
                    .ValueGeneratedNever();

                entity.Property(e => e.createdby).HasMaxLength(30);

                entity.Property(e => e.updatedby).HasMaxLength(30);
            });

            modelBuilder.Entity<gtm_offer_type>(entity =>
            {
                entity.ToTable("gtm_offer_type", "hpcsf_master");

                entity.HasIndex(e => new { e.l1offertype, e.l2offertype })
                    .HasName("uid_offer_type")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(30);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.updatedby).HasMaxLength(30);
            });

            modelBuilder.Entity<gtm_offer_type_by_country>(entity =>
            {
                entity.ToTable("gtm_offer_type_by_country", "hpcsf_master");

                entity.HasIndex(e => new { e.l1offertype, e.l2offertype, e.isocountrycode, e.regioncode })
                    .HasName("idx_gtm_offer_type_by_country")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(30);

                entity.Property(e => e.isocountrycode).HasMaxLength(3);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.regioncode).HasMaxLength(22);

                entity.Property(e => e.updatedby).HasMaxLength(30);
            });

            modelBuilder.Entity<gtm_region>(entity =>
            {
                entity.HasKey(e => e.regioncode)
                    .HasName("pk_gtm_region");

                entity.ToTable("gtm_region", "hpcsf_master");

                entity.HasIndex(e => e.regioncode)
                    .HasName("uid_region")
                    .IsUnique();

                entity.Property(e => e.regioncode)
                    .HasMaxLength(20)
                    .ValueGeneratedNever();

                entity.Property(e => e.createdby).HasMaxLength(30);

                entity.Property(e => e.id)
                    .ValueGeneratedOnAdd()
                    .UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.regionname).HasMaxLength(50);

                entity.Property(e => e.updatedby).HasMaxLength(30);
            });

            modelBuilder.Entity<plm_configrable_services>(entity =>
            {
                entity.ToTable("plm_configrable_services", "hpcsf_master");

                entity.HasIndex(e => e.printersku)
                    .HasName("idx_printersku_configrable_services");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_configrable_services");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.cpqflag).HasMaxLength(20);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.deliverablecode).HasMaxLength(100);

                entity.Property(e => e.description).HasMaxLength(60);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.modifiercode).HasMaxLength(10);

                entity.Property(e => e.modifiervalue).HasColumnType("numeric(18,8)");

                entity.Property(e => e.printersku).HasMaxLength(20);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);

                entity.HasOne(d => d.printerskuNavigation)
                    .WithMany(p => p.plm_configrable_services)
                    .HasForeignKey(d => d.printersku)
                    .HasConstraintName("fk_configrable_services_prn_sku");
            });

            modelBuilder.Entity<plm_cto_hw_bom>(entity =>
            {
                entity.ToTable("plm_cto_hw_bom", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_cto_hw_bom");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.featuretype).HasMaxLength(30);

                entity.Property(e => e.featurevalue).HasMaxLength(30);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<plm_family>(entity =>
            {
                entity.ToTable("plm_family", "hpcsf_master");

                entity.HasIndex(e => e.family)
                    .HasName("uid_family")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(30);

                entity.Property(e => e.family)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.labname).HasMaxLength(50);

                entity.Property(e => e.updatedby).HasMaxLength(30);
            });

            modelBuilder.Entity<plm_family_hw_accessories>(entity =>
            {
                entity.ToTable("plm_family_hw_accessories", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_family_hw_accessories");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.featuretype).HasMaxLength(30);

                entity.Property(e => e.featurevalue).HasMaxLength(30);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<plm_llc_bom>(entity =>
            {
                entity.ToTable("plm_llc_bom", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_llc_bom");

                entity.HasIndex(e => new { e.sku, e.family })
                    .HasName("uid_plm_llc_bom")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.description).HasMaxLength(60);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<plm_model>(entity =>
            {
                entity.ToTable("plm_model", "hpcsf_master");

                entity.HasIndex(e => e.model)
                    .HasName("uid_plm_model")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(30);

                entity.Property(e => e.model).HasMaxLength(50);

                entity.Property(e => e.series).HasMaxLength(50);

                entity.Property(e => e.updatedby).HasMaxLength(30);

                entity.HasOne(d => d.series_)
                    .WithMany(p => p.plm_model)
                    .HasForeignKey(d => d.series_id)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_plm_model_series");
            });

            modelBuilder.Entity<plm_mv_model>(entity =>
            {
                entity.ToTable("plm_mv_model", "hpcsf_master");

                entity.HasIndex(e => new { e.comparablehpseries, e.make, e.model })
                    .HasName("idx_plm_mv_model_key")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.comparablehpseries).HasMaxLength(50);

                entity.Property(e => e.createdby).HasMaxLength(30);

                entity.Property(e => e.make).HasMaxLength(7);

                entity.Property(e => e.model).HasMaxLength(50);

                entity.Property(e => e.updatedby).HasMaxLength(30);
            });

            modelBuilder.Entity<plm_pab_hw_bom>(entity =>
            {
                entity.ToTable("plm_pab_hw_bom", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_pab_hw_bom");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.featuretype).HasMaxLength(30);

                entity.Property(e => e.featurevalue).HasMaxLength(30);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<plm_preconfigured_hw_bom>(entity =>
            {
                entity.ToTable("plm_preconfigured_hw_bom", "hpcsf_master");

                entity.HasIndex(e => e.printersku)
                    .HasName("idx_printersku_preconfigured_hw_bom");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_preconfigured_hw_bom");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.featuretype).HasMaxLength(30);

                entity.Property(e => e.featurevalue).HasMaxLength(30);

                entity.Property(e => e.printersku).HasMaxLength(20);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);

                entity.HasOne(d => d.printerskuNavigation)
                    .WithMany(p => p.plm_preconfigured_hw_bom)
                    .HasForeignKey(d => d.printersku)
                    .HasConstraintName("fk_preconfigured_hw_bom_prn_sku");
            });

            modelBuilder.Entity<plm_preconfigured_services>(entity =>
            {
                entity.ToTable("plm_preconfigured_services", "hpcsf_master");

                entity.HasIndex(e => e.printersku)
                    .HasName("idx_printersku_preconfigured_services");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_preconfigured_services");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.country)
                    .IsRequired()
                    .HasMaxLength(3);

                entity.Property(e => e.cpqflag).HasMaxLength(20);

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.deliverablecode).HasMaxLength(100);

                entity.Property(e => e.description).HasMaxLength(60);

                entity.Property(e => e.enableflag).HasMaxLength(1);

                entity.Property(e => e.l1offertype).HasMaxLength(30);

                entity.Property(e => e.l2offertype).HasMaxLength(30);

                entity.Property(e => e.modifiercode).HasMaxLength(10);

                entity.Property(e => e.modifiervalue).HasColumnType("numeric(18,8)");

                entity.Property(e => e.printersku).HasMaxLength(20);

                entity.Property(e => e.region).HasMaxLength(22);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<plm_series>(entity =>
            {
                entity.ToTable("plm_series", "hpcsf_master");

                entity.HasIndex(e => e.series)
                    .HasName("uid_plm_series")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(30);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.series).HasMaxLength(60);

                entity.Property(e => e.updatedby).HasMaxLength(30);

                entity.HasOne(d => d.familyNavigation)
                    .WithMany(p => p.plm_series)
                    .HasPrincipalKey(p => p.family)
                    .HasForeignKey(d => d.family)
                    .HasConstraintName("fk_plm_series_family");
            });

            modelBuilder.Entity<plm_service_part_bom>(entity =>
            {
                entity.ToTable("plm_service_part_bom", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_service_part_bom");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.description).HasMaxLength(60);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<plm_sku>(entity =>
            {
                entity.HasKey(e => e.sku)
                    .HasName("pk_plm_sku");

                entity.ToTable("plm_sku", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("uid_plm_sku")
                    .IsUnique();

                entity.Property(e => e.sku)
                    .HasMaxLength(20)
                    .ValueGeneratedNever();

                entity.Property(e => e.createdby).HasMaxLength(30);

                entity.Property(e => e.model).HasMaxLength(50);

                entity.Property(e => e.updatedby).HasMaxLength(30);
            });

            modelBuilder.Entity<plm_sku_attributes>(entity =>
            {
                entity.HasKey(e => e.sku)
                    .HasName("pk_plm_sku_attributes");

                entity.ToTable("plm_sku_attributes", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("uid_plm_sku_attributes")
                    .IsUnique();

                entity.Property(e => e.sku)
                    .HasMaxLength(20)
                    .ValueGeneratedNever();

                entity.Property(e => e.createdby).HasMaxLength(30);

                entity.Property(e => e.description).HasMaxLength(200);

                entity.Property(e => e.productline).HasMaxLength(6);

                entity.Property(e => e.statuscode).HasMaxLength(3);

                entity.Property(e => e.updatedby).HasMaxLength(30);

                entity.Property(e => e.warrantycode).HasMaxLength(6);
            });

            modelBuilder.Entity<plm_supply_bom>(entity =>
            {
                entity.ToTable("plm_supply_bom", "hpcsf_master");

                entity.HasIndex(e => e.sku)
                    .HasName("idx_sku_supply_bom");

                entity.HasIndex(e => new { e.sku, e.family, e.supplycolortype, e.supplytype, e.supplyloadtype })
                    .HasName("uid_plm_supply_bom")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.description).HasMaxLength(400);

                entity.Property(e => e.family).HasMaxLength(50);

                entity.Property(e => e.sku).HasMaxLength(20);

                entity.Property(e => e.supplycolortype).HasMaxLength(30);

                entity.Property(e => e.supplyloadtype).HasMaxLength(30);

                entity.Property(e => e.supplytype).HasMaxLength(30);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<scott_tables>(entity =>
            {
                entity.ToTable("scott_tables", "hpcsf_master");

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.column_charid).HasMaxLength(4);

                entity.Property(e => e.column_name).HasMaxLength(33);

                entity.Property(e => e.data_type).HasMaxLength(30);

                entity.Property(e => e.table_name).HasMaxLength(63);
            });

            modelBuilder.Entity<treasury_currency>(entity =>
            {
                entity.ToTable("treasury_currency", "hpcsf_master");

                entity.HasIndex(e => e.iso3currencycode)
                    .HasName("idx_treasury_currency_iso3currecncy")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.description).HasMaxLength(60);

                entity.Property(e => e.iso2currencycode).HasMaxLength(3);

                entity.Property(e => e.iso3currencycode).HasMaxLength(3);

                entity.Property(e => e.numdecimals).HasColumnType("numeric(18,8)");

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<treasury_currency_rate>(entity =>
            {
                entity.ToTable("treasury_currency_rate", "hpcsf_master");

                entity.HasIndex(e => e.iso3currencycode)
                    .HasName("uid_treasury_currency_rate")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.currencyrate).HasColumnType("numeric(18,8)");

                entity.Property(e => e.iso2currencycode).HasMaxLength(2);

                entity.Property(e => e.iso3currencycode).HasMaxLength(3);

                entity.Property(e => e.productline).HasMaxLength(2);

                entity.Property(e => e.ratetable).HasMaxLength(30);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });

            modelBuilder.Entity<treasury_currency_rate_table>(entity =>
            {
                entity.ToTable("treasury_currency_rate_table", "hpcsf_master");

                entity.HasIndex(e => e.ratetable)
                    .HasName("uid_treasury_currency_rate_table")
                    .IsUnique();

                entity.Property(e => e.id).UseNpgsqlIdentityAlwaysColumn();

                entity.Property(e => e.createdby).HasMaxLength(60);

                entity.Property(e => e.ratetable).HasMaxLength(30);

                entity.Property(e => e.updatedby).HasMaxLength(60);
            });
        }
    }
}
