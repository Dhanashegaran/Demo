﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

namespace Hp.ContractualFramework.Services.Catalog.API.Migrations.PricingSimulation
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "pricing_simulation");

            migrationBuilder.CreateTable(
                name: "pricing_catalog",
                schema: "pricing_simulation",
                columns: table => new
                {
                    printersku = table.Column<string>(nullable: false),
                    effectivestartdate = table.Column<DateTime>(nullable: false),
                    effectiveenddate = table.Column<DateTime>(nullable: false),
                    simulationid = table.Column<string>(nullable: true),
                    enabled = table.Column<bool>(nullable: true, defaultValue: true),
                    createdby = table.Column<string>(nullable: true),
                    updatedby = table.Column<string>(nullable: true),
                    createddate = table.Column<DateTime>(nullable: true),
                    updateddate = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pricing_catalog", x => new { x.printersku, x.effectivestartdate, x.effectiveenddate });
                });

            migrationBuilder.CreateTable(
                name: "pricing_simulation_model_template",
                schema: "pricing_simulation",
                columns: table => new
                {
                    templateid = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    templateorder = table.Column<int>(nullable: false),
                    calcorder = table.Column<int>(nullable: true),
                    templatename = table.Column<string>(maxLength: 255, nullable: false),
                    templategroup = table.Column<string>(maxLength: 255, nullable: false),
                    comment = table.Column<string>(nullable: true),
                    enabled = table.Column<bool>(nullable: true, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pricing_simulation_model_template", x => x.templateid);
                });

            migrationBuilder.CreateTable(
                name: "pricing_simulation_request",
                schema: "pricing_simulation",
                columns: table => new
                {
                    requestid = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    simulationid = table.Column<string>(maxLength: 255, nullable: false),
                    createdby = table.Column<string>(nullable: true),
                    updatedby = table.Column<string>(nullable: true),
                    createddate = table.Column<DateTime>(nullable: true),
                    updateddate = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pricing_simulation_request", x => x.requestid);
                });

            migrationBuilder.CreateTable(
                name: "pricing_simulation_response",
                schema: "pricing_simulation",
                columns: table => new
                {
                    responseid = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    simulationid = table.Column<string>(maxLength: 255, nullable: false),
                    createdby = table.Column<string>(nullable: true),
                    updatedby = table.Column<string>(nullable: true),
                    createddate = table.Column<DateTime>(nullable: true),
                    updateddate = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pricing_simulation_response", x => x.responseid);
                });

            migrationBuilder.CreateTable(
                name: "pricing_simulation_model_template_field",
                schema: "pricing_simulation",
                columns: table => new
                {
                    fieldid = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    fieldorder = table.Column<int>(nullable: false),
                    calcorder = table.Column<int>(nullable: true),
                    fieldname = table.Column<string>(maxLength: 255, nullable: false),
                    calcprocedure = table.Column<string>(nullable: true),
                    calcexpression = table.Column<string>(nullable: true),
                    comment = table.Column<string>(nullable: true),
                    enabled = table.Column<bool>(nullable: true, defaultValue: true),
                    templateid = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pricing_simulation_model_template_field", x => x.fieldid);
                    table.ForeignKey(
                        name: "FK_pricing_simulation_model_template_field_pricing_simulation_~",
                        column: x => x.templateid,
                        principalSchema: "pricing_simulation",
                        principalTable: "pricing_simulation_model_template",
                        principalColumn: "templateid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "pricing_simulation_request_detail",
                schema: "pricing_simulation",
                columns: table => new
                {
                    requestdetailid = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    simulationid = table.Column<string>(maxLength: 255, nullable: false),
                    printersku = table.Column<string>(nullable: true),
                    targetbase = table.Column<decimal>(type: "decimal(18, 8)", nullable: false),
                    targetmonoclick = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    targetcolorclick = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    targetprofcolorclick = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    programdiscountpct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    printermonthlypagesoption = table.Column<string>(nullable: true),
                    overridemonthlymonopages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    overridemonthlyprofcolorpages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    overridemonthlycolorpages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    overridemonthlycolorsavepages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    suppliesyieldoption = table.Column<string>(nullable: true),
                    operationalmonocoveragepct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    operationalcolorcoveragepct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    createdby = table.Column<string>(nullable: true),
                    updatedby = table.Column<string>(nullable: true),
                    createddate = table.Column<DateTime>(nullable: true),
                    updateddate = table.Column<DateTime>(nullable: true),
                    requestid = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pricing_simulation_request_detail", x => x.requestdetailid);
                    table.ForeignKey(
                        name: "FK_pricing_simulation_request_detail_pricing_simulation_reques~",
                        column: x => x.requestid,
                        principalSchema: "pricing_simulation",
                        principalTable: "pricing_simulation_request",
                        principalColumn: "requestid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "pricing_simulation_request_header",
                schema: "pricing_simulation",
                columns: table => new
                {
                    requestheaderid = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    simulationid = table.Column<string>(maxLength: 255, nullable: false),
                    l1offertype = table.Column<string>(nullable: true),
                    l2offertype = table.Column<string>(nullable: true),
                    country = table.Column<string>(nullable: true),
                    currency = table.Column<string>(nullable: true),
                    currencyrate = table.Column<decimal>(type: "decimal(18, 8)", nullable: false),
                    term = table.Column<int>(nullable: false),
                    hwpurchasemethod = table.Column<string>(nullable: true),
                    billingmodel = table.Column<string>(nullable: true),
                    kitoption = table.Column<string>(nullable: true),
                    servicelevel = table.Column<string>(nullable: true),
                    hwfulfillmentoption = table.Column<string>(nullable: true),
                    suppliesfulfillmentoption = table.Column<string>(nullable: true),
                    hwfulfillmentchannel = table.Column<string>(nullable: true),
                    suppliesfulfillmentchannel = table.Column<string>(nullable: true),
                    includeoptionalaccessories = table.Column<bool>(nullable: true),
                    includeoptionalsupplies = table.Column<bool>(nullable: true),
                    includecarepacks = table.Column<bool>(nullable: true),
                    margintemplate = table.Column<string>(nullable: true),
                    pricingmethodology = table.Column<string>(nullable: true),
                    marginrebalancingmethod = table.Column<string>(nullable: true),
                    RealtimeCostCall = table.Column<bool>(nullable: false),
                    RealtimePriceCall = table.Column<bool>(nullable: false),
                    createdby = table.Column<string>(nullable: true),
                    updatedby = table.Column<string>(nullable: true),
                    createddate = table.Column<DateTime>(nullable: true),
                    updateddate = table.Column<DateTime>(nullable: true),
                    requestid = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pricing_simulation_request_header", x => x.requestheaderid);
                    table.ForeignKey(
                        name: "FK_pricing_simulation_request_header_pricing_simulation_reques~",
                        column: x => x.requestid,
                        principalSchema: "pricing_simulation",
                        principalTable: "pricing_simulation_request",
                        principalColumn: "requestid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "pricing_simulation_response_detail",
                schema: "pricing_simulation",
                columns: table => new
                {
                    responsedetailid = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    simulationid = table.Column<string>(maxLength: 255, nullable: false),
                    printersku = table.Column<string>(nullable: true),
                    componentsku = table.Column<string>(nullable: true),
                    itemclass = table.Column<string>(nullable: true),
                    cpqflag = table.Column<string>(nullable: true),
                    pricesource = table.Column<string>(nullable: true),
                    costsource = table.Column<string>(nullable: true),
                    tcos = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    tcoscurrency = table.Column<string>(nullable: true),
                    tcoscurrencyrate = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    targetmarginpct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    lclpcurrency = table.Column<string>(nullable: true),
                    lclpcurrencyrate = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    lclp = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    bdnetprice = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    bdnetpricecurrency = table.Column<string>(nullable: true),
                    bdnetpricecurrencyrate = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    contractualdiscountpct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    truckloaddiscountpct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    maxpricepct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    msppct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    tier1pct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    tier2pct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    tier3pct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    tier4pct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    isomonoyield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    isocoloryield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    isoprofcoloryield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    isocolorsaveyield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    isocoveragepct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    operationalyieldcalcmethod = table.Column<string>(nullable: true),
                    tcossimulationcurrencyrate = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    lclpsimulationcurrencyrate = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    bdnetsimulationcurrencyrate = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    unitcost = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    targetmarginnetprice = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    listprice = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    ndp = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    maxprice = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    msp = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    streetprice = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    bdnetpricetier0 = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    bdnetpricetier1 = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    bdnetpricetier2 = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    bdnetpricetier3 = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    bdnetpricetier4 = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    discountednetprice = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    netprice = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    operationalcoveragepct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    operationalmonoonmonoyield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    operationalmonoonprofessionalcoloryield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    operationalmonooncoloryield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    operationalmonooncolorsaveyield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    operationalprofcoloryield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    operationalcoloryield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    operationacolorsaveyield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    componentqty = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    componentbasefee = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    componentmonoclick = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    componentprofcolorclick = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    componentcolorclick = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    componentcolorsaveclick = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    extendednetprice = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    extendedcost = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    createdby = table.Column<string>(nullable: true),
                    updatedby = table.Column<string>(nullable: true),
                    createddate = table.Column<DateTime>(nullable: true),
                    updateddate = table.Column<DateTime>(nullable: true),
                    responseid = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pricing_simulation_response_detail", x => x.responsedetailid);
                    table.ForeignKey(
                        name: "FK_pricing_simulation_response_detail_pricing_simulation_respo~",
                        column: x => x.responseid,
                        principalSchema: "pricing_simulation",
                        principalTable: "pricing_simulation_response",
                        principalColumn: "responseid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "pricing_simulation_response_summary",
                schema: "pricing_simulation",
                columns: table => new
                {
                    responsesummaryid = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    simulationid = table.Column<string>(maxLength: 255, nullable: false),
                    printersku = table.Column<string>(nullable: true),
                    defaultmonthlymonopages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    defaultmonthlyprofcolorpages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    defaultmonthlycolorpages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    defaultmonthlycolorsavepages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    monthlymonopages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    monthlyprofcolorpages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    monthlycolorpages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    monthlycolorsavepages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    totalmonthlypages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    totalcontractmonopages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    totalcontractprofcolorpages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    totalcontractcolorpages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    totalcontractcolorsavepages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    totalcontractpages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    totaldirectpurchasehardware = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    basefee = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    monoclick = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    profcolorclick = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    colorclick = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    colorsaveclick = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    systemmarginpct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    hardwaremarginpct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    suppliesmarginpct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    servicemarginpct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    breakfixmarginpct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    kitmarginpct = table.Column<decimal>(type: "decimal(18, 4)", nullable: true),
                    createdby = table.Column<string>(nullable: true),
                    updatedby = table.Column<string>(nullable: true),
                    createddate = table.Column<DateTime>(nullable: true),
                    updateddate = table.Column<DateTime>(nullable: true),
                    responseid = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pricing_simulation_response_summary", x => x.responsesummaryid);
                    table.ForeignKey(
                        name: "FK_pricing_simulation_response_summary_pricing_simulation_resp~",
                        column: x => x.responseid,
                        principalSchema: "pricing_simulation",
                        principalTable: "pricing_simulation_response",
                        principalColumn: "responseid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_pricing_simulation_model_template_field_templateid",
                schema: "pricing_simulation",
                table: "pricing_simulation_model_template_field",
                column: "templateid");

            migrationBuilder.CreateIndex(
                name: "IX_pricing_simulation_request_simulationid",
                schema: "pricing_simulation",
                table: "pricing_simulation_request",
                column: "simulationid",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_pricing_simulation_request_detail_requestid",
                schema: "pricing_simulation",
                table: "pricing_simulation_request_detail",
                column: "requestid");

            migrationBuilder.CreateIndex(
                name: "IX_pricing_simulation_request_header_requestid",
                schema: "pricing_simulation",
                table: "pricing_simulation_request_header",
                column: "requestid",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_pricing_simulation_response_simulationid",
                schema: "pricing_simulation",
                table: "pricing_simulation_response",
                column: "simulationid",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_pricing_simulation_response_detail_responseid",
                schema: "pricing_simulation",
                table: "pricing_simulation_response_detail",
                column: "responseid");

            migrationBuilder.CreateIndex(
                name: "IX_pricing_simulation_response_summary_responseid",
                schema: "pricing_simulation",
                table: "pricing_simulation_response_summary",
                column: "responseid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "pricing_catalog",
                schema: "pricing_simulation");

            migrationBuilder.DropTable(
                name: "pricing_simulation_model_template_field",
                schema: "pricing_simulation");

            migrationBuilder.DropTable(
                name: "pricing_simulation_request_detail",
                schema: "pricing_simulation");

            migrationBuilder.DropTable(
                name: "pricing_simulation_request_header",
                schema: "pricing_simulation");

            migrationBuilder.DropTable(
                name: "pricing_simulation_response_detail",
                schema: "pricing_simulation");

            migrationBuilder.DropTable(
                name: "pricing_simulation_response_summary",
                schema: "pricing_simulation");

            migrationBuilder.DropTable(
                name: "pricing_simulation_model_template",
                schema: "pricing_simulation");

            migrationBuilder.DropTable(
                name: "pricing_simulation_request",
                schema: "pricing_simulation");

            migrationBuilder.DropTable(
                name: "pricing_simulation_response",
                schema: "pricing_simulation");
        }
    }
}
