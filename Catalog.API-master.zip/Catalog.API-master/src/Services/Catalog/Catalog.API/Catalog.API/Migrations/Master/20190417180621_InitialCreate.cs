﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

namespace Hp.ContractualFramework.Services.Catalog.API.Migrations.Master
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CFS_GEOGRAPHIC_MODEL",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    TABLE_NAME = table.Column<string>(unicode: false, maxLength: 65, nullable: false),
                    COLUMN_NAME = table.Column<string>(unicode: false, maxLength: 65, nullable: false),
                    MKEY = table.Column<string>(unicode: false, maxLength: 30, nullable: false),
                    MAPPED_VALUE = table.Column<string>(unicode: false, maxLength: 30, nullable: false),
                    ISO_KEY = table.Column<string>(unicode: false, maxLength: 30, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    UpdateDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CFS_GEOGRAPHIC_MODEL", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CFS_TABLE_METADATA",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    TABLE_NAME = table.Column<string>(unicode: false, maxLength: 100, nullable: false),
                    KEY_FIELDS = table.Column<string>(unicode: false, maxLength: 150, nullable: true),
                    WILDCARD_FIELDS = table.Column<string>(unicode: false, maxLength: 150, nullable: true),
                    DATE_FIELDS = table.Column<string>(unicode: false, maxLength: 100, nullable: true),
                    RANGE_FIELDS = table.Column<string>(unicode: false, maxLength: 100, nullable: true),
                    UPDATE_DTTM = table.Column<DateTime>(type: "date", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_USER = table.Column<string>(unicode: false, maxLength: 25, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CFS_TABLE_METADATA", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_BILLING_MODELS",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    BillingModel = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    Description = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_BILLING_MODELS", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_BILLING_MODELS_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    BillingModel = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_BILLING_MODELS_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_C4_COST_BY_OFFER",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    Currency = table.Column<string>(unicode: false, maxLength: 4, nullable: true),
                    TCOS = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    VCOS = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    EffStartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    EffEndDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    ISO2Currency = table.Column<string>(unicode: false, maxLength: 3, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_C4_COST_BY_OFFER", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_CATEGORY_PRICING_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: true),
                    Currency = table.Column<string>(unicode: false, maxLength: 4, nullable: true),
                    NetPrice = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_CATEGORY_PRICING_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_COUNTRY",
                columns: table => new
                {
                    IsoCountryCode = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CpqCountryFlag = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_COUNTRY_ISO_COUNTRY_CODE", x => x.IsoCountryCode);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_DEFAULT_BM_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    BillingModel = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_DEFAULT_BM_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_DEFAULT_HWFFO_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    HWFulfillmentOption = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_DEFAULT_HWFFO_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_DEFAULT_HWPO_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    HWPurchaseOption = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_DEFAULT_HWPO_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_DEFAULT_KO_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    KitOption = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_DEFAULT_KO_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_DEFAULT_MARGIN_TEMPLATE_BY_OFFER",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    MarginTemplate = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_DEFAULT_MARGIN_TEMPLATE_BY_OFFER", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_DEFAULT_SFFO_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SuppliesFulfillmentOption = table.Column<string>(unicode: false, maxLength: 60, nullable: false),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_DEFAULT_SFFO_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_DEFAULT_SLA_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SLA = table.Column<string>(unicode: false, maxLength: 16, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_DEFAULT_SLA_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_HW_FULFILLMENT_OPTIONS",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    HWFulfillmentOption = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    HWFulfillmentChannel = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Description = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_HW_FULFILLMENT_OPTIONS", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_HW_FULFILLMENT_OPTIONS_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    HWFulfillmentOption = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_HW_FULFILLMENT_OPTIONS_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_HW_PURCHASE_OPTIONS",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    HWPurchaseOption = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Description = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_HW_PURCHASE_OPTIONS", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_HW_PURCHASE_OPTIONS_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    HWPurchaseOption = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_HW_PURCHASE_OPTIONS_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_KIT_OPTIONS",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    KitOption = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Description = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_KIT_OPTIONS", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_KIT_OPTIONS_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    KitOption = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_KIT_OPTIONS_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_LOCAL_COST_BY_OFFER",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    Currency = table.Column<string>(unicode: false, maxLength: 4, nullable: true),
                    TCOS = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    VCOS = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    EffStartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    EffEndDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    ISO2Currency = table.Column<string>(unicode: false, maxLength: 3, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_LOCAL_COST_BY_OFFER", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_LOCAL_PRICE_BY_OFFER",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    PriceDescriptor = table.Column<string>(unicode: false, maxLength: 6, nullable: true),
                    ListPrice = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    EffStartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    EffEndDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_LOCAL_PRICE_BY_OFFER", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_MARGIN_TARGETS_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    MarginTemplate = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    Class = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    ProductLine = table.Column<string>(unicode: false, maxLength: 2, nullable: true),
                    PrinterSKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    TargetMarginPCT = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_MARGIN_TARGETS_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_MARGIN_TEMPLATE_BY_OFFER",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    MarginTemplate = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_MARGIN_TEMPLATE_BY_OFFER", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_MAX_PRICE_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    ProductLine = table.Column<string>(unicode: false, maxLength: 2, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    MaxPricePCT = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_MAX_PRICE_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_MSP_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    ProductLine = table.Column<string>(unicode: false, maxLength: 2, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    MSPPCT = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_MSP_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_PRICE_COST_SOURCE_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    PriceSource = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CostSource = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_PRICE_COST_SOURCE_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_PRICE_DESCRIPTOR_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: true),
                    ItemClass = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    PriceDescriptor = table.Column<string>(unicode: false, maxLength: 6, nullable: true),
                    DefaultFlag = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_PRICE_DESCRIPTOR_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_PRINTER_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CPQFlag = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_PRINTER_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_PRINTER_CLASS_ATTRIBUTES",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    Description = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    ShortDescription = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    IsColor = table.Column<string>(unicode: false, maxLength: 1, nullable: true),
                    IsMFP = table.Column<string>(unicode: false, maxLength: 1, nullable: true),
                    IsA3 = table.Column<string>(unicode: false, maxLength: 1, nullable: true),
                    IsInk = table.Column<string>(unicode: false, maxLength: 1, nullable: true),
                    IsFlow = table.Column<string>(unicode: false, maxLength: 1, nullable: true),
                    MonoPrintSpeed = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    ColorPrintSpeed = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    SimplexScanSpeed = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    DuplexScanSpeed = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    TrayCapacity = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    ADFCapacity = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    RMPV = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    EngineLife = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_PRINTER_CLASS_ATTRIBUTES", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_PRINTER_CLASS_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    DefaultMonthlyMonoPages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    DefaultMonthlyColorPages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    DefaultMonthlyProfColorPages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    DefaultMonthlyColorSavePages = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_PRINTER_CLASS_ATTRIBUTES_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_PRINTER_STATUS_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    ProductStatus = table.Column<string>(unicode: false, maxLength: 3, nullable: true),
                    NPIDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    STDDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    IBODate = table.Column<DateTime>(type: "datetime", nullable: true),
                    IBXDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_PRINTER_STATUS_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_RATE_TABLE_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    RateTable = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_RATE_TABLE_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_SERVICE_LEVELS",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SLA = table.Column<string>(unicode: false, maxLength: 16, nullable: true),
                    Description = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_SERVICE_LEVELS", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_SERVICE_LEVELS_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SLA = table.Column<string>(unicode: false, maxLength: 16, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_SERVICE_LEVELS_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_SERVICE_PART_PRICING_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: true),
                    Currency = table.Column<string>(unicode: false, maxLength: 4, nullable: true),
                    ListPrice = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    Discount = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    WarrantyCredit = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    UseLLCPriceFlag = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_SERVICE_PART_PRICING_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_STANDARD_DISCOUNTS_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    ProductLine = table.Column<string>(unicode: false, maxLength: 2, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: true),
                    StandardDiscountPCT = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_STANDARD_DISCOUNTS_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_SUPPLIES_FULFILLMENT_OPTIONS",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SuppliesFulfillmentOption = table.Column<string>(unicode: false, maxLength: 60, nullable: false),
                    SuppliesFulfillmentChannel = table.Column<string>(unicode: false, maxLength: 60, nullable: false),
                    Description = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_SUPPLIES_FULFILLMENT_OPTIONS", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_SUPPLIES_FULFILLMENT_OPTIONS_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SuppliesFulfillmentOption = table.Column<string>(unicode: false, maxLength: 60, nullable: false),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_SUPPLIES_FULFILLMENT_OPTIONS_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_TRUCKLOAD_DISCOUNTS_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    ProductLine = table.Column<string>(unicode: false, maxLength: 2, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    TruckloadDiscountPCT = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_TRUCKLOAD_DISCOUNTS_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_VOLUME_DISCOUNTS_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    ProductLine = table.Column<string>(unicode: false, maxLength: 2, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    Tier1PCT = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    Tier2PCT = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    Tier3PCT = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    Tier4PCT = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_VOLUME_DISCOUNTS_BY_OFFER_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "ct_table",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    table_name = table.Column<string>(unicode: false, maxLength: 63, nullable: true),
                    column_name = table.Column<string>(unicode: false, maxLength: 33, nullable: true),
                    column_charid = table.Column<string>(unicode: false, maxLength: 4, nullable: true),
                    column_id = table.Column<int>(nullable: true),
                    data_type = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    max_length = table.Column<int>(nullable: true),
                    precision = table.Column<int>(nullable: true),
                    scale = table.Column<int>(nullable: true),
                    is_nullable = table.Column<int>(nullable: true),
                    is_identity = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ct_table", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "GPSY_PRICE",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    PROD_BASE = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    OPT = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    PROD_NBR = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CTRY_CD = table.Column<string>(unicode: false, maxLength: 6, nullable: true),
                    CURR_CD = table.Column<string>(unicode: false, maxLength: 6, nullable: true),
                    PRC_TERM_CD = table.Column<string>(unicode: false, maxLength: 6, nullable: true),
                    QB_SET_NBR = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    QBL_SEQ_NBR = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    START_EFF_DT = table.Column<DateTime>(type: "date", nullable: true),
                    LCLP = table.Column<decimal>(type: "numeric(18, 6)", nullable: true),
                    USER_LOGON_ID = table.Column<string>(unicode: false, maxLength: 24, nullable: true),
                    PROCESS_NM = table.Column<string>(unicode: false, maxLength: 24, nullable: true),
                    LAST_MOD_TMSTMP = table.Column<DateTime>(type: "date", nullable: true),
                    END_EFF_DT = table.Column<DateTime>(type: "date", nullable: true),
                    END_DT_CD = table.Column<string>(unicode: false, maxLength: 3, nullable: true),
                    PRC_METH_CD = table.Column<string>(unicode: false, maxLength: 3, nullable: true),
                    CALC_REF_PRC_AMT = table.Column<decimal>(type: "numeric(18, 6)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GPSY_PRICE", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "GTM_OFFER_TYPE",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GTM_OFFER_TYPE", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "GTM_OFFER_TYPE_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    RegionCode = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    IsoCountryCode = table.Column<string>(unicode: false, maxLength: 3, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GTM_OFFER_TYPE_BY_COUNTRY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "GTM_REGION",
                columns: table => new
                {
                    RegionCode = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    RegionName = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GTM_REGION", x => x.RegionCode);
                });

            migrationBuilder.CreateTable(
                name: "PLM_CTO_HW_BOM",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    FeatureType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    FeatureValue = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_CTO_HW_BOM", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "PLM_FAMILY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    LabName = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_FAMILY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "PLM_FAMILY_HW_ACCESSORIES",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    FeatureType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    FeatureValue = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_FAMILY_HW_ACCESSORIES", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "PLM_LLC_BOM",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    Description = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_LLC_BOM", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "PLM_MV_MODEL",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    ComparableHpSeries = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    Make = table.Column<string>(unicode: false, maxLength: 7, nullable: true),
                    Model = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_MV_MODEL", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "PLM_PAB_HW_BOM",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    FeatureType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    FeatureValue = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_PAB_HW_BOM", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "PLM_PRECONFIGURED_SERVICES",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    Description = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    DeliverableCode = table.Column<string>(unicode: false, maxLength: 100, nullable: true),
                    ModifierCode = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    ModifierValue = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    PrinterSKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CPQFlag = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_PRECONFIGURED_SERVICES", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "PLM_SERVICE_PART_BOM",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    Description = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_SERVICE_PART_BOM", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "PLM_SUPPLY_BOM",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    Description = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    SupplyType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    SupplyLoadType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    SupplyColorType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_SUPPLY_BOM", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "scott_tables",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    table_name = table.Column<string>(unicode: false, maxLength: 63, nullable: true),
                    column_name = table.Column<string>(unicode: false, maxLength: 33, nullable: true),
                    column_charid = table.Column<string>(unicode: false, maxLength: 4, nullable: true),
                    column_id = table.Column<int>(nullable: true),
                    data_type = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    max_length = table.Column<int>(nullable: true),
                    precision = table.Column<int>(nullable: true),
                    scale = table.Column<int>(nullable: true),
                    is_nullable = table.Column<int>(nullable: true),
                    is_identity = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_scott_tables", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TREASURY_CURRENCY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    ISO2CurrencyCode = table.Column<string>(unicode: false, maxLength: 3, nullable: true),
                    ISO3CurrencyCode = table.Column<string>(unicode: false, maxLength: 3, nullable: true),
                    Description = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    NumDecimals = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TREASURY_CURRENCY", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TREASURY_CURRENCY_RATE",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    RateTable = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    ISO2CurrencyCode = table.Column<string>(unicode: false, maxLength: 3, nullable: true),
                    ProductLine = table.Column<string>(unicode: false, maxLength: 2, nullable: true),
                    CurrencyRate = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    EffStartDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    EffEndDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TREASURY_CURRENCY_RATE", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TREASURY_CURRENCY_RATE_TABLE",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    RateTable = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TREASURY_CURRENCY_RATE_TABLE", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "GTM_COUNTRY",
                columns: table => new
                {
                    CountryCode = table.Column<string>(unicode: false, maxLength: 2, nullable: false),
                    RegionCode = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    IsoCountryCode = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    CountryName = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GTM_COUNTRY", x => x.CountryCode);
                    table.ForeignKey(
                        name: "FK_GTM_COUNTRY_IsoCountryCode",
                        column: x => x.IsoCountryCode,
                        principalTable: "CPQ_COUNTRY",
                        principalColumn: "IsoCountryCode",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_GTM_COUNTRY_RegionCode",
                        column: x => x.RegionCode,
                        principalTable: "GTM_REGION",
                        principalColumn: "RegionCode",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PLM_SERIES",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    Series = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    family_id = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_SERIES", x => x.ID);
                    table.ForeignKey(
                        name: "FK_PLM_SERIES_Family",
                        column: x => x.family_id,
                        principalTable: "PLM_FAMILY",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PLM_MODEL",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Series = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    Model = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    series_id = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_MODEL", x => x.ID);
                    table.ForeignKey(
                        name: "FK_PLM_MODEL_Series",
                        column: x => x.series_id,
                        principalTable: "PLM_SERIES",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PLM_SKU",
                columns: table => new
                {
                    Sku = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    Model = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    model_id = table.Column<long>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_SKU", x => x.Sku);
                    table.ForeignKey(
                        name: "FK_PLM_SKU_MODEL",
                        column: x => x.model_id,
                        principalTable: "PLM_MODEL",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_LLC_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    PrinterSKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    MonoYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    ColorYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    ProfessionalColorYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_LLC_ATTRIBUTES_BY_OFFER_BY_COUNTRY", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LLC_ATTRIBUTES_PRN_SKU",
                        column: x => x.PrinterSKU,
                        principalTable: "PLM_SKU",
                        principalColumn: "Sku",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_PRINTER_ACCESSORY_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    PrinterSKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CPQAccessoryFlag = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    EnableFlag = table.Column<string>(unicode: false, maxLength: 1, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_PRINTER_ACCESSORY_BY_OFFER_BY_COUNTRY", x => x.ID);
                    table.ForeignKey(
                        name: "FK_PRINTER_ACCESSORY_PRN_SKU",
                        column: x => x.PrinterSKU,
                        principalTable: "PLM_SKU",
                        principalColumn: "Sku",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_PRINTER_LLC_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    PrinterSKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CPQFlag = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_PRINTER_LLC_BY_OFFER_BY_COUNTRY", x => x.ID);
                    table.ForeignKey(
                        name: "FK_PRINTER_LLC_BY_PRN_SKU",
                        column: x => x.PrinterSKU,
                        principalTable: "PLM_SKU",
                        principalColumn: "Sku",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_PRINTER_SERVICE_PART_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    PrinterSKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CPQFlag = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_PRINTER_SERVICE_PART_BY_OFFER_BY_COUNTRY", x => x.ID);
                    table.ForeignKey(
                        name: "FK_PRINTER_SERVICE_PART_PRN_SKU",
                        column: x => x.PrinterSKU,
                        principalTable: "PLM_SKU",
                        principalColumn: "Sku",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_PRINTER_SUPPLY_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    PrinterSKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CPQSupplyFlag = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_PRINTER_SUPPLY_BY_OFFER_BY_COUNTRY", x => x.ID);
                    table.ForeignKey(
                        name: "FK_PRINTER_SUPPLY_PRN_SKU",
                        column: x => x.PrinterSKU,
                        principalTable: "PLM_SKU",
                        principalColumn: "Sku",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_PW_SUPPLY_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    PrinterSKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CustomerAvailableInk = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    InkPerPage = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    GeneralOfficeReductionPCT = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    ColorSaveReductionPCT = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    MaintInkLowVolSlope = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    MaintInkLowVolIntercept = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    MaintInklSlope = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    MaintInkIntercept = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    MaintInkLowVolumeThreshold = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CostRatioMono = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CostRatioColor = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_PW_SUPPLY_ATTRIBUTES_BY_OFFER_BY_COUNTRY", x => x.ID);
                    table.ForeignKey(
                        name: "FK_PW_SUPPLY_ATTR_PRN_SKU",
                        column: x => x.PrinterSKU,
                        principalTable: "PLM_SKU",
                        principalColumn: "Sku",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_SERVICE_PART_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    PrinterSKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    AIR = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_SERVICE_PART_ATTRIBUTES_BY_OFFER_BY_COUNTRY", x => x.ID);
                    table.ForeignKey(
                        name: "FK_SERVICE_PART_A_PRN_SKU",
                        column: x => x.PrinterSKU,
                        principalTable: "PLM_SKU",
                        principalColumn: "Sku",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_SUPPLY_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    PrinterSKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    ISOMonoYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    ISOColorYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    ISOProfessionalColorYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    ISOCoveragePCT = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    StarterMonoYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    StarterColorYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    StarterProfessionalColorYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    StarterColorSaveYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    OperationalYieldCalcMethod = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    ISOColorSaveYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_SUPPLY_ATTRIBUTES_BY_OFFER_BY_COUNTRY", x => x.ID);
                    table.ForeignKey(
                        name: "FK_SUPPLY_ATTRIBU_PRN_SKU",
                        column: x => x.PrinterSKU,
                        principalTable: "PLM_SKU",
                        principalColumn: "Sku",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "CPQ_SUPPLY_PROGRAM_BY_OFFER_BY_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    SupplyProgram = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    PrinterSKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    ProgramMonoYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    ProgramColorYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    ProgramProfessionalColorYield = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CPQ_SUPPLY_PROGRAM_BY_OFFER_BY_COUNTRY", x => x.ID);
                    table.ForeignKey(
                        name: "FK_SUPPLY_PROGRAM_PRN_SKU",
                        column: x => x.PrinterSKU,
                        principalTable: "PLM_SKU",
                        principalColumn: "Sku",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PLM_CONFIGRABLE_SERVICES",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    Family = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    Description = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    DeliverableCode = table.Column<string>(unicode: false, maxLength: 100, nullable: true),
                    ModifierCode = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    ModifierValue = table.Column<decimal>(type: "decimal(18, 8)", nullable: true),
                    L1OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    L2OfferType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Region = table.Column<string>(unicode: false, maxLength: 22, nullable: true),
                    Country = table.Column<string>(unicode: false, maxLength: 3, nullable: false),
                    PrinterSKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CPQFlag = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_CONFIGRABLE_SERVICES", x => x.ID);
                    table.ForeignKey(
                        name: "FK_CONFIGRABLE_SERVICES_PRN_SKU",
                        column: x => x.PrinterSKU,
                        principalTable: "PLM_SKU",
                        principalColumn: "Sku",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "PLM_PRECONFIGURED_HW_BOM",
                columns: table => new
                {
                    ID = table.Column<long>(nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.SerialColumn),
                    PrinterSKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    FeatureType = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    FeatureValue = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    SKU = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 60, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PLM_PRECONFIGURED_HW_BOM", x => x.ID);
                    table.ForeignKey(
                        name: "FK_PRECONFIGURED_HW_BOM_PRN_SKU",
                        column: x => x.PrinterSKU,
                        principalTable: "PLM_SKU",
                        principalColumn: "Sku",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "UID_GEOGRAPHIC_MODEL_KEY",
                table: "CFS_GEOGRAPHIC_MODEL",
                columns: new[] { "TABLE_NAME", "MKEY", "MAPPED_VALUE" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UID_TABLE_METADATA_TABLENAME",
                table: "CFS_TABLE_METADATA",
                column: "TABLE_NAME",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "idx_C4_COST_SKU",
                table: "CPQ_C4_COST_BY_OFFER",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_CPQ_C4_COST_CountrySku",
                table: "CPQ_C4_COST_BY_OFFER",
                columns: new[] { "Country", "SKU" });

            migrationBuilder.CreateIndex(
                name: "uid_CATEGORY_PRICING_SKU",
                table: "CPQ_CATEGORY_PRICING_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "uid_CATEGORY_PRICING_Currency_SKU",
                table: "CPQ_CATEGORY_PRICING_BY_OFFER_BY_COUNTRY",
                columns: new[] { "Currency", "SKU" });

            migrationBuilder.CreateIndex(
                name: "uid_CATEGORY_PRICING_SKU_Currency",
                table: "CPQ_CATEGORY_PRICING_BY_OFFER_BY_COUNTRY",
                columns: new[] { "SKU", "Currency" });

            migrationBuilder.CreateIndex(
                name: "idx_PrinterSKU_LLC_ATTRIBUTES",
                table: "CPQ_LLC_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                column: "PrinterSKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_LLC_ATTRIBUTES",
                table: "CPQ_LLC_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_LOC",
                table: "CPQ_LOCAL_COST_BY_OFFER",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_CPQ_LOCAL_COST_BY_OFFER_CountrySku",
                table: "CPQ_LOCAL_COST_BY_OFFER",
                columns: new[] { "Country", "SKU" });

            migrationBuilder.CreateIndex(
                name: "idx_CPQ_LOCAL_PRICE_BY_OFFER_Start_End_EffDate",
                table: "CPQ_LOCAL_PRICE_BY_OFFER",
                columns: new[] { "EffStartDate", "EffEndDate" });

            migrationBuilder.CreateIndex(
                name: "idx_CPQ_LOCAL_PRICE_BY_OFFER_L2_L1",
                table: "CPQ_LOCAL_PRICE_BY_OFFER",
                columns: new[] { "L2OfferType", "L1OfferType" });

            migrationBuilder.CreateIndex(
                name: "idx_CPQ_LOCAL_PRICE_BY_OFFER_Sku_PriceDesc",
                table: "CPQ_LOCAL_PRICE_BY_OFFER",
                columns: new[] { "SKU", "PriceDescriptor" });

            migrationBuilder.CreateIndex(
                name: "idx_PrinterSKU_MARGIN_TARGETS",
                table: "CPQ_MARGIN_TARGETS_BY_OFFER_BY_COUNTRY",
                column: "PrinterSKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_MARGIN_TARGETS",
                table: "CPQ_MARGIN_TARGETS_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_MAX_PRICE_BY_O",
                table: "CPQ_MAX_PRICE_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_MSP_BY_OFFER_B",
                table: "CPQ_MSP_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_PRICE_COST_SOU",
                table: "CPQ_PRICE_COST_SOURCE_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_CPQ_PRICE_DESCRIPTOR_BY_OFFER_BY_COUNTRY_Country",
                table: "CPQ_PRICE_DESCRIPTOR_BY_OFFER_BY_COUNTRY",
                column: "Country");

            migrationBuilder.CreateIndex(
                name: "idx_CPQ_PRICE_DESCRIPTOR_BY_OFFER_BY_COUNTRY_L2_L1",
                table: "CPQ_PRICE_DESCRIPTOR_BY_OFFER_BY_COUNTRY",
                columns: new[] { "L2OfferType", "L1OfferType" });

            migrationBuilder.CreateIndex(
                name: "idx_PrinterSKU_PRINTER_ACCESS",
                table: "CPQ_PRINTER_ACCESSORY_BY_OFFER_BY_COUNTRY",
                column: "PrinterSKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_PRINTER_ACCESS",
                table: "CPQ_PRINTER_ACCESSORY_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_PRINTER_BY_OFF",
                table: "CPQ_PRINTER_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_PRINTER_CLASS_ATTRIBUTES",
                table: "CPQ_PRINTER_CLASS_ATTRIBUTES",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_PRINTER_CLASS_",
                table: "CPQ_PRINTER_CLASS_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_PrinterSKU_PRINTER_LLC_BY",
                table: "CPQ_PRINTER_LLC_BY_OFFER_BY_COUNTRY",
                column: "PrinterSKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_PRINTER_LLC_BY",
                table: "CPQ_PRINTER_LLC_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_PrinterSKU_PRINTER_SERVIC",
                table: "CPQ_PRINTER_SERVICE_PART_BY_OFFER_BY_COUNTRY",
                column: "PrinterSKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_PRINTER_SERVIC",
                table: "CPQ_PRINTER_SERVICE_PART_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_PRINTER_STATUS",
                table: "CPQ_PRINTER_STATUS_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_PrinterSKU_PRINTER_SUPPLY",
                table: "CPQ_PRINTER_SUPPLY_BY_OFFER_BY_COUNTRY",
                column: "PrinterSKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_PRINTER_SUPPLY",
                table: "CPQ_PRINTER_SUPPLY_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_PrinterSKU_PW_SUPPLY_ATTR",
                table: "CPQ_PW_SUPPLY_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                column: "PrinterSKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_PW_SUPPLY_ATTR",
                table: "CPQ_PW_SUPPLY_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_PrinterSKU_SERVICE_PART_A",
                table: "CPQ_SERVICE_PART_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                column: "PrinterSKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_SERVICE_PART_A",
                table: "CPQ_SERVICE_PART_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_SERVICE_PART_P",
                table: "CPQ_SERVICE_PART_PRICING_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_STANDARD_DISCO",
                table: "CPQ_STANDARD_DISCOUNTS_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_PrinterSKU_SUPPLY_ATTRIBU",
                table: "CPQ_SUPPLY_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                column: "PrinterSKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_SUPPLY_ATTRIBU",
                table: "CPQ_SUPPLY_ATTRIBUTES_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_PrinterSKU_SUPPLY_PROGRAM",
                table: "CPQ_SUPPLY_PROGRAM_BY_OFFER_BY_COUNTRY",
                column: "PrinterSKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_SUPPLY_PROGRAM",
                table: "CPQ_SUPPLY_PROGRAM_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_TRUCKLOAD_DISC",
                table: "CPQ_TRUCKLOAD_DISCOUNTS_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_VOLUME_DISCOUN",
                table: "CPQ_VOLUME_DISCOUNTS_BY_OFFER_BY_COUNTRY",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "UID_GPSY_PROD_BASE",
                table: "GPSY_PRICE",
                column: "PROD_BASE");

            migrationBuilder.CreateIndex(
                name: "UID_GTM_COUNTRY_COUNTRY",
                table: "GTM_COUNTRY",
                column: "CountryCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UID_GTM_COUNTRY_ISO",
                table: "GTM_COUNTRY",
                column: "IsoCountryCode");

            migrationBuilder.CreateIndex(
                name: "IX_GTM_COUNTRY_RegionCode",
                table: "GTM_COUNTRY",
                column: "RegionCode");

            migrationBuilder.CreateIndex(
                name: "UID_OFFER_TYPE",
                table: "GTM_OFFER_TYPE",
                columns: new[] { "L1OfferType", "L2OfferType" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UID_REGION",
                table: "GTM_REGION",
                column: "RegionCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "idx_PrinterSKU_CONFIGRABLE_SERVICES",
                table: "PLM_CONFIGRABLE_SERVICES",
                column: "PrinterSKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_CONFIGRABLE_SERVICES",
                table: "PLM_CONFIGRABLE_SERVICES",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_CTO_HW_BOM",
                table: "PLM_CTO_HW_BOM",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "UID_Family",
                table: "PLM_FAMILY",
                column: "Family",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "idx_SKU_FAMILY_HW_ACCESSORIES",
                table: "PLM_FAMILY_HW_ACCESSORIES",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_LLC_BOM",
                table: "PLM_LLC_BOM",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "UID_PLM_LLC_BOM",
                table: "PLM_LLC_BOM",
                columns: new[] { "SKU", "Family" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UID_PLM_MODEL",
                table: "PLM_MODEL",
                column: "Model",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_PLM_MODEL_series_id",
                table: "PLM_MODEL",
                column: "series_id");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_PAB_HW_BOM",
                table: "PLM_PAB_HW_BOM",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_PrinterSKU_PRECONFIGURED_HW_BOM",
                table: "PLM_PRECONFIGURED_HW_BOM",
                column: "PrinterSKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_PRECONFIGURED_HW_BOM",
                table: "PLM_PRECONFIGURED_HW_BOM",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "idx_PrinterSKU_PRECONFIGURED_SERVICES",
                table: "PLM_PRECONFIGURED_SERVICES",
                column: "PrinterSKU");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_PRECONFIGURED_SERVICES",
                table: "PLM_PRECONFIGURED_SERVICES",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "IX_PLM_SERIES_family_id",
                table: "PLM_SERIES",
                column: "family_id");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_SERVICE_PART_BOM",
                table: "PLM_SERVICE_PART_BOM",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "IX_PLM_SKU_model_id",
                table: "PLM_SKU",
                column: "model_id");

            migrationBuilder.CreateIndex(
                name: "idx_SKU_SUPPLY_BOM",
                table: "PLM_SUPPLY_BOM",
                column: "SKU");

            migrationBuilder.CreateIndex(
                name: "UID_PLM_SUPPLY_BOM",
                table: "PLM_SUPPLY_BOM",
                columns: new[] { "SKU", "Family" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UID_TREASURY_CURRENCY_RATE",
                table: "TREASURY_CURRENCY_RATE",
                column: "ISO2CurrencyCode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UID_TREASURY_CURRENCY_RATE_TABLE",
                table: "TREASURY_CURRENCY_RATE_TABLE",
                column: "RateTable",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CFS_GEOGRAPHIC_MODEL");

            migrationBuilder.DropTable(
                name: "CFS_TABLE_METADATA");

            migrationBuilder.DropTable(
                name: "CPQ_BILLING_MODELS");

            migrationBuilder.DropTable(
                name: "CPQ_BILLING_MODELS_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_C4_COST_BY_OFFER");

            migrationBuilder.DropTable(
                name: "CPQ_CATEGORY_PRICING_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_DEFAULT_BM_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_DEFAULT_HWFFO_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_DEFAULT_HWPO_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_DEFAULT_KO_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_DEFAULT_MARGIN_TEMPLATE_BY_OFFER");

            migrationBuilder.DropTable(
                name: "CPQ_DEFAULT_SFFO_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_DEFAULT_SLA_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_HW_FULFILLMENT_OPTIONS");

            migrationBuilder.DropTable(
                name: "CPQ_HW_FULFILLMENT_OPTIONS_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_HW_PURCHASE_OPTIONS");

            migrationBuilder.DropTable(
                name: "CPQ_HW_PURCHASE_OPTIONS_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_KIT_OPTIONS");

            migrationBuilder.DropTable(
                name: "CPQ_KIT_OPTIONS_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_LLC_ATTRIBUTES_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_LOCAL_COST_BY_OFFER");

            migrationBuilder.DropTable(
                name: "CPQ_LOCAL_PRICE_BY_OFFER");

            migrationBuilder.DropTable(
                name: "CPQ_MARGIN_TARGETS_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_MARGIN_TEMPLATE_BY_OFFER");

            migrationBuilder.DropTable(
                name: "CPQ_MAX_PRICE_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_MSP_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_PRICE_COST_SOURCE_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_PRICE_DESCRIPTOR_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_PRINTER_ACCESSORY_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_PRINTER_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_PRINTER_CLASS_ATTRIBUTES");

            migrationBuilder.DropTable(
                name: "CPQ_PRINTER_CLASS_ATTRIBUTES_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_PRINTER_LLC_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_PRINTER_SERVICE_PART_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_PRINTER_STATUS_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_PRINTER_SUPPLY_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_PW_SUPPLY_ATTRIBUTES_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_RATE_TABLE_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_SERVICE_LEVELS");

            migrationBuilder.DropTable(
                name: "CPQ_SERVICE_LEVELS_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_SERVICE_PART_ATTRIBUTES_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_SERVICE_PART_PRICING_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_STANDARD_DISCOUNTS_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_SUPPLIES_FULFILLMENT_OPTIONS");

            migrationBuilder.DropTable(
                name: "CPQ_SUPPLIES_FULFILLMENT_OPTIONS_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_SUPPLY_ATTRIBUTES_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_SUPPLY_PROGRAM_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_TRUCKLOAD_DISCOUNTS_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "CPQ_VOLUME_DISCOUNTS_BY_OFFER_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "ct_table");

            migrationBuilder.DropTable(
                name: "GPSY_PRICE");

            migrationBuilder.DropTable(
                name: "GTM_COUNTRY");

            migrationBuilder.DropTable(
                name: "GTM_OFFER_TYPE");

            migrationBuilder.DropTable(
                name: "GTM_OFFER_TYPE_BY_COUNTRY");

            migrationBuilder.DropTable(
                name: "PLM_CONFIGRABLE_SERVICES");

            migrationBuilder.DropTable(
                name: "PLM_CTO_HW_BOM");

            migrationBuilder.DropTable(
                name: "PLM_FAMILY_HW_ACCESSORIES");

            migrationBuilder.DropTable(
                name: "PLM_LLC_BOM");

            migrationBuilder.DropTable(
                name: "PLM_MV_MODEL");

            migrationBuilder.DropTable(
                name: "PLM_PAB_HW_BOM");

            migrationBuilder.DropTable(
                name: "PLM_PRECONFIGURED_HW_BOM");

            migrationBuilder.DropTable(
                name: "PLM_PRECONFIGURED_SERVICES");

            migrationBuilder.DropTable(
                name: "PLM_SERVICE_PART_BOM");

            migrationBuilder.DropTable(
                name: "PLM_SUPPLY_BOM");

            migrationBuilder.DropTable(
                name: "scott_tables");

            migrationBuilder.DropTable(
                name: "TREASURY_CURRENCY");

            migrationBuilder.DropTable(
                name: "TREASURY_CURRENCY_RATE");

            migrationBuilder.DropTable(
                name: "TREASURY_CURRENCY_RATE_TABLE");

            migrationBuilder.DropTable(
                name: "CPQ_COUNTRY");

            migrationBuilder.DropTable(
                name: "GTM_REGION");

            migrationBuilder.DropTable(
                name: "PLM_SKU");

            migrationBuilder.DropTable(
                name: "PLM_MODEL");

            migrationBuilder.DropTable(
                name: "PLM_SERIES");

            migrationBuilder.DropTable(
                name: "PLM_FAMILY");
        }
    }
}
